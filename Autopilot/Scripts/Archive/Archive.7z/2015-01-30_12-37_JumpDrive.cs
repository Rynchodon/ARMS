﻿#define LOG_ENABLED //remove on build

using System;
using System.Collections.Generic;
//using System.Linq;
//using System.Text;

using Sandbox.Common;
using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.ModAPI;
using Ingame = Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;

namespace Rynchodon.Autopilot.Jumper
{
	[MyEntityComponentDescriptor(typeof(MyObjectBuilder_GravityGeneratorSphere))]
	public class JumpDrive : MyGameLogicComponent
	{
		public bool enabled = false;
		public float radius = 10f;
		public float gravity = 0f;

		private static Dictionary<IMyCubeBlock, JumpDrive> registry = new Dictionary<IMyCubeBlock, JumpDrive>();

		private static string SubTypeNameLarge = "LargeBlockJumpDrive";
		private static string SubTypeNameSmall = "SmallBlockJumpDrive";

		private static ITerminalProperty<float> property_radius = null;
		private static ITerminalProperty<float> property_gravity = null;

		private static ITerminalAction action_onoff = null;

		private bool set_radius = false;
		private bool set_gravity = false;
		private bool toggled_onoff = false;

		private MyObjectBuilder_EntityBase builder_base = null;
		private IMyCubeBlock myBlock = null;
		private Ingame.IMyGravityGeneratorSphere myGravBlock = null;

		private bool initialized = false;

		private static Logger myLogger;
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private static void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{ alwaysLog(toLog, method, level); }
		private static void alwaysLog(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			if (myLogger == null) myLogger = new Logger(null, "JumpDrive");
			myLogger.log(level, method, toLog);
		}

		public override void Init(MyObjectBuilder_EntityBase objectBuilder)
		{
			builder_base = objectBuilder;
			Entity.NeedsUpdate |= MyEntityUpdateEnum.EACH_FRAME;
		}

		private void setup()
		{
			try
			{
				myBlock = Entity as IMyCubeBlock;
				myGravBlock = Entity as Ingame.IMyGravityGeneratorSphere;

				if (myBlock.BlockDefinition.SubtypeName != SubTypeNameLarge && myBlock.BlockDefinition.SubtypeName != SubTypeNameSmall)
				{
					// normal gravity
					//log("SubtypeName=" + myBlock.BlockDefinition.SubtypeName + " did not match JumpDrive", "Init()", Logger.severity.TRACE);
					Entity.NeedsUpdate = MyEntityUpdateEnum.NONE;
					return;
				}

				if (property_radius == null)
					property_radius = (ITerminalProperty<float>)myGravBlock.GetProperty("Radius");
				if (property_gravity == null)
					property_gravity = (ITerminalProperty<float>)myGravBlock.GetProperty("Gravity");
				if (action_onoff == null)
					action_onoff = myGravBlock.GetActionWithName("OnOff");

				registry.Add(myBlock, this);
				initialized = true;

				log("setup OK", "setup()", Logger.severity.INFO);
			}
			catch (Exception e)
			{
				alwaysLog("failed to setup" + e, "Init()", Logger.severity.FATAL);
				Close();
			}
		}

		public override void Close()
		{
			try
			{
				Entity.NeedsUpdate = MyEntityUpdateEnum.NONE;
				registry.Remove(myBlock);
			}
			catch (Exception e)
			{ alwaysLog("exception enabled removing from registry: " + e, "Close()", Logger.severity.FATAL); }
			myBlock = null;
		}

		~JumpDrive() { if (initialized) Close(); }

		public override void UpdateAfterSimulation()
		{
			try
			{
				if (!initialized) { setup(); return; }

				MyObjectBuilder_GravityGeneratorSphere builder = myBlock.GetObjectBuilderCubeBlock() as MyObjectBuilder_GravityGeneratorSphere;
				//log("builder=" + builder + ", producer=" + builder.ProducerEnabled + ", semiauto=" + builder.SemiautoEnabled);

				// block's enabled switch must match JumpDrive's
				if (builder.Enabled != enabled)
				{
					if (!toggled_onoff)
					{
						action_onoff.Apply(myGravBlock);
						toggled_onoff = true;
						log("toggled enabled to " + enabled, "UpdateAfterSimulation()", Logger.severity.DEBUG);
					}
				}
				else
					toggled_onoff = false;

				// block's radius must match JumpDrive's
				if (property_radius.GetValue(myGravBlock) != radius)
				{
					//log("property_radius=" + property_radius.GetValue(myGravBlock)+", radius="+radius);
					if (!set_radius)
					{
						property_radius.SetValue(myGravBlock, radius);
						set_radius = true;
						log("set property radius to " + radius, "UpdateAfterSimulation()", Logger.severity.DEBUG);
					}
				}
				else
					set_radius = false;

				// block's gravity must match JumpDrive's
				if (property_gravity.GetValue(myGravBlock) != gravity)
				{
					log("property_gravity=" + property_gravity.GetValue(myGravBlock) + ", gravity=" + gravity);
					if (!set_gravity)
					{
						property_gravity.SetValue(myGravBlock, gravity);
						set_gravity = true;
						log("set property gravity to " + gravity, "UpdateAfterSimulation()", Logger.severity.DEBUG);
					}
				}
				else
					set_gravity = false;

			}
			catch (Exception e)
			{
				log("Exception occured: " + e, "UpdateAfterSimulation()", Logger.severity.FATAL);
				Close();
			}
		}

		public override MyObjectBuilder_EntityBase GetObjectBuilder(bool copy = false)
		{ return builder_base; }

		public static bool tryGetJumpDrive(out JumpDrive forBlock, IMyCubeBlock block)
		{ return registry.TryGetValue(block, out forBlock); }
	}
}
