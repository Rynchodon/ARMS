﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Sandbox.ModAPI;
using VRageMath;

namespace Rynchodon.Autopilot
{
	class RelativeVector3
	{
		// one of these will always be set on create
		private Vector3? world;
		private Vector3? grid;
		//private Vector3? block = null;

		//private IMyCubeBlock cubeBlock = null;
		private IMyCubeGrid cubeGrid; // always set on create

		public static RelativeVector3 createFromWorld(Vector3 world, IMyCubeGrid cubeGrid)
		{
			RelativeVector3 result = new RelativeVector3();
			result.world = world;
			result.cubeGrid = cubeGrid;
			return result;
		}

		public static RelativeVector3 createFromGrid(Vector3 grid, IMyCubeGrid cubeGrid)
		{
			RelativeVector3 result = new RelativeVector3();
			result.grid = grid;
			result.cubeGrid = cubeGrid;
			return result;
		}

		//public static RelativeVector3 createFromBlock(Vector3 block, IMyCubeBlock cubeBlock) { } // might need this at some point

		private static float precisionMultiplier = 1080;

		public Vector3 getWorld()
		{
			if (world != null)
				return (Vector3)world;

			Vector3I gridInt = Vector3I.Round((Vector3)grid * precisionMultiplier / cubeGrid.GridSize);
			world = (cubeGrid.GridIntegerToWorld(gridInt) - cubeGrid.GetPosition()) / precisionMultiplier;
			return (Vector3)world;
		}

		public Vector3 getGrid()
		{
			if (grid != null)
				return (Vector3)grid;

			Vector3I gridInt = cubeGrid.WorldToGridInteger((Vector3)world * precisionMultiplier + cubeGrid.GetPosition());
			grid = (gridInt * cubeGrid.GridSize) / precisionMultiplier;
			return (Vector3)grid;
		}

		public Vector3 getBlock(Sandbox.ModAPI.IMyCubeBlock cubeBlock)
		{
			Vector3 v3;
			MatrixD matrix;
			if (grid != null)
			{
				v3 = ((Vector3)this.grid);
				matrix = cubeBlock.LocalMatrix;
			}
			else // (world != null)
			{
				v3 = ((Vector3)this.world);
				matrix = cubeBlock.WorldMatrix;
			}

			Vector3 resultant = v3.Dot(matrix.Right) * Base6Directions.GetVector(Base6Directions.Direction.Right);
			resultant += v3.Dot(matrix.Up) * Base6Directions.GetVector(Base6Directions.Direction.Up);
			resultant += v3.Dot(matrix.Backward) * Base6Directions.GetVector(Base6Directions.Direction.Backward);
			return resultant;
		}
	}
}
