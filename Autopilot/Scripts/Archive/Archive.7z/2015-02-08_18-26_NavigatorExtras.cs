﻿#define LOG_ENABLED //remove on build

using System;
using System.Collections.Generic;
using System.Linq;
//using System.Text;

using Sandbox.Common;
//using Sandbox.Common.Components;
//using Sandbox.Common.ObjectBuilders;
//using Sandbox.Definitions;
//using Sandbox.Engine;
//using Sandbox.Game;
using Sandbox.ModAPI;
using Ingame = Sandbox.ModAPI.Ingame;
//using Sandbox.ModAPI.Interfaces;
using VRageMath;

namespace Rynchodon.Autopilot
{
	internal class Targeter
	{
		private Logger myLogger;
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{ alwaysLog(toLog, method, level); }
		private void alwaysLog(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			if (myLogger == null) myLogger = new Logger(owner.myGrid.DisplayName, "Targeter");
			myLogger.log(level, method, toLog);
		}

		private Navigator owner;

		internal Targeter(Navigator owner)
		{ this.owner = owner; }

		public bool canConsiderFriendly(long playerID)
		{
			switch (owner.currentRCblock.GetUserRelationToOwner(playerID))
			{
				case MyRelationsBetweenPlayerAndBlock.FactionShare:
				case MyRelationsBetweenPlayerAndBlock.Owner:
					return true;
				default:
					return false;
			}
		}

		public bool canConsiderFriendly(IMyCubeBlock target)
		{
			if (target.OwnerId == 0) // every ship will have neutral blocks, treat them as belonging to grid's owner
				return canConsiderFriendly(target.CubeGrid);
			return canConsiderFriendly(target.OwnerId); 
		}

		public bool canConsiderFriendly(IMyCubeGrid target)
		{
			if (target.BigOwners.Count == 0)
				return true;
			foreach (long bigOwner in target.BigOwners)
				if (canConsiderFriendly(bigOwner))
					return true;
			foreach (long smallOwner in target.SmallOwners)
				if (canConsiderFriendly(smallOwner))
					return true;
			return false;
		}

		public bool canConsiderHostile(long playerID)
		{
			return (owner.currentRCblock.GetUserRelationToOwner(playerID) == MyRelationsBetweenPlayerAndBlock.Enemies);
		}

		public bool canConsiderHostile(IMyCubeBlock target)
		{
			if (target.OwnerId == 0) // every ship will have neutral blocks, treat them as belonging to grid's owner
				return canConsiderHostile(target.CubeGrid);
			return canConsiderHostile(target.OwnerId); 
		}

		public bool canConsiderHostile(IMyCubeGrid target)
		{
			if (target.BigOwners.Count == 0)
				return true;
			foreach (long bigOwner in target.BigOwners)
				if (canConsiderHostile(bigOwner))
					return true;
			foreach (long smallOwner in target.SmallOwners)
				if (canConsiderHostile(smallOwner))
					return true;
			return false;
		}

		private IMyCubeGrid isInRange_last_grid = null;
		private Vector3D isInRange_last_position;
		private double isInRange_last_distance;

		// TODO: use AntennaRelay
		private bool isInRange(out double distance, bool friend, IMyCubeGrid targetGrid)
		{
			Vector3D position = owner.currentRCblock.GetPosition();
			if (targetGrid == isInRange_last_grid && position == isInRange_last_position)
			{
				distance = isInRange_last_distance;
			}
			else
			{
				distance = targetGrid.WorldAABB.Distance(position);
				isInRange_last_grid = targetGrid;
				isInRange_last_position = position;
				isInRange_last_distance = distance;
			}

			if (friend)
			{
				//log("got distance of " + distance + ", between " + owner.myGrid.DisplayName + " and " + targetGrid.DisplayName, "canTarget()", Logger.severity.TRACE);
				return distance < Settings.intSettings[Settings.IntSetName.iMaxLockOnRangeFriend];
			}
			else
			{
				if (owner.CNS.lockOnRangeEnemy < 1)
					owner.CNS.lockOnRangeEnemy = Settings.intSettings[Settings.IntSetName.iMaxLockOnRangeEnemy];
				//log("got distance of " + distance + ", between " + owner.myGrid.DisplayName + " and " + targetGrid.DisplayName, "canTarget()", Logger.severity.TRACE);
				return distance < owner.CNS.lockOnRangeEnemy;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="distance">distance to grid if no targetBlock, distance to block squared otherwise</param>
		/// <param name="friend"></param>
		/// <param name="targetGrid"></param>
		/// <param name="targetBlock"></param>
		/// <returns></returns>
		private bool canTarget(out double distance, bool friend, IMyCubeGrid targetGrid = null, IMyCubeBlock targetBlock = null)
		{
			//log("entered canTarget(" + friend + ")", "canTarget()", Logger.severity.TRACE);

			distance = -1;
			if (targetBlock == null)
			{
				if (targetGrid == null)
					return false; // need something to target
				if (targetGrid.IsTrash())
				{
					log("cannot lock onto trash: " + targetGrid.DisplayName, "canTarget()", Logger.severity.TRACE);
					return false;
				}
				if (!isInRange(out distance, friend, targetGrid))
				{
					//log ("not in range", "canTarget()", Logger.severity.TRACE);
					return false;
				}

				if (friend)
				{
					if (!canConsiderFriendly(targetGrid))
						return false;
				}
				else if (!canConsiderHostile(targetGrid))
					return false;

				//log("can lock onto grid", "canTarget()", Logger.severity.TRACE);
				return true;
			}

			targetGrid = targetBlock.CubeGrid;

			// working test
			if (!friend && !targetBlock.IsWorking)
			{
				log("cannot lock onto non-working block: " + targetBlock.DisplayNameText, "canTarget()", Logger.severity.TRACE);
				return false;
			}

			// relations test
			if (friend)
			{
				//log("checking canConsiderFriendly: " + targetBlock.DisplayNameText, "canTarget()", Logger.severity.TRACE);
				if (!canConsiderFriendly(targetBlock))
				{
					log("cannot lock onto non-friend: " + targetBlock.DisplayNameText, "canTarget()", Logger.severity.TRACE);
					return false;
				}
			}
			else
			{
				//log("checking canConsiderHostile: " + targetBlock.DisplayNameText, "canTarget()", Logger.severity.TRACE);
				if (!canConsiderHostile(targetBlock))
				{
					log("cannot lock onto non-enemy: " + targetBlock.DisplayNameText, "canTarget()", Logger.severity.TRACE);
					return false;
				}
			}

			// distance test
			if (!isInRange(out distance, friend, targetGrid))
			{
				//log("got distance of " + distance + ", between " + owner.myGrid.DisplayName + " and " + targetGrid.DisplayName, "canTarget()", Logger.severity.TRACE);
				log("block's grid is out of range", "canTarget()", Logger.severity.TRACE);
				return false;
			}

			
			// passed all tests
			distance = (owner.currentRCblock.GetPosition() - targetBlock.GetPosition()).LengthSquared();
			//log("can lock onto block", "canTarget()", Logger.severity.TRACE);
			return true;
		}

		private static DateTime tryLockOnLastGlobal;
		private DateTime tryLockOnLastLocal;
		private static DateTime sanityCheckMinTime = DateTime.Today.AddDays(-1);

		public void tryLockOn()
		{
			//log("entered tryLockOn");

			if (owner.CNS.lockOnTarget == NavSettings.TARGET.OFF)
				return;

			DateTime now = DateTime.UtcNow;

			if (tryLockOnLastLocal > sanityCheckMinTime)
			{
				double secondsSinceLocalUpdate = (now - tryLockOnLastLocal).TotalSeconds;
				if (secondsSinceLocalUpdate < 1)
					return;
				double millisecondDelayGlobal = 9000 / secondsSinceLocalUpdate + 100;
				if (now < tryLockOnLastGlobal.AddMilliseconds(millisecondDelayGlobal))
					return;
			}
			else if (tryLockOnLastGlobal > sanityCheckMinTime && now < tryLockOnLastGlobal.AddMilliseconds(50)) // delay for first run
				return;

			log("trying to lock on type=" + owner.CNS.lockOnTarget, "tryLockOn()", Logger.severity.TRACE);
			tryLockOnLastGlobal = now;
			tryLockOnLastLocal = now;

			Sandbox.ModAPI.IMyCubeBlock closestBlock;
			Sandbox.ModAPI.IMyCubeGrid closestEnemy = findCubeGrid(out closestBlock, false, null, owner.CNS.lockOnBlock);
			if (closestEnemy == null)
			{
				double distance;
				if (owner.CNS.gridDestination != null && !canTarget(out distance, false, null, owner.CNS.closestBlock))
				{
					log("lost lock on " + owner.CNS.gridDestination + ":" + owner.CNS.getDestGridName());
					owner.CNS.atWayDest();
				}
				return;
			}

			// found an enemy, setting as destination
			if (closestBlock != null)
				log("found an enemy: " + closestEnemy.DisplayName + ":" + closestBlock.DisplayNameText, "tryLockOn()");
			else
				log("found an enemy: " + closestEnemy.DisplayName, "tryLockOn()");
			owner.CNS.setDestination(closestBlock, closestEnemy);

			if (owner.CNS.lockOnTarget == NavSettings.TARGET.MISSILE)
			{
				owner.CNS.isAMissile = true;
				owner.reportState(Navigator.ReportableState.MISSILE);
			}
			else
				owner.reportState(Navigator.ReportableState.ENGAGING);
			owner.CNS.waitUntil = DateTime.UtcNow; // stop waiting
			owner.CNS.clearSpeedInternal();
		}

		public Sandbox.ModAPI.IMyCubeGrid findCubeGrid(out Sandbox.ModAPI.IMyCubeBlock closestBlock, bool friend = true, string gridNameContains = null, string blockContains = null)//, double lockOnRangeEnemy = 0)
		{
			closestBlock = null;

			Dictionary<double, Sandbox.ModAPI.IMyCubeGrid> nearbyGrids = new Dictionary<double, Sandbox.ModAPI.IMyCubeGrid>();

			HashSet<IMyEntity> entities = new HashSet<IMyEntity>();
			MyAPIGateway.Entities.GetEntities(entities);
			foreach (IMyEntity entity in entities)
			{
				IMyCubeGrid grid = entity as IMyCubeGrid;
				if (grid == null)
					continue;
				if (owner.myGrid == grid)
					continue;

				double distance;
				if (!canTarget(out distance, friend, grid))
					continue;
				if (gridNameContains == null || Navigator.looseContains(grid.DisplayName, gridNameContains))
				{
					//log("adding to nearbyGrids: " + grid.DisplayName, "findCubeGrid()", Logger.severity.TRACE);
					bool added = false;
					while (!added)
					{
						try
						{
							nearbyGrids.Add(distance, grid);
							added = true;
						}
						catch (ArgumentException) { distance += 0.001; }
					}
				}
			}
			
			if (nearbyGrids.Count > 0)
				foreach (KeyValuePair<double, Sandbox.ModAPI.IMyCubeGrid> pair in nearbyGrids.OrderBy(i => i.Key))
				{
					log("checking pair: " + pair.Key + ", " + pair.Value.DisplayName + ". block contains=" + blockContains, "findCubeGrid()", Logger.severity.TRACE);
					if (blockContains == null || findClosestCubeBlockOnGrid(out closestBlock, pair.Value, blockContains, friend))
					{
						log("pair OK", "findCubeGrid()", Logger.severity.TRACE);
						return pair.Value;
					}
				}

			return null;
		}

		/// <summary>
		/// finds the closest block on a grid that contains the specified string
		/// </summary>
		/// <param name="grid"></param>
		/// <param name="blockContains"></param>
		/// <param name="friend"></param>
		/// <returns></returns>
		public bool findClosestCubeBlockOnGrid(out Sandbox.ModAPI.IMyCubeBlock closestBlock, Sandbox.ModAPI.IMyCubeGrid grid, string blockContains, bool friend) //, bool getAny = false)
		{
			List<Sandbox.ModAPI.IMySlimBlock> allBlocks = new List<Sandbox.ModAPI.IMySlimBlock>();
			closestBlock = null;
			double distanceToClosest = 0;
			grid.GetBlocks(allBlocks);
			foreach (Sandbox.ModAPI.IMySlimBlock blockInGrid in allBlocks)
			{
				Sandbox.ModAPI.IMyCubeBlock fatBlock = blockInGrid.FatBlock;
				if (fatBlock == null || fatBlock == owner.currentRCblock)
					continue;

				double distance;
				if (!canTarget(out distance, friend, null, fatBlock))
					continue;

				string toSearch;
				if (friend)
				{
					if (fatBlock is Ingame.IMyRemoteControl)
						toSearch = Navigator.getRCNameOnly(fatBlock);
					else
						toSearch = fatBlock.DisplayNameText;
				}
				else
					toSearch = fatBlock.DefinitionDisplayNameText;
				
				//toSearch = toSearch.ToLower();
				if (Navigator.looseContains(toSearch, blockContains))
				{
					//log("got a match for " + blockContains + ", match is " + toSearch, "findClosestCubeBlockOnGrid()", Logger.severity.TRACE);
					//double distance = myGridDim.getRCdistanceTo(fatBlock);
					if (closestBlock == null || distance < distanceToClosest)
					{
						closestBlock = fatBlock;
						distanceToClosest = distance;
					}
				}
				//else
				//	log("did not match " + toSearch + " to " + blockContains, "findClosestCubeBlockOnGrid()", Logger.severity.TRACE);
			}
			return (closestBlock != null);
		}
	}

	internal static class SpeedControl
	{
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private static void log(Logger logger, string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{ alwaysLog(logger, toLog, method, level); }
		private static void alwaysLog(Logger logger, string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			if (logger == null) logger = new Logger(null, "SpeedControl");
			logger.log(level, method, toLog);
		}

		public static void controlSpeed(Navigator nav)
		{
			Logger myLogger = new Logger(nav.myGrid.DisplayName, "SpeedControl");

			if (nav.CNS.isAMissile)
			{
				checkAndCruise(nav, myLogger);
				return;
			}

			if (nav.CNS.moveState == NavSettings.Moving.MOVING || nav.CNS.moveState == NavSettings.Moving.SIDELING)
			{
				//log("getting stopping distance", "controlSpeed()", Logger.severity.TRACE);
				double stoppingDistance = nav.currentThrust.getStoppindDistance();
				double distanceToDestination = nav.MM.distRCtoWayDest;
				if (nav.CNS.moveState == NavSettings.Moving.SIDELING)
					distanceToDestination = nav.MM.distNavToWayDest;

				//log("got stopping distance: " + stoppingDistance + ", distanceToDestination: " + distanceToDestination + ", CNS.getTypeOfWayDest(): " + CNS.getTypeOfWayDest(), "controlSpeed()", Logger.severity.TRACE);

				switch (nav.CNS.getTypeOfWayDest())
				{
					case NavSettings.TypeOfWayDest.BLOCK:
					case NavSettings.TypeOfWayDest.GRID:
					case NavSettings.TypeOfWayDest.LAND:
						if (nav.CNS.moveState == NavSettings.Moving.MOVING)
							distanceToDestination = nav.CNS.getDistanceToDestGrid();
						goto case NavSettings.TypeOfWayDest.COORDINATES;
					case NavSettings.TypeOfWayDest.WAYPOINT:
						adjustSpeeds(nav, myLogger, distanceToDestination, 1f, 2f);
						break;
					case NavSettings.TypeOfWayDest.OFFSET: // run collision avoidance on aproach. see CollisionAvoidance..ctor()
					case NavSettings.TypeOfWayDest.COORDINATES:
						adjustSpeeds(nav, myLogger, distanceToDestination, 2f, 4f);
						break;
				}
			}

			checkAndCruise(nav, myLogger);
		}

		private static void adjustSpeeds(Navigator nav, Logger myLogger, double distanceToDestination, float stopMultiplierSlowDown, float stopMultiplierSpeedUp)
		{
			if (distanceToDestination < 0)
			{
				log(myLogger, "distance < 0: " + distanceToDestination, "adjustSpeeds()", Logger.severity.INFO);
				nav.fullStop();
				return;
			}

			float stoppingDistance = nav.currentThrust.getStoppindDistance();

			if (distanceToDestination < stopMultiplierSlowDown * stoppingDistance) // distance is small
			{
				if (!(nav.currentMove == Vector3.Zero && nav.dampenersOn())) // not slowing down
				{
					float initialSpeedSlow = nav.CNS.getSpeedSlow();

					float speedSlow = (float)(nav.movementSpeed * 0.9);
					nav.CNS.speedSlow_internal = speedSlow;
					nav.CNS.speedCruise_internal = speedSlow / 2;

					//if (nav.CNS.getSpeedSlow() < initialSpeedSlow) // have made a difference
						log(myLogger, "reducing speeds (" + distanceToDestination + ", " + stoppingDistance + "), setting speed slow = " + (float)(nav.movementSpeed * 0.9), "adjustSpeeds()", Logger.severity.TRACE);
				}
			}
			else // distance is not small
				if (distanceToDestination > stopMultiplierSpeedUp * stoppingDistance) // distance is great
				{
					if (nav.currentMove == Vector3.Zero || nav.currentMove == cruiseForward) // not speeding up
					{
						float initialSpeedCruise = nav.CNS.getSpeedCruise();

						float speedCruise = (float)(nav.movementSpeed * 2);
						nav.CNS.speedCruise_internal = speedCruise;
						nav.CNS.speedSlow_internal = speedCruise * 2;

						//if (nav.CNS.getSpeedCruise() > initialSpeedCruise) // have made a difference
							log(myLogger, "increasing speeds (" + distanceToDestination + ", " + stoppingDistance + "), setting speed cruise = " + (float)(nav.movementSpeed * 2), "adjustSpeeds()", Logger.severity.TRACE);
					}
				}
		}

		private static readonly Vector3 cruiseForward = new Vector3(0, 0, -0.01); // 10 * observed minimum
		/// <summary>
		/// call every run, needed to enable dampeners
		/// two options for cruise: use cruiseForward, or disable dampeners
		/// </summary>
		private static void checkAndCruise(Navigator nav, Logger myLogger) //float rotLengthSq)
		{
			//log("entered checkAndCruise, speed="+movementSpeed+", slow="+CNS.getSpeedSlow()+", cruise="+CNS.getSpeedCruise());

			switch (nav.CNS.moveState)
			{
				case NavSettings.Moving.MOVING:
				case NavSettings.Moving.SIDELING:
				//case NavSettings.Moving.STOP_MOVE:
					break; // continue method
				default:
					if (nav.movementSpeed > 1 && !nav.dampenersOn())
					{
						nav.setDampeners();
						log(myLogger, "wrong state(" + nav.CNS.moveState + "), enabling dampeners", "checkAndCruise()", Logger.severity.TRACE);
					}
					return;
			}

			if (nav.movementSpeed > nav.CNS.getSpeedSlow())
			{
				if (!nav.dampenersOn() || nav.currentMove != Vector3.Zero)
				{
					nav.setDampeners();
					nav.moveOrder(Vector3.Zero);
					log(myLogger, "too fast(" + nav.CNS.getSpeedCruise() + " : " + nav.movementSpeed + " : " + nav.CNS.getSpeedSlow() + "), slowing", "checkAndCruise()", Logger.severity.TRACE);
				}
				return;
			}
			if (nav.movementSpeed < nav.CNS.getSpeedCruise())
			{
				// as long as there is acceleration, do not calcAndMove
				if (nav.currentMove == Vector3.Zero || nav.currentMove == cruiseForward && ! nav.movingTooSlow)
				{
					nav.movingTooSlow = true;
					nav.setDampeners();
					//nav.calcAndMove(nav.CNS.moveState == NavSettings.Moving.SIDELING);
					log(myLogger, "too slow(" + nav.CNS.getSpeedCruise() + " : " + nav.movementSpeed + " : " + nav.CNS.getSpeedSlow() + "), setting nav.movingTooSlow", "checkAndCruise()", Logger.severity.TRACE);
				}
				return;
			}

			// between cruise and slow speed
			if (nav.CNS.rotateState == NavSettings.Rotating.NOT_ROTA) // as long as state change comes after checkAndCruise, this will work
			{
				if (nav.dampenersOn() || nav.currentMove != Vector3.Zero)
				{
					// disable dampeners
					nav.setDampeners(false);
					nav.moveOrder(Vector3.Zero);
					log(myLogger, "speed is good(" + nav.CNS.getSpeedCruise() + " : " + nav.movementSpeed + " : " + nav.CNS.getSpeedSlow() + "), disabling dampeners", "checkAndCruise()", Logger.severity.TRACE);
				}
				return;
			}
			else
			{
				// use cruise vector
				if (!nav.dampenersOn() || nav.currentMove != cruiseForward)
				{
					nav.setDampeners();
					nav.moveOrder(cruiseForward, false);
					log(myLogger, "speed is good(" + nav.CNS.getSpeedCruise() + " : " + nav.movementSpeed + " : " + nav.CNS.getSpeedSlow() + "), using cruise vector", "checkAndCruise()", Logger.severity.TRACE);
				}
				return;
			}
		}
	}
}
