﻿using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//using Sandbox.Common;
//using Sandbox.Common.Components;
//using Sandbox.Common.ObjectBuilders;
//using Sandbox.Definitions;
//using Sandbox.Engine;
//using Sandbox.Game;
//using Sandbox.ModAPI;
//using Sandbox.ModAPI.Ingame;
//using Sandbox.ModAPI.Interfaces;
using VRageMath;

namespace Rynchodon.Autopilot
{
	/// <summary>
	/// for all the interactions between grid space and world space
	/// </summary>
	public class GridWorld
	{
		/// <summary>
		/// finds the middle of a grid
		/// </summary>
		/// <param name="target"></param>
		/// <returns>as world vector</returns>
		public static Vector3 getMiddle(Sandbox.ModAPI.IMyCubeGrid target)
		{
			Vector3[] corners = target.LocalAABB.GetCorners();

			float? maxX = null, maxY = null, maxZ = null, minX = null, minY = null, minZ = null;
			foreach (Vector3 corner in corners)
			{
				if (maxX == null)
				{
					maxX = corner.X; minX = corner.X;
					maxY = corner.Y; minY = corner.Y;
					maxZ = corner.Z; minZ = corner.Z;
					continue;
				}
				if (corner.X > maxX)
					maxX = corner.X;
				else if (corner.X < minX)
					minX = corner.X;

				if (corner.Y > maxY)
					maxY = corner.Y;
				else if (corner.Y < minY)
					minY = corner.Y;

				if (corner.Z > maxZ)
					maxZ = corner.Z;
				else if (corner.Z < minZ)
					minZ = corner.Z;
			}

			float midX = (float)(maxX + minX) / 2;
			float midY = (float)(maxY + minY) / 2;
			float midZ = (float)(maxZ + minZ) / 2;

			//log("getMiddle - origin is (" + target.GetPosition().X + ", " + target.GetPosition().Y + ", " + target.GetPosition().Z + "), middle is ("+midX+", "+midY+", "+midZ+")");
			//log("and middle in world is "+gridV3toWorld(target, new Vector3(midX, midY, midZ)));
			return gridV3toWorld(target, new Vector3(midX, midY, midZ));
		}

		/// <summary>
		/// converts from local metres to world
		/// </summary>
		/// <param name="target"></param>
		/// <param name="localF"></param>
		/// <returns>as world vector</returns>
		public static Vector3D gridV3toWorld(Sandbox.ModAPI.IMyCubeGrid target, Vector3 localF)
		{
			int x = (int)Math.Round(localF.X / target.GridSize);
			int y = (int)Math.Round(localF.Y / target.GridSize);
			int z = (int)Math.Round(localF.Z / target.GridSize);
			return target.GridIntegerToWorld(new Vector3I(x, y, z));
		}

		public struct closestCorner
		{
			/// <summary>
			/// world vector
			/// </summary>
			public Vector3 location;
			/// <summary>
			/// between start and corner
			/// </summary>
			public double distance;

			//private closestCorner();
			public closestCorner(Vector3 loc, double dist) { location = loc; distance = dist; }
		}
		/*/// <summary>
		/// find the closest corner of target grid to myPosition
		/// </summary>
		/// <param name="myPosition"></param>
		/// <param name="target"></param>
		/// <returns></returns>
		public static closestCorner getClosestCorner(Vector3D start, Sandbox.ModAPI.IMyCubeGrid target)
		{
			Vector3D[] corners = target.WorldAABB.GetCorners();

			Vector3 closestCorner = new Vector3();
			double? closestDistance = null;

			foreach (Vector3D corner in corners)
			{
				//Vector3 cornerWorld = gridV3toWorld(target, corner);
				double distance = (start - corner).Length();
				if (closestDistance == null || distance < closestDistance)
				{
					closestCorner = corner;
					closestDistance = distance;
				}
			}

			//log("getClosestCorner - origin is (" + target.GetPosition().X + ", " + target.GetPosition().Y + ", " + target.GetPosition().Z + "), corner is (" + closestCorner.X + ", " + closestCorner.Y + ", " + closestCorner .Z+ ")");
			return new closestCorner(closestCorner, (double)closestDistance);
		}*/

		/// <summary>
		/// take a Vector3D that is relative to a RC and convert it to world coordinates.
		/// uses the convention of (right, up, back)
		/// </summary>
		/// <param name="remoteControl"></param>
		/// <param name="RCrelative"></param>
		/// <returns>as world vector</returns>
		public static Vector3D RCtoWorld(Sandbox.ModAPI.IMyCubeBlock remoteControl, Vector3 RCrelative)
		{
			// orient according to RC
			Vector3D resultant = Vector3D.Zero;
			Base6Directions.Direction RCdirection = remoteControl.Orientation.Left;
			resultant -= Base6Directions.GetVector(RCdirection) * RCrelative.X;
			RCdirection = remoteControl.Orientation.Up;
			resultant += Base6Directions.GetVector(RCdirection) * RCrelative.Y;
			RCdirection = remoteControl.Orientation.Forward;
			resultant -= Base6Directions.GetVector(RCdirection) * RCrelative.Z;

			// add to RC position
			resultant += remoteControl.Position * remoteControl.CubeGrid.GridSize;

			// convert to world
			return gridV3toWorld(remoteControl.CubeGrid, resultant);
		}
	}
}
