﻿#define LOG_ENABLED //remove on build

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//using Sandbox.Common;
//using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
//using Sandbox.Definitions;
//using Sandbox.Engine;
//using Sandbox.Game;
using Sandbox.ModAPI;
using Ingame = Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using VRageMath;

using Rynchodon.Autopilot.Pathfinder;

namespace Rynchodon.Autopilot
{
	internal class Navigator
	{
		private Logger myLogger = null;
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			alwaysLog(level, method, toLog);
			//myLogger.log(level, method, toLog, CNS.moveState.ToString(), CNS.rotateState.ToString());
		}
		private void alwaysLog(string toLog, string method = null, Logger.severity level = Logger.severity.WARNING)
		{
			alwaysLog(level, method, toLog);
		}
		private void alwaysLog(Logger.severity level, string method, string toLog)
		{
			myLogger.log(level, method, toLog, CNS.moveState.ToString() + ":" + CNS.rotateState.ToString(), CNS.landingState.ToString());
		}

		public Sandbox.ModAPI.IMyCubeGrid myGrid { get; private set; }

		private List<Sandbox.ModAPI.IMySlimBlock> remoteControlBlocks;

		/// <summary>
		/// overrids fetching commands from display name when true
		/// </summary>
		public bool AIOverride = false;

		/// <summary>
		/// current navigation settings
		/// </summary>
		internal NavSettings CNS;
		private Collision myCollisionObject;
		internal GridDimensions myGridDim;
		private ThrustProfiler currentThrust;

		private IMyControllableEntity currentRemoteControl_Value;
		public IMyControllableEntity currentRCcontrol
		{
			get { return currentRemoteControl_Value; }
			set
			{
				//log("setting new RC ", "currentRCcontrol.set", Logger.severity.TRACE);
				if (currentRemoteControl_Value == value)
				{
					//log("currentRemoteControl_Value == value", "currentRCcontrol.set", Logger.severity.TRACE);
					return;
				}

				if (currentRemoteControl_Value != null)
				{
					// actions on old RC
					(currentRemoteControl_Value as Sandbox.ModAPI.IMyTerminalBlock).CustomNameChanged -= remoteControl_OnNameChanged;
					reportState(ReportableState.OFF);
				}

				currentRemoteControl_Value = value;
				if (currentRemoteControl_Value == null)
				{
					myGridDim = null;
					myCollisionObject = null;
					CNS = new NavSettings(null);
				}
				else
				{
					myGridDim = new GridDimensions(currentRCblock);
					myCollisionObject = new Collision(myGridDim); //(currentRCblock, out distance_from_RC_to_front);
					CNS = new NavSettings(myGridDim);
				}

				if (currentRemoteControl_Value != null)
				{
					// actions on new RC
					(currentRemoteControl_Value as Sandbox.ModAPI.IMyTerminalBlock).CustomNameChanged += remoteControl_OnNameChanged;
					reportState(ReportableState.OFF);
				}

				// some variables
				rotationPower = 3f;
				decelerateRotation = 1f / 2f;
				inflightRotatingPower = 3f;
				inflightDecelerateRotation = 1f / 2f;
			}
		}
		public Sandbox.ModAPI.IMyCubeBlock currentRCblock
		{
			get { return currentRemoteControl_Value as Sandbox.ModAPI.IMyCubeBlock; }
			set { currentRCcontrol = value as IMyControllableEntity; }
		}
		/// <summary>
		/// only use for position or distance, for rotation it is simpler to only use RC directions
		/// </summary>
		/// <returns></returns>
		public Sandbox.ModAPI.IMyCubeBlock getNavigationBlock()
		{
			if (CNS.landingState == NavSettings.LANDING.OFF || CNS.landLocalBlock == null)
				return currentRCblock;
			else
			{
				//log("using "+CNS.landLocalBlock.DisplayNameText+" as navigation block");
				if (CNS.landingSeparateBlock != null)
					return CNS.landingSeparateBlock;
				return CNS.landLocalBlock;
			}
		}

		internal Navigator(Sandbox.ModAPI.IMyCubeGrid grid)
		{
			myGrid = grid;
			myLogger = new Logger(myGrid.DisplayName, "Navigator");
		}

		private bool needToInit = true;

		private void init()
		{
			//	find remote control blocks
			remoteControlBlocks = new List<Sandbox.ModAPI.IMySlimBlock>();
			myGrid.GetBlocks(remoteControlBlocks, block => block.FatBlock != null && block.FatBlock.BlockDefinition.TypeId == remoteControlType);

			// register for events
			myGrid.OnBlockAdded += OnBlockAdded;
			//myGrid.OnBlockOwnershipChanged += OnBlockOwnershipChanged;
			myGrid.OnBlockRemoved += OnBlockRemoved;

			currentThrust = new ThrustProfiler(myGrid);
			CNS = new NavSettings(null);
			needToInit = false;
		}

		//private bool needToUpdateBlocks;
		private static MyObjectBuilderType remoteControlType = (new MyObjectBuilder_RemoteControl()).TypeId;

		//private void OnBlockOwnershipChanged(Sandbox.ModAPI.IMyCubeGrid changedBlock)
		//{
		//	//needToUpdateBlocks = true;

		//}

		private void OnBlockAdded(Sandbox.ModAPI.IMySlimBlock addedBlock)
		{
			if (addedBlock.FatBlock != null && addedBlock.FatBlock.BlockDefinition.TypeId == remoteControlType)
				remoteControlBlocks.Add(addedBlock);
				//needToUpdateBlocks = true;
		}

		private void OnBlockRemoved(Sandbox.ModAPI.IMySlimBlock removedBlock)
		{
			if (removedBlock.FatBlock != null)
			{
				if (removedBlock.FatBlock.BlockDefinition.TypeId == remoteControlType)
					remoteControlBlocks.Remove(removedBlock);
					//needToUpdateBlocks = true;
			}
		}

		private long updateCount = 0;

		/// <summary>
		/// Causes the ship to fly around, following commands.
		/// Calling more often means more precise movements, calling too often (~ every update) will break functionality.
		/// </summary>
		public void update()
		{
			updateCount++;
			if (!gridCanNavigate())
				return;
			if (needToInit)
				init();
			if (CNS.lockOnTarget != NavSettings.TARGET.OFF)
				tryLockOn();
			if (CNS.waitUntilNoCheck.CompareTo(DateTime.UtcNow) > 0)
				return;
			if (CNS.waitUntil.CompareTo(DateTime.UtcNow) > 0 || CNS.EXIT)
			{
				if (!remoteControlIsReady(currentRCcontrol as Sandbox.ModAPI.IMyCubeBlock)) // if something changes, stop waiting!
				{
					log("wait interrupted", "update()", Logger.severity.DEBUG);
					reset();
				}
				return;
			}

			if (CNS.getTypeOfWayDest() != NavSettings.TypeOfWayDest.NULL)
				navigate();
			else // no waypoints
			{
				//log("no waypoints or destination");
				if (CNS.instructions.Count > 0)
				{
					while (CNS.instructions.Count > 0)
					{
						addInstruction(CNS.instructions.Dequeue());
						switch (CNS.getTypeOfWayDest())
						{
							case NavSettings.TypeOfWayDest.BLOCK:
								log("got a block as a destination: " + CNS.getDestGridName() + ":" + CNS.destinationBlockName, "update()");
								reportState(ReportableState.PATHFINDING);
								return;
							case NavSettings.TypeOfWayDest.OFFSET:
								log("got an offset as a destination: " + CNS.getDestGridName() + ":" + CNS.destinationBlockName + ":" + CNS.destination_offset, "update()");
								reportState(ReportableState.PATHFINDING);
								return;
							case NavSettings.TypeOfWayDest.GRID:
								log("got a grid as a destination: " + CNS.getDestGridName(), "update()");
								reportState(ReportableState.PATHFINDING);
								return;
							case NavSettings.TypeOfWayDest.COORDINATES:
								log("got a new destination " + CNS.getWayDest(), "update()");
								reportState(ReportableState.PATHFINDING);
								return;
							case NavSettings.TypeOfWayDest.LAND:
								log("got a new landing destination " + CNS.getWayDest(), "update()");
								reportState(ReportableState.PATHFINDING);
								return;
							case NavSettings.TypeOfWayDest.NULL:
								break; // keep searching
							default:
								alwaysLog("got an invalid TypeOfWayDest: " + CNS.getTypeOfWayDest(), "update()", Logger.severity.WARNING);
								return;
						}
					}
					// at end of instructions
					CNS.endOfCommands();
					CNS.waitUntilNoCheck = DateTime.UtcNow.AddSeconds(1);
					return;
				}
				else
				{
					// find a remote control with NavSettings instructions
					reportState(ReportableState.NO_DEST);
					//log("searching for a ready remote control", "update()", Logger.severity.TRACE);
					CNS.waitUntilNoCheck = DateTime.UtcNow.AddSeconds(1);
					foreach (Sandbox.ModAPI.IMySlimBlock remoteControlBlock in remoteControlBlocks)
					{
						Sandbox.ModAPI.IMyCubeBlock fatBlock = remoteControlBlock.FatBlock;
						if (remoteControlIsReady(fatBlock))
						{
							if (AIOverride)
							{
								if (currentRCcontrol == null)
									currentRCcontrol = (fatBlock as IMyControllableEntity);
							}
							else
							{
								//	parse display name
								string instructions = getInstructionsFromRC(fatBlock);
								if (instructions != null)
								{
									log("found a ready remote control " + fatBlock.DisplayNameText, "update()", Logger.severity.TRACE);
									string noSpaces = instructions.Replace(" ", ""); // remove all spaces
									string[] inst = noSpaces.Split(':'); // split into CNS.instructions
									CNS.instructions = new Queue<string>(inst);
									currentRCcontrol = (fatBlock as IMyControllableEntity);
									log("finished queuing instructions(" + CNS.instructions.Count + ")", "update()", Logger.severity.TRACE);
									return;
								}
							}
						}
					}
					// failed to find a ready remote control
//					if (needToUpdateBlocks)
//						updateBlocks();
				}
			}
		}

		private void runActionOnBlock(string blockName, string actionString)
		{
			//log("entered runActionOnBlock("+blockName+", "+actionString+")", "runActionOnBlock()", Logger.severity.TRACE);
			blockName = blockName.ToLower().Replace(" ", "");
			actionString = actionString.Trim();

			List<IMySlimBlock> blocksWithName = new List<IMySlimBlock>();
			//ITerminalAction actionToRun = null;
			myGrid.GetBlocks(blocksWithName);//, block => block.FatBlock != null && block.FatBlock.DisplayNameText.Contains(blockName));
			foreach (IMySlimBlock block in blocksWithName){
				IMyCubeBlock fatblock = block.FatBlock;
				if (fatblock == null)
					continue;

				Sandbox.Common.MyRelationsBetweenPlayerAndBlock relationship = fatblock.GetUserRelationToOwner(currentRCblock.OwnerId);
				if (relationship != Sandbox.Common.MyRelationsBetweenPlayerAndBlock.Owner && relationship != Sandbox.Common.MyRelationsBetweenPlayerAndBlock.FactionShare)
				{
					//log("failed relationship test for " + fatblock.DisplayNameText + ", result was " + relationship.ToString(), "runActionOnBlock()", Logger.severity.TRACE);
					continue;
				}
				//log("passed relationship test for " + fatblock.DisplayNameText + ", result was " + relationship.ToString(), "runActionOnBlock()", Logger.severity.TRACE);

				//log("testing: " + fatblock.DisplayNameText, "runActionOnBlock()", Logger.severity.TRACE);
				// name test
				if (fatblock is Ingame.IMyRemoteControl)
				{
					string nameOnly = getRCNameOnly(fatblock);
					if (nameOnly == null || !nameOnly.Contains(blockName))
						continue;
				}
				else
				{
					if (!looseContains(fatblock.DisplayNameText, blockName))
					{
						//log("testing failed " + fatblock.DisplayNameText + " does not contain " + blockName, "runActionOnBlock()", Logger.severity.TRACE);
						continue;
					}
					//log("testing successfull " + fatblock.DisplayNameText + " contains " + blockName, "runActionOnBlock()", Logger.severity.TRACE);
				}

				if (!(fatblock is IMyTerminalBlock))
				{
					//log("not a terminal block: " + fatblock.DisplayNameText, "runActionOnBlock()", Logger.severity.TRACE);
					continue;
				}
				IMyTerminalBlock terminalBlock = fatblock as IMyTerminalBlock;
				ITerminalAction	actionToRun = terminalBlock.GetActionWithName(actionString); // get actionToRun on every iteration so invalid blocks can be ignored
				if (actionToRun != null)
				{
					log("running action: " + actionString + " on block: " + fatblock.DisplayNameText, "runActionOnBlock()", Logger.severity.DEBUG);
					actionToRun.Apply(fatblock);
				}
				//else
					//log("could not get action: " +actionString+" for: "+ fatblock.DisplayNameText, "runActionOnBlock()", Logger.severity.TRACE);
			}
		}

		/// <summary>
		/// adds a single instruction to this handler
		/// </summary>
		/// <param name="instruction">the instruction to add</param>
		private void addInstruction(string instruction)
		{
			log("entered addInstruction(" + instruction + ")", "addInstruction()", Logger.severity.TRACE);

			if (instruction.Length < 2)
				return;

			string lowerCase = instruction.ToLower();
			string data = lowerCase.Substring(1);

			if (looseContains(instruction, "EXIT"))
			{
				CNS.EXIT = true;
				reportState(ReportableState.OFF);
				return;
			}
			//if (looseContains(instruction, "JUMP"))
			//{
			//	log("setting jump");
			//	CNS.jump_to_dest = true;
			//	return;
			//}

			if (looseContains(instruction, "LOCK"))
			{
				if (CNS.landingState == NavSettings.LANDING.LOCKED)
				{
					log("staying locked. local=" + CNS.landingSeparateBlock.DisplayNameText, "addInstruction()", Logger.severity.TRACE);// + ", target=" + CNS.closestBlock + ", grid=" + CNS.gridDestination);
					CNS.landingState = NavSettings.LANDING.OFF;
					CNS.landingSeparateBlock = null;
					CNS.landingSeparateWaypoint = null;
				}
				return;
			}

			switch (lowerCase[0])
			{
				case 'a': // action, run an action on (a) block(s)
					{
						data = instruction.Substring(1); // restore case
						string[] split = data.Split(',');
						if (split.Length == 2)
							runActionOnBlock(split[0], split[1]);
						return;
					}
				case 'b': // block: for friendly, search by name. for enemy, search by type
					{
						string[] dataParts = data.Split(',');
						if (dataParts.Length != 2)
						{
							CNS.tempBlockName = data;
							return;
						}
						CNS.tempBlockName = dataParts[0];
						Base6Directions.Direction? dataDir = stringToDirection(dataParts[1]);
						if (dataDir != null)
							CNS.landDirection = dataDir;
							//CNS.landOffset = Base6Directions.GetVector((Base6Directions.Direction)dataDir);
						return;
					}
				case 'c': // coordinates
					{
						string[] coordsString = data.Split(',');
						if (coordsString.Length == 3)
						{
							double[] coordsDouble = new double[3];
							for (int i = 0; i < coordsDouble.Length; i++)
								if (!Double.TryParse(coordsString[i], out coordsDouble[i]))
									return;
							Vector3D destination = new Vector3D(coordsDouble[0], coordsDouble[1], coordsDouble[2]);
							CNS.setDestination(destination);
						}
						return;
					}
				case 'e': // fly to nearest enemy, set max lock-on, block
					goto case 'm';
				case 'f': // fly a given distance relative to RC
					{
						string[] coordsString = data.Split(',');
						if (coordsString.Length == 3)
						{
							double[] coordsDouble = new double[3];
							for (int i = 0; i < coordsDouble.Length; i++)
								if (!Double.TryParse(coordsString[i], out coordsDouble[i]))
								{
									//log("failed to parse " + coordsString[i] + " to double", "addInstruction()", Logger.severity.TRACE);
									return;
								}
							Vector3D destination = new Vector3D(coordsDouble[0], coordsDouble[1], coordsDouble[2]);
							destination = GridWorld.RCtoWorld(currentRCblock, destination);
							if (CNS.setDestination(destination))
							{
								//log("added " + destination + " as a relative destination, type response=" + CNS.getTypeOfWayDest(), "addInstruction()", Logger.severity.TRACE);
							}
							else
								log("failed to add " + destination + " as a fly to destination", "addInstruction()", Logger.severity.TRACE);
						}
						//else
							//log("wrong number of coords " + coordsString.Length, "addInstruction()", Logger.severity.TRACE);
						return;
					}
				case 'g': // grid: closest friendly grid that contains the string
					{
						CNS.destinationBlockName = CNS.tempBlockName;
						CNS.tempBlockName = null;
						Sandbox.ModAPI.IMyCubeBlock closestBlock;
						Sandbox.ModAPI.IMyCubeGrid closestGrid = findCubeGrid(out closestBlock, true, data, CNS.destinationBlockName);

						if (closestGrid != null)
						{
							CNS.setDestination(closestBlock, closestGrid);
							//log("grid destination set", "addInstruction()", Logger.severity.TRACE);
							//log("CNS.landLocalBlock = " + CNS.landLocalBlock + ", CNS.landOffset = " + CNS.landOffset, "addInstruction()", Logger.severity.TRACE);
							if (CNS.landLocalBlock != null && CNS.landOffset == Vector3.Zero)
							{
								Base6Directions.Direction? landDir = Lander.landingDirection(CNS.closestBlock);
								if (landDir == null)
								{
									log("could not get landing direction from block: " + CNS.landLocalBlock.DefinitionDisplayNameText, "calcOrientationFromBlockDirection()", Logger.severity.INFO);
									return;
								}
								CNS.landDirection = Lander.landingDirection(CNS.closestBlock);
								//CNS.landOffset = Base6Directions.GetVector((Base6Directions.Direction)Lander.landingDirection(CNS.closestBlock));
								log("set land offset to " + CNS.landOffset, "addInstruction()", Logger.severity.TRACE);
							}
						}
						return;
					}
				case 'l': // for landing or docking, specify direction and local block
					{
						//string[] dataParts = data.Split(',');
						//if (dataParts.Length != 2)
						//	return;
						//Base6Directions.Direction? dataDir = stringToDirection(dataParts[0]);
						//if (dataDir == null)
						//{
						//	log("could not get a direction for landing", "addInstruction()", Logger.severity.DEBUG);
						//	return;
						//}
						IMyCubeBlock landLocalBlock;
						findClosestCubeBlockOnGrid(out landLocalBlock, myGrid, data);
						CNS.landLocalBlock = landLocalBlock;
						if (CNS.landLocalBlock == null)
						{
							log("could not get a block for landing", "addInstruction()", Logger.severity.DEBUG);
							return;
						}

						//CNS.landOffset = Base6Directions.GetVector((Base6Directions.Direction)dataDir);
						//CNS.landRCdirection = myGridDim.direction_getLandRCdirection(landLocalBlock);
						return;
					}
				case 'm': // same as e, but will crash into target
					{
						double parsed;
						if (Double.TryParse(data, out parsed))
						{
							if (lowerCase[0] == 'e')
								CNS.lockOnTarget = NavSettings.TARGET.ENEMY;
							else
								CNS.lockOnTarget = NavSettings.TARGET.MISSILE;
							CNS.lockOnRange = (int)parsed;
							CNS.lockOnBlock = CNS.tempBlockName;
							CNS.tempBlockName = null;
						}
						else
						{
							CNS.lockOnTarget = NavSettings.TARGET.OFF;
							CNS.lockOnRange = 0;
							CNS.lockOnBlock = null;
							CNS.tempBlockName = null;
							log("stopped tracking enemies");
						}
						return;
					}
				case 'o': // destination offset, should be cleared after every waypoint
					{
						string[] coordsString = data.Split(',');
						if (coordsString.Length == 3)
						{
							double[] coordsDouble = new double[3];
							for (int i = 0; i < coordsDouble.Length; i++)
								if (!Double.TryParse(coordsString[i], out coordsDouble[i]))
									return;
							CNS.destination_offset = new Vector3I((int)coordsDouble[0], (int)coordsDouble[1], (int)coordsDouble[2]);
							log("setting offset to " + CNS.destination_offset, "addInstruction()", Logger.severity.DEBUG);
						}
						return;
					}
				case 'p': // how close ship needs to be to destination
					{
						double parsed;
						if (double.TryParse(data, out parsed))
							CNS.destinationRadius = (int)parsed;
						return;
					}
				case 'r': // match orientation
					{
						CNS.match_direction = null;
						CNS.match_roll = null;
						string[] orientation = data.Split(',');
						if (orientation.Length == 0 || orientation.Length > 2)
							return;
						Base6Directions.Direction? dir = stringToDirection(orientation[0]);
						//log("got dir "+dir);
						if (dir == null)
							return;
						CNS.match_direction = (Base6Directions.Direction)dir;

						if (orientation.Length == 1)
							return;
						Base6Directions.Direction? roll = stringToDirection(orientation[1]);
						//log("got roll " + roll);
						if (roll == null)
							return;
						CNS.match_roll = (Base6Directions.Direction)roll;

						return;
					}
				case 'v': // speed limits
					{
						string[] speeds = data.Split(',');
						if (speeds.Length == 2)
						{
							double[] parsedArray = new double[2];
							for (int i = 0; i < parsedArray.Length; i++)
							{
								if (!Double.TryParse(speeds[i], out parsedArray[i]))
									return;
							}
							CNS.speedCruise_external = (int)parsedArray[0];
							CNS.speedSlow_external = (int)parsedArray[1];
						}
						else
						{
							double parsed;
							if (Double.TryParse(data, out parsed))
								CNS.speedCruise_external = (int)parsed;
							return;
						}
						return;
					}
				case 'w': // wait
					double seconds = 0;
					if (Double.TryParse(data, out seconds))
					{
						if (CNS.waitUntil < DateTime.UtcNow)
							CNS.waitUntil = DateTime.UtcNow.AddSeconds(seconds);
						//if (seconds > 1.1)
						//log("setting wait for " + CNS.waitUntil);
					}
					return;
			}
			log("failed to parse: " + instruction, "addInstruction", Logger.severity.TRACE);
		}

		private Base6Directions.Direction? stringToDirection(string str)
		{
			switch (str[0])
			{
				case 'f':
					return Base6Directions.Direction.Forward;
				case 'b':
					return Base6Directions.Direction.Backward;
				case 'l':
					return Base6Directions.Direction.Left;
				case 'r':
					return Base6Directions.Direction.Right;
				case 'u':
					return Base6Directions.Direction.Up;
				case 'd':
					return Base6Directions.Direction.Down;
			}
			return null;
		}

		private static DateTime tryLockOnLastGlobal;
		private DateTime tryLockOnLastLocal;
		private static DateTime sanityCheckMinTime = DateTime.Today.AddDays(-1);

		private void tryLockOn()
		{
			//log("entered tryLockOn");

			if (CNS.lockOnTarget == NavSettings.TARGET.OFF)
				return;

			DateTime now = DateTime.UtcNow;

			if (tryLockOnLastLocal > sanityCheckMinTime)
			{
				double secondsSinceLocalUpdate = (now - tryLockOnLastLocal).TotalSeconds;
				if (secondsSinceLocalUpdate < 1)
					return;
				double millisecondDelayGlobal = 9000 / secondsSinceLocalUpdate + 100;
				if (now < tryLockOnLastGlobal.AddMilliseconds(millisecondDelayGlobal))
					return;
			}
			else if (tryLockOnLastGlobal > sanityCheckMinTime && now < tryLockOnLastGlobal.AddMilliseconds(50)) // delay for first run
				return;

			log("trying to lock on type=" + CNS.lockOnTarget, "tryLockOn()", Logger.severity.TRACE);
			tryLockOnLastGlobal = now;
			tryLockOnLastLocal = now;

			Sandbox.ModAPI.IMyCubeBlock closestBlock;
			Sandbox.ModAPI.IMyCubeGrid closestEnemy = findCubeGrid(out closestBlock, false, null, CNS.lockOnBlock, CNS.lockOnRange);
			if (closestEnemy == null)
			{
				//TODO check current target for validity
				//log("no enemy found");
				return;
			}

			// found an enemy, setting as destination
			if (closestBlock != null)
				log("found an enemy: " + closestEnemy.DisplayName + ":" + closestBlock.DisplayNameText);
			else
				log("found an enemy: " + closestEnemy.DisplayName);
			CNS.setDestination(closestBlock, closestEnemy);

			if (CNS.lockOnTarget == NavSettings.TARGET.MISSILE)
			{
				CNS.isAMissile = true;
				reportState(ReportableState.MISSILE);
			}
			else
				reportState(ReportableState.ENGAGING);
			CNS.waitUntil = DateTime.UtcNow; // stop waiting
			CNS.clearSpeedInternal();
		}

		public static bool looseContains(string bigstring, string substring)
		{
			bigstring = bigstring.ToLower().Replace(" ", "");
			substring = substring.ToLower().Replace(" ", "");

			return bigstring.Contains(substring);
		}

		private static int maxLockOnRangeEnemy = 1100; // only lock-onto enemies closer than this

		// TODO: check grid for functional
		private Sandbox.ModAPI.IMyCubeGrid findCubeGrid(out Sandbox.ModAPI.IMyCubeBlock closestBlock, bool friend = true, string nameContains = null, string blockContains = null, double lockOnRangeEnemy = 0)
		{
			//log("entered findCubeGrid: " + friend + ", " + nameContains + ", " + blockContains + ", " + lockOnRangeEnemy);
			if (lockOnRangeEnemy < 1 || maxLockOnRangeEnemy < lockOnRangeEnemy)
				lockOnRangeEnemy = maxLockOnRangeEnemy;

			closestBlock = null;

			Dictionary<double, Sandbox.ModAPI.IMyCubeGrid> nearbyGrids = new Dictionary<double, Sandbox.ModAPI.IMyCubeGrid>();

			HashSet<IMyEntity> entities = new HashSet<IMyEntity>();
			MyAPIGateway.Entities.GetEntities(entities, e => e is Sandbox.ModAPI.IMyCubeGrid);
			foreach (IMyEntity entity in entities)
			{
				Sandbox.ModAPI.IMyCubeGrid grid = entity as Sandbox.ModAPI.IMyCubeGrid;
				if (myGrid == grid)
				{
					//log("ignoring grid, is myGrid "+grid.DisplayName+":"+myGrid.DisplayName, "findCubeGrid()", Logger.severity.TRACE);
					continue;
				}
				if (Core.isHostile(myGrid, grid) == friend)
					continue;
				if (nameContains == null || looseContains(grid.DisplayName, nameContains))
				{
					double distance = myGridDim.getRCdistanceTo(grid); // even though we do not need to subtract distance to front
					if (friend || distance < lockOnRangeEnemy)
					{
						bool added = false;
						while (!added)
						{
							try
							{
								nearbyGrids.Add(distance, grid);
								added = true;
							}
							catch (ArgumentException) { distance += 0.001; }
						}
					}
				}
			}
			if (nearbyGrids.Count > 0)
				foreach (KeyValuePair<double, Sandbox.ModAPI.IMyCubeGrid> pair in nearbyGrids.OrderBy(i => i.Key))
				{
					log("checking pair: " + pair.Key + ", " + pair.Value + ". block contains=" + blockContains, "findCubeGrid()", Logger.severity.TRACE);
					if (blockContains == null || findClosestCubeBlockOnGrid(out closestBlock, pair.Value, blockContains, !friend))
						return pair.Value;
				}

			closestBlock = null;
			return null;
		}

		/// <summary>
		/// finds the closest block on a grid that contains the specified string
		/// </summary>
		/// <param name="grid"></param>
		/// <param name="blockContains"></param>
		/// <param name="searchByDefinition"></param>
		/// <returns></returns>
		private bool findClosestCubeBlockOnGrid(out Sandbox.ModAPI.IMyCubeBlock closestBlock, Sandbox.ModAPI.IMyCubeGrid grid, string blockContains, bool searchByDefinition = false) //, bool getAny = false)
		{
			//log("entered findClosestCubeBlockOnGrid: " + grid.DisplayName + ", " + blockContains + ", " + searchByDefinition + ", " + getAny);
			List<Sandbox.ModAPI.IMySlimBlock> allBlocks = new List<Sandbox.ModAPI.IMySlimBlock>();
			closestBlock = null;
			double distanceToClosest = 0;
			grid.GetBlocks(allBlocks);
			foreach (Sandbox.ModAPI.IMySlimBlock blockInGrid in allBlocks)
			{
				Sandbox.ModAPI.IMyCubeBlock fatBlock = blockInGrid.FatBlock;
				if (fatBlock == null || fatBlock == currentRCblock)
					continue;
				//if (!fatBlock.IsWorking)
				//{
				//	log("fatblock is not working for " + fatBlock.DisplayNameText, "findClosestCubeBlockOnGrid()", Logger.severity.TRACE);
				//	continue;
				//}
				if (!fatBlock.IsFunctional)
				{
					log("fatblock is not functional for " + fatBlock.DisplayNameText, "findClosestCubeBlockOnGrid()", Logger.severity.TRACE);
					continue;
				} if (!searchByDefinition)
				{
					var relationship = fatBlock.GetUserRelationToOwner(myGrid.BigOwners[0]);
					if (relationship == Sandbox.Common.MyRelationsBetweenPlayerAndBlock.Enemies || relationship == Sandbox.Common.MyRelationsBetweenPlayerAndBlock.Neutral)
					{
						log("relationship (" + relationship + ") no good for " + fatBlock.DisplayNameText, "findClosestCubeBlockOnGrid()", Logger.severity.TRACE);
						continue;
					}
				}
				
				string toSearch;
				if (searchByDefinition)
					toSearch = fatBlock.DefinitionDisplayNameText;
				else
					toSearch = fatBlock.DisplayNameText;
				if (fatBlock is Ingame.IMyRemoteControl)
				{
					toSearch = getRCNameOnly(fatBlock);
				} 
				toSearch = toSearch.ToLower();
				if (looseContains(toSearch, blockContains))
				{
					log("got a match for " + blockContains + ", match is " + toSearch, "findClosestCubeBlockOnGrid()", Logger.severity.TRACE);
					double distance = myGridDim.getRCdistanceTo(fatBlock);
					if (closestBlock == null || distance < distanceToClosest)
					{
						closestBlock = fatBlock;
						distanceToClosest = distance;
					}
				}
				//else
				//	log("did not match " + toSearch + " to " + blockContains, "findClosestCubeBlockOnGrid()", Logger.severity.TRACE);
			}
			return (closestBlock != null);
		}

		private bool player_controlling = false;

		/// <summary>
		/// checks for is a station, is owned by current session's player, grid exists
		/// </summary>
		/// <returns>true iff it is possible for this grid to navigate</returns>
		public bool gridCanNavigate()
		{
			if (myGrid == null)
			{
				log("grid is gone...", "gridCanNavigate()", Logger.severity.INFO);
				return false;
			}
			if (myGrid.IsStatic)
				return false;

			if (MyAPIGateway.Players.GetPlayerControllingEntity(myGrid) != null)
			{
				//if (MyAPIGateway.Players.GetPlayerControllingEntity(myGrid).Controller.ControlledEntity == myGrid)
				//	log("confirmed, controlling grid", "remoteControlIsReady()", Logger.severity.TRACE);
				//else
				//	log("did not confirm grid control", "remoteControlIsReady()", Logger.severity.TRACE);

				if (!player_controlling)
				{
					IMyPlayer controllingPlayer = MyAPIGateway.Players.GetPlayerControllingEntity(myGrid);
					if (controllingPlayer != null)
					{
						//if (CNS.landingState == NavSettings.LANDING.SEPARATE)
						//{
						//	// there is a bug in Space Engineers, when undocking with a player in a passenger seat
						//	MyAPIGateway.Players.RemoveControlledEntity(myGrid);
						//	//IMyPlayer originalPlayer = controllingPlayer;
						//	//controllingPlayer = MyAPIGateway.Players.GetPlayerControllingEntity(myGrid);
						//	//if (controllingPlayer == null)
						//	log("removed player control, player = " + controllingPlayer.DisplayName, "gridCanNavigate()", Logger.severity.TRACE);
						//	//else
						//	//	alwaysLog(Logger.severity.ERROR, "gridCanNavigate()", "failed to remove player control, player = " + controllingPlayer.DisplayName);
						//}
						//else
						//{
							log("player is controlling grid: " + controllingPlayer.DisplayName, "gridCanNavigate()", Logger.severity.TRACE);
							//MyAPIGateway.Players.RemoveControlledEntity(myGrid);
							//if (MyAPIGateway.Players.GetPlayerControllingEntity(myGrid) != null)
							//{
							//	log("failed to remove control from " + MyAPIGateway.Players.GetPlayerControllingEntity(myGrid).DisplayName, "remoteControlIsReady()", Logger.severity.TRACE);
							player_controlling = true;
							reportState(ReportableState.PLAYER);
							//}
						//}
					}
				}
				return false;
			}
			if (player_controlling)
			{
				log("player(s) released controls", "gridCanNavigate()", Logger.severity.TRACE);
				player_controlling = false;
				//reportState(ReportableState.OFF);
			}

			//if (myGrid.BigOwners.Count > 0)
				//return Core.canControl(myGrid);

			return true;
		}

		private bool remoteControlIsNotReady = false;

		/// <summary>
		/// checks the functional and working flags, current player owns it, display name has not changed
		/// </summary>
		/// <param name="remoteControl">remote control to check</param>
		/// <returns>true iff the remote control is ready</returns>
		public bool remoteControlIsReady(Sandbox.ModAPI.IMyCubeBlock remoteControl)
		{
			if (remoteControlIsNotReady)
			{
				remoteControlIsNotReady = false;
				return false;
			}
			if (remoteControl == null)
			{
				//log("no remote control", "remoteControlIsReady()", Logger.severity.TRACE);
				return false;
			}
			if (!remoteControl.IsFunctional)
			{
				log("not functional", "remoteControlIsReady()", Logger.severity.TRACE);
				return false;
			}
			if (!remoteControl.IsWorking)
			{
				log("not working", "remoteControlIsReady()", Logger.severity.TRACE);
				return false;
			}
			if (remoteControl.CubeGrid.BigOwners.Count == 0) // no owner
			{
				log("no owner", "remoteControlIsReady()", Logger.severity.TRACE);
				return false;
			}
			//if (!Core.canControl(remoteControl))
			if (remoteControl.OwnerId != remoteControl.CubeGrid.BigOwners[0]) // remote control is not owned by grid's owner
			{
				log("remote has different owner", "remoteControlIsReady()", Logger.severity.TRACE);
				return false;
			}
			if (!(remoteControl as Ingame.IMyShipController).ControlThrusters)
			{
				//log("no thruster control", "remoteControlIsReady()", Logger.severity.TRACE);
				return false;
			}

			return true;
		}

		public bool remoteControlIsReady(IMyControllableEntity remoteControl)
		{
			return remoteControlIsReady(remoteControl as Sandbox.ModAPI.IMyCubeBlock);
		}

		/// <summary>
		/// stop the ship, return navigation variables to their defaults, clears current remote control
		/// </summary>
		public void reset()
		{
			//log("resetting");
			NavSettings startNav = CNS;
			if (currentRCcontrol != null)
			{
				try
				{
					fullStop();
				}
				catch (NullReferenceException) // when grid is destroyed
				{
					//currentRCcontrol.MoveAndRotateStopped();
					//currentRCcontrol = null;
				}
				//log("clearing current remote control");
				currentRCcontrol = null;
			}
			//if (needToUpdateBlocks)
			//	updateBlocks();
			if (object.ReferenceEquals(startNav, CNS))
			{
				log("clearing CNS", "reset()", Logger.severity.DEBUG);
				CNS = new NavSettings(myGridDim);
			}
			else
				log("did not clear CNS", "reset()", Logger.severity.TRACE);
			//CNS = new NavSettings(this);
		}

		private double pitchNeedToRotate; // from start of rotation
		private double yawNeedToRotate; // from start of rotation
		/// <summary>
		/// from RC (forward) to way/dest
		/// </summary>
		private double distRCtoWayDest;
		/// <summary>
		/// navigation block to way/dest point. Only call when invalidating, otherwise use getDistNavToWayDest()
		/// </summary>
		private double distNavToWayDest_value = -1;

		public double getDistNavToWayDest()
		{
			if (distNavToWayDest_value < 0)
				distNavToWayDest_value = (getNavigationBlock().GetPosition() - (Vector3D)CNS.getWayDest()).Length();
			return distNavToWayDest_value;
		}

		//private Vector3D? previousPosition = null;
		//private DateTime? previousTime = null;
		public double movementSpeed { get; private set; }
		Vector3D currentPos;

		private DateTime maxRotateTime;

		private void navigate()
		{
			if (currentRCblock == null)
				return;
			if (!remoteControlIsReady(currentRCblock))
			{
				log("remote control is not ready");
				reset();
				return;
			}

			// before navigate
			if (movementSpeed > 0 && currentMove == Vector3.Zero && dampenersOn())
			{
				//log("assessing power... reason is " + movementSpeed + ", " + currentMove + ", " + dampenersOn(), "navigate()", Logger.severity.TRACE);
				currentThrust.assessPower();
			}

			navigateSub();

			// after navigate
			checkStopped();
		}

		private Lander myLand;

		private void navigateSub()
		{
			//log("entered navigate(" + currentWaypoint + ")", "navigate()", Logger.severity.TRACE);

			Vector3D currentWaypoint = (Vector3D)CNS.getWayDest(); // update() checked for null
			Vector3D displacement = currentWaypoint - myGridDim.getRCworld();
			//log("displacement vector: "+displacement);

			Vector3D dirNorm = Vector3D.Normalize(displacement);
			double pitch, yaw;
			getRotationC(dirNorm, out pitch, out yaw);

			distRCtoWayDest = CNS.getDistanceToWayDest();
			distNavToWayDest_value = -1; // invalidate
			//log("distanceToWaypoint=" + distanceToWaypoint, "navigate()", Logger.severity.TRACE);

			movementSpeed = myGrid.Physics.LinearVelocity.Length();

			if (CNS.landingState != NavSettings.LANDING.OFF)
			{
				myLand.landGrid(pitch, yaw); // continue landing
				return;
			}
			if (myLand != null && myLand.targetDirection != null)
			{
				myLand.matchOrientation(); // continue match
				return;
			}
			//if (CNS.jump_to_dest && CNS.moveState == NavSettings.Moving.NOT_MOVE && CNS.rotateState == NavSettings.Rotating.NOT_ROTA && distRCtoWayDest > 1000)
			//{
			//	jumpToDestination();
			//}

			if (distRCtoWayDest < CNS.destinationRadius && !CNS.isAMissile && (CNS.landLocalBlock == null || distRCtoWayDest < 1)) // at Way or Dest
			{
				if (CNS.getTypeOfWayDest() == NavSettings.TypeOfWayDest.WAYPOINT)
				{
					CNS.atWayDest();
					if (CNS.getTypeOfWayDest() == NavSettings.TypeOfWayDest.NULL)
					{
						alwaysLog(Logger.severity.ERROR, "navigate()", "Error no more destinations at Navigator.navigate() // at destination");
						fullStop();
					}
					else
					{
						log("reached waypoint, next type is " + CNS.getTypeOfWayDest() + ", coords: " + CNS.getWayDest(), "navigate()", Logger.severity.INFO);
						CNS.clearSpeedInternal();
						//fullStop();
					}
				}
				else // CNS.getTypeOfWayDest() != NavSettings.TypeOfWayDest.WAYPOINT
					if (CNS.destinationRadius > 0)
					{
						if (CNS.moveState == NavSettings.Moving.NOT_MOVE)
						{
							if (CNS.match_direction == null && CNS.landLocalBlock == null)
							{
								log("reached destination", "navigate()", Logger.severity.INFO);
								CNS.atWayDest();
							}
							else
							{
								if (CNS.landLocalBlock != null)
								{
									log("near dest, start landing. dist=" + distRCtoWayDest + ", radius=" + CNS.destinationRadius, "navigate()", Logger.severity.DEBUG);
									myLand = new Lander(this);
									myLand.landGrid(pitch, yaw); // start landing
								}
								else // CNS.match_direction != null
								{
									myLand = new Lander(this);
									myLand.matchOrientation(); // start match
								}
							}
						}
						else if (CNS.moveState != NavSettings.Moving.STOP_MOVE)
						{
							log("stopping at destination");
							fullStop();
							CNS.moveState = NavSettings.Moving.STOP_MOVE;
						}
					}
			}
			else // not at destination
			{
				collisionCheckMoveAndRotate(pitch, yaw);
			}
		}

		internal void collisionCheckMoveAndRotate(double pitch, double yaw)
		{
			if (!CNS.isAMissile)
			{
				Collision.collisionAvoidResult currentAvoidResult = myCollisionObject.avoidCollisions(ref CNS, updateCount);
				switch (currentAvoidResult)
				{
					case Collision.collisionAvoidResult.NOT_FINISHED:
						break;
					case Collision.collisionAvoidResult.NOT_PERFORMED:
						break;
					case Collision.collisionAvoidResult.ALTERNATE_PATH:
						CNS.noWayForward = false;
						log("got a currentAvoidResult " + currentAvoidResult + ", new waypoint is " + CNS.getWayDest(), "navigate()", Logger.severity.TRACE);
						CNS.collisionUpdateSinceWaypointAdded++;
						break;
					case Collision.collisionAvoidResult.NO_WAY_FORWARD:
						log("got a currentAvoidResult " + currentAvoidResult, "navigate()", Logger.severity.INFO);
						CNS.collisionUpdateSinceWaypointAdded++;
						CNS.noWayForward = true;
						reportState(ReportableState.NO_PATH);
						fullStop();
						return;
					case Collision.collisionAvoidResult.NO_OBSTRUCTION:
						CNS.noWayForward = false;
						CNS.collisionUpdateSinceWaypointAdded++;
						break;
					default:
						alwaysLog(Logger.severity.ERROR, "navigate()", "Error: unsuitable case from avoidCollisions(): " + currentAvoidResult);
						fullStop();
						return;
				}
			}
			calcMoveAndRotate(pitch, yaw);
		}

		private static byte collisionUpdatesBeforeMove = 1;

		private void calcMoveAndRotate(double pitch, double yaw)
		{
			//log("entered calcMoveAndRotate(" + pitch + ", " + yaw + ", " + CNS.getWayDest() + ")", "calcMoveAndRotate()", Logger.severity.TRACE);

			if (CNS.noWayForward)
				return;

			if (!CNS.isAMissile && (CNS.moveState == NavSettings.Moving.MOVING || CNS.moveState == NavSettings.Moving.SIDELING))
			{
				//log("getting stopping distance", "calcMoveAndRotate()", Logger.severity.TRACE);
				double stoppingDistance = currentThrust.getStoppindDistance();
				double distanceToDestination = distRCtoWayDest;
				if (CNS.moveState == NavSettings.Moving.SIDELING)
					distanceToDestination = getDistNavToWayDest();

				//log("got stopping distance: " + stoppingDistance + ", distanceToDestination: " + distanceToDestination + ", CNS.getTypeOfWayDest(): " + CNS.getTypeOfWayDest(), "calcMoveAndRotate()", Logger.severity.TRACE);

				switch (CNS.getTypeOfWayDest())
				{
					case NavSettings.TypeOfWayDest.BLOCK:
					case NavSettings.TypeOfWayDest.GRID:
					case NavSettings.TypeOfWayDest.LAND:
						if (CNS.moveState == NavSettings.Moving.MOVING)
							distanceToDestination = CNS.getDistanceToDestGrid();
						goto case NavSettings.TypeOfWayDest.COORDINATES;
					case NavSettings.TypeOfWayDest.OFFSET: // run collision avoidance on aproach rather than slowdown. see CollisionAvoidance..ctor
					case NavSettings.TypeOfWayDest.WAYPOINT:
						if (distanceToDestination < 0)
						{
							log("speed control: distance < 0 : " + distanceToDestination, "calcMoveAndRotate()", Logger.severity.INFO);
							fullStop();
							return;
						}
						if (distanceToDestination < stoppingDistance && movementSpeed > CNS.speedSlow_minimum) // less slowdown on aproaching waypoint, TODO remove slowdown when waypoint skip is available
						{
							log("speed control: aproaching waypoint (" + distanceToDestination + ", " + stoppingDistance + "), setting speed limit=" + (float)(movementSpeed * 0.9), "simpleMoveOrRotate()", Logger.severity.TRACE);
							float speedSlow = (float)(movementSpeed * 0.9);
							CNS.speedSlow_internal = speedSlow;
							CNS.speedCruise_internal = speedSlow / 2;
						}
						break;
					case NavSettings.TypeOfWayDest.COORDINATES:
						if (distanceToDestination < 0)
						{
							log("speed control: distance < 0: " + distanceToDestination, "calcMoveAndRotate()", Logger.severity.INFO);
							fullStop();
							return;
						}
						if (distanceToDestination < 2 * stoppingDistance && movementSpeed > CNS.speedSlow_minimum)
						{
							log("speed control: on aproach (" + distanceToDestination + ", " + stoppingDistance + "), setting speed limit=" + (float)(movementSpeed * 0.9), "simpleMoveOrRotate()", Logger.severity.TRACE);
							float speedSlow = (float)(movementSpeed * 0.9);
							CNS.speedSlow_internal = speedSlow;
							CNS.speedCruise_internal = speedSlow / 2;
						}
						break;
				}
			}

			Vector2 rot = new Vector2((float)pitch, (float)yaw);
			float rotLengthSq = Math.Abs(rot.LengthSquared());
			checkAndCruise();
			//log("reached missile check", "calcMoveAndRotate()", Logger.severity.TRACE);

			if (CNS.isAMissile)
			{
				if (CNS.moveState == NavSettings.Moving.SIDELING)
					fullStop();
				else // calcAndMove() will not run while sideling
					if (rotLengthSq < rotLenSq_startMissile)
						calcAndMove();
			}
			else // not a missile
			{
				if (CNS.moveState == NavSettings.Moving.SIDELING)
				{
					//log("reached inflight sidel", "calcMoveAndRotate()", Logger.severity.TRACE);
					//CNS.nextMoveSidel = true;
					calcAndMove(true);
				}
				else
					if (CNS.moveState == NavSettings.Moving.NOT_MOVE && CNS.rotateState == NavSettings.Rotating.NOT_ROTA && CNS.collisionUpdateSinceWaypointAdded >= collisionUpdatesBeforeMove)
					{
						//log("checking distance", "calcMoveAndRotate()", Logger.severity.TRACE);
						if (distRCtoWayDest < myGridDim.getLongestDim() + CNS.destinationRadius)
							calcAndMove(true);
						else
							if (rotLengthSq < rotLenSq_startMove)
								calcAndMove();
					}
			}

			if (CNS.moveState != NavSettings.Moving.SIDELING)
				calcAndRotate(pitch, yaw);

			//if (CNS.moveState == NavSettings.Moving.MOVING && CNS.rotateState == NavSettings.Rotating.NOT_ROTA && movementSpeed < CNS.getSpeedCruise())
			//{
			//	jumpToDestination();
			//}
		}

		/// <summary>
		/// start moving when less than
		/// </summary>
		private static float rotLenSq_startMove = 1f;
		/// <summary>
		/// start moving when less than, for missile
		/// </summary>
		private static float rotLenSq_startMissile = 4f;
		/// <summary>
		/// inflight rotate when greater than
		/// </summary>
		internal static float rotLenSq_inflight = 0.01f;
		/// <summary>
		/// stop and rotate when greater than
		/// </summary>
		private static float rotLenSq_stopAndRot = 16f;

		private Vector3 moveDirection = Vector3.Zero;

		/// <summary>
		/// only needed to start movement, does not handle stopping/slowing
		/// </summary>
		/// <param name="doSidel"></param>
		/// <param name="anyState">do not check moveState</param>
		private void calcAndMove(bool sidel= false)//, bool anyState=false)
		{
			//log("entered calcAndMove("+doSidel+")", "calcAndMove()", Logger.severity.TRACE);
			//if (anyState || CNS.moveState == NavSettings.Moving.SIDELING || (CNS.moveState == NavSettings.Moving.NOT_MOVE && CNS.rotateState == NavSettings.Rotating.NOT_ROTA))
			//{
			if (sidel)
			{
				Vector3 worldDisplacement = ((Vector3D)CNS.getWayDest() - (Vector3D)getNavigationBlock().GetPosition());
				//Vector3 RCdisplacement = GridWorld.relative_worldToBlock(currentRCblock, worldDisplacement);
				//Vector3 RCdirection = Vector3.Normalize(RCdisplacement);

				RelativeVector3 displacement = RelativeVector3.createFromWorld(worldDisplacement, myGrid);
				Vector3 RCdirection = Vector3.Normalize(displacement.getBlock(currentRCblock));
				//Vector3I destination = myGrid.WorldToGridInteger((Vector3D)CNS.getWayDest()) - getNavigationBlock().Position;
				//Vector3 direction = Vector3.Normalize((Vector3)GridWorld.relative_worldToBlock(currentRCblock, destination));
				//log("back from GridWorld, destination=" + destination + ", relative_worldToBlock=" + GridWorld.relative_worldToBlock(currentRCblock, destination));
				//Vector3I displacement = destination - getNavigationBlock().Position + myGridDim.myRC.Position;
				//direction = Vector3D.Normalize((Vector3D)direction);// *0.1;
				//if (direction.LengthSquared() < 0.01)
					//return;
				//log("three 'D's : " + destination + /*", " + displacement +*/ ", " + direction, "calcAndMove()", Logger.severity.TRACE);
				if (CNS.moveState == NavSettings.Moving.SIDELING)
				{ 
					//log("inflight adjust sidel " + direction + " for " + displacement + " to " + destination, "calcAndMove()", Logger.severity.TRACE);
					if (Math.Abs(moveDirection.X - RCdirection.X) < 0.1 && Math.Abs(moveDirection.Y - RCdirection.Y) < 0.1 && Math.Abs(moveDirection.Z - RCdirection.Z) < 0.1)
					{
						//log("cancel inflight adjustment: no change", "calcAndMove()", Logger.severity.TRACE);
						return;
					}
					else
					{
						log("sidel, stop to change course", "calcAndMove()", Logger.severity.TRACE);
						fullStop();
						return;
					}
				}
				else // other state
				{
					//log("destination=" + destination + ", getNavigationBlock().DefinitionDisplayNameText=" + getNavigationBlock().DefinitionDisplayNameText + ", getNavigationBlock().Position=" + getNavigationBlock().Position + ", myGridDim.myRC.Position=" + myGridDim.myRC.Position, "calcAndMove()", Logger.severity.TRACE);
					RelativeVector3 scaled = currentThrust.scaleByForce(displacement, currentRCblock);
					log("sideling. wayDest=" + CNS.getWayDest() + ", worldDisplacement=" + worldDisplacement+", RCdirection=" + RCdirection, "calcAndMove()", Logger.severity.DEBUG);
					log("... scaled=" + scaled.getWorld()+":" + scaled.getGrid() + ":" + scaled.getBlock(currentRCblock), "calcAndMove()", Logger.severity.DEBUG);
					//log("sidel " + direction +" scaled to "+scaled+ /*" for " + displacement + */" to " + destination, "calcAndMove()", Logger.severity.DEBUG); // + " world: " + myGridDim.getRCworld() + " to " + CNS.getWayDest());
					moveDirection = RCdirection;
					moveOrder(scaled);
					CNS.moveState = NavSettings.Moving.SIDELING;
				}
			}
			else
			{
				moveOrder(Vector3.Forward); // move forward
				log("moving " + distRCtoWayDest + " to " + CNS.getWayDest(), "calcAndMove()", Logger.severity.DEBUG);
				CNS.moveState = NavSettings.Moving.MOVING;

				//log("CNS.jump_to_dest=" + CNS.jump_to_dest + ", distanceToWaypoint=" + distanceToWaypoint);
				//if (CNS.jump_to_dest && distanceToWaypoint > 1000)
				//{
				//	jumpToDestination();
				//	return;
				//}
			}

			reportState(ReportableState.MOVING);
			stoppedMovingAt = DateTime.UtcNow + stoppedAfter;
			return;
			//}
			//else
			//	log("no can do, wrong state: " + CNS.moveState + ", " + CNS.rotateState, "calcAndMove()", Logger.severity.TRACE);
		}

		/// <summary>
		/// for simplicity's sake, this method shall only use current remote control
		/// </summary>
		/// <param name="dirNorm">which direction the remote control should face</param>
		/// <param name="pitch"></param>
		/// <param name="yaw"></param>
		internal void getRotationC(Vector3D dirNorm, out double pitch, out double yaw)
		{
			//Sandbox.ModAPI.IMyCubeBlock navigationBlock = getNavigationBlock();
			pitch = currentRCblock.WorldMatrix.Down.Dot(dirNorm);
			yaw = currentRCblock.WorldMatrix.Right.Dot(dirNorm);

			double forward = currentRCblock.WorldMatrix.Forward.Dot(dirNorm);
			//log("amount forward(" + forward + ") = RCfore(" + currentRCblock.WorldMatrix.Forward + ") . dirNorm(" + dirNorm + ")", "getRotationC()", Logger.severity.TRACE);

			if (forward < 0) // destination is behind myGrid
			{
				double yO = yaw;
				if (yaw > 0)
					yaw = 1;//2 - rotY;
				else
					yaw = -1;// -2 - rotY;
				//log("changing y from " + yO + " to " + rotY, "getRotationC()", Logger.severity.TRACE);
			}

			if (CNS.moveState == NavSettings.Moving.MOVING)
			{
				pitch *= inflightRotatingPower;
				yaw *= inflightRotatingPower;
			}
			else
			{
				pitch *= rotationPower;
				yaw *= rotationPower;
			}
		}

		private double pitchRotatePast;
		private double yawRotatePast;

		/// <summary>
		/// 
		/// </summary>
		/// <param name="pitch"></param>
		/// <param name="yaw"></param>
		/// <param name="precision_stopAndRot">for increasing precision of rotLenSq_stopAndRot</param>
		internal void calcAndRotate(double pitch, double yaw, float? precision_stopAndRot=null){
			Vector2 rot = new Vector2((float)pitch, (float)yaw);
			float rotLengthSq = Math.Abs(rot.LengthSquared());
			if (precision_stopAndRot == null)
				precision_stopAndRot = rotLenSq_stopAndRot;

			//log("need to rotate "+rot.Length());
			// need to rotate
			switch (CNS.rotateState)
			{
				case NavSettings.Rotating.NOT_ROTA:
					{
						switch (CNS.moveState)
						{
							case NavSettings.Moving.MOVING:
								{
									if (rotLengthSq < rotLenSq_inflight)
										return;
									if (rotLengthSq > precision_stopAndRot)
									{
										log("stopping to rotate");
										fullStop();
										return;
									}
									else
									{// make a small, inflight adjustment
										pitchRotatePast = pitchNeedToRotate / 4;
										yawRotatePast = yawNeedToRotate / 4;
										pitchNeedToRotate = pitch + pitchRotatePast;
										yawNeedToRotate = yaw + yawRotatePast;
										if (Math.Abs(pitchNeedToRotate) < rotLenSq_inflight)
											pitchNeedToRotate = 0;
										if (Math.Abs(yawNeedToRotate) < rotLenSq_inflight)
											yawNeedToRotate = 0;
										if (pitchNeedToRotate == 0 && yawNeedToRotate == 0)
											return;
										log("need to adjust: " + pitch + ", " + yaw);
										changeRotationPower = !changeRotationPower;
										rotateOrder(rot); // rotate towards target
										CNS.rotateState = NavSettings.Rotating.ROTATING;
										maxRotateTime = DateTime.UtcNow.AddSeconds(3);
										return;
									}
								}
							case NavSettings.Moving.NOT_MOVE:
								{
									if (!CNS.isAMissile && CNS.collisionUpdateSinceWaypointAdded < collisionUpdatesBeforeMove)
										return;
									pitchRotatePast = 0;
									yawRotatePast = 0;
									pitchNeedToRotate = pitch;
									yawNeedToRotate = yaw;
									if (Math.Abs(pitchNeedToRotate) < rotLenSq_inflight)
										pitchNeedToRotate = 0;
									if (Math.Abs(yawNeedToRotate) < rotLenSq_inflight)
										yawNeedToRotate = 0;
									if (pitchNeedToRotate == 0 && yawNeedToRotate == 0)
										return;
									reportState(ReportableState.ROTATING);
									log("starting rotation: " + pitch + ", " + yaw+", updates="+collisionUpdatesBeforeMove);
									changeRotationPower = !changeRotationPower;
									rotateOrder(rot); // rotate towards target
									CNS.rotateState = NavSettings.Rotating.ROTATING;
									maxRotateTime = DateTime.UtcNow.AddSeconds(10);
									return;
								}
						}
						return;
					}
				case NavSettings.Rotating.STOP_ROTA:
					{
						if (isNotRotating())
						{
							adjustRotationPower(pitch, yaw);
							pitchNeedToRotate = 0;
							yawNeedToRotate = 0;
							CNS.rotateState = NavSettings.Rotating.NOT_ROTA;
						}
						return;
					}
				case NavSettings.Rotating.ROTATING:
					{
						// check for need to derotate
						pitch += pitchRotatePast;
						yaw += yawRotatePast;
						float whichDecelRot;
						if (CNS.moveState == NavSettings.Moving.MOVING)
							whichDecelRot = inflightDecelerateRotation;
						else
							whichDecelRot = decelerateRotation;
						if ((pitchNeedToRotate > rotLenSq_inflight && pitch < pitchNeedToRotate * whichDecelRot)
							|| (pitchNeedToRotate < -rotLenSq_inflight && pitch > pitchNeedToRotate * whichDecelRot)
							|| (yawNeedToRotate > rotLenSq_inflight && yaw < yawNeedToRotate * whichDecelRot)
							|| (yawNeedToRotate < -rotLenSq_inflight && yaw > yawNeedToRotate * whichDecelRot)
							|| DateTime.UtcNow.CompareTo(maxRotateTime) > 0)
						{
							log("decelerate rotation (" + pitch + ", " + yaw + ", " + pitchNeedToRotate + ", " + yawNeedToRotate + ")");
							rotateOrder(Vector2.Zero); // stop rotating
							CNS.rotateState = NavSettings.Rotating.STOP_ROTA;
						}
						return;
					}
			}
		}

		private float needToRoll = 0;
		private float? lastRoll = null;
		private DateTime stoppedRollingAt = DateTime.UtcNow;

		/// <summary>
		/// does not check for moving or rotating
		/// </summary>
		/// <param name="roll"></param>
		internal void calcAndRoll(float roll)
		{
			switch (CNS.rollState)
			{
				case NavSettings.Rolling.NOT_ROLL:
					{
						log("rollin' rollin' rollin' " + roll, "calcAndRoll()", Logger.severity.DEBUG);
						needToRoll = roll;
						rollOrder(roll);
						CNS.rollState = NavSettings.Rolling.ROLLING;
						maxRotateTime = DateTime.UtcNow.AddSeconds(3);
						reportState(ReportableState.ROTATING);
					}
					return;
				case NavSettings.Rolling.ROLLING:
					{
						if (Math.Sign(roll) * Math.Sign(needToRoll) <= 0 || Math.Abs(roll) < Math.Abs(needToRoll) * decelerateRotation || DateTime.UtcNow.CompareTo(maxRotateTime) > 0)
						{
							//log("Math.Sign(roll) = " + Math.Sign(roll) + ", Math.Sign(needToRoll) = " + Math.Sign(needToRoll) + ", Math.Abs(roll) = " + Math.Abs(roll) + ", Math.Abs(needToRoll) = " + Math.Abs(needToRoll)
							//	+ ", decelerateRotation = " + decelerateRotation + ", DateTime.UtcNow = " + DateTime.UtcNow + ", maxRotateTime = " + maxRotateTime);
							log("decelerate roll, roll="+roll+", needToRoll="+needToRoll, "calcAndRoll()", Logger.severity.DEBUG);
							rollOrder(0);
							CNS.rollState = NavSettings.Rolling.STOP_ROLL;
						}
					}
					return;
				case NavSettings.Rolling.STOP_ROLL:
					{
						if (lastRoll == null || lastRoll != roll) // is rolling
						{
							stoppedRollingAt = DateTime.UtcNow + stoppedAfter;
							lastRoll = roll;
						}
						else // stopped rolling
							if (DateTime.UtcNow.CompareTo(stoppedRollingAt) > 0)
							{
								log("get off the log (done rolling) ", "calcAndRoll()", Logger.severity.DEBUG);
								lastRoll = null;
								CNS.rollState = NavSettings.Rolling.NOT_ROLL;
							}
					}
					return;
			}
		}

		private void jumpToDestination()
		{
			log("jumping to "+CNS.getWayDest(), "jumpToDestination()", Logger.severity.INFO);
			myGrid.SetPosition((Vector3D)CNS.getWayDest());
		}

		internal float rotationPower = 3f;
		private float decelerateRotation = 1f / 2f; // how much of rotation should be deceleration
		private float inflightRotatingPower = 3;
		private float inflightDecelerateRotation = 1f / 2f;

		private static float decelerateAdjustmentOver = 1.15f; // adjust decelerate by this much when overshoot
		private static float decelerateAdjustmentUnder = 0.90f; // adjust decelerate by this much when undershoot
		private static float rotationPowerAdjustmentOver = 0.85f;
		private static float rotationPowerAdjustmentUnder = 1.10f;

		private void adjustRotationPower(double x, double y)
		{
			int overUnder = 0;
			//	check for overshoot/undershoot
			if (Math.Abs(x) > 0.1 && Math.Abs(pitchNeedToRotate) > 0.1)
				if (Math.Sign(x) == Math.Sign(pitchNeedToRotate)) // same sign
					//if ((x > 0 && needToRotateX > 0) || (x < 0 && needToRotateX < 0))
					overUnder--;
				else // different sign
					overUnder++;
			if (Math.Abs(y) > 0.1 && Math.Abs(yawNeedToRotate) > 0.1)
				if (Math.Sign(y) == Math.Sign(yawNeedToRotate)) // same sign
					//if ((y > 0 && needToRotateY > 0) || (y < 0 && needToRotateY < 0))
					overUnder--;
				else // different sign
					overUnder++;

			if (overUnder != 0)
			{
				log("checking for over/under shoot on rotation: x=" + x + ", needX=" + pitchNeedToRotate + ", y=" + y + ", needY=" + yawNeedToRotate);
				if (overUnder > 0) // over rotated
					if (changeRotationPower)
						adjustRotationPowerBy(rotationPowerAdjustmentOver);
					else
						adjustRotationPowerBy(decelerateAdjustmentOver);
				else // under rotated
					if (changeRotationPower)
						adjustRotationPowerBy(rotationPowerAdjustmentUnder);
					else
						adjustRotationPowerBy(decelerateAdjustmentUnder);

				log("power adjusted, under/over is " + overUnder + " x=" + x + "/" + pitchNeedToRotate + ", y=" + y + "/" + yawNeedToRotate);
			}
		}

		private bool changeRotationPower;

		private void adjustRotationPowerBy(float adjustBy)
		{
			if (changeRotationPower)
			{
				if (CNS.moveState == NavSettings.Moving.MOVING)
				{
					inflightRotatingPower *= adjustBy;
					log("adjusted inflightRotatingPower, new value is " + inflightRotatingPower, "adjustRotationPowerBy", Logger.severity.DEBUG);
				}
				else
				{
					rotationPower *= adjustBy;
					log("adjusted rotationPower, new value is " + rotationPower, "adjustRotationPowerBy", Logger.severity.DEBUG);
				}
			}
			else
			{
				if (CNS.moveState == NavSettings.Moving.MOVING)
				{
					inflightDecelerateRotation *= adjustBy;
					log("adjusted inflightDecelerateRotation, new value is " + inflightDecelerateRotation, "adjustRotationPowerBy", Logger.severity.DEBUG);
				}
				else
				{
					decelerateRotation *= adjustBy;
					log("adjusted decelerateRotation, new value is " + decelerateRotation, "adjustRotationPowerBy", Logger.severity.DEBUG);
				}
			}
		}

		private void capFloat(ref float value, float min, float max)
		{
			if (value < min)
			{
				//alwaysLog(Logger.severity.WARNING, "capFloat", "value too low " + value + " < " + min, CNS.moveState.ToString(), CNS.rotateState.ToString());
				value = min;
			}
			else if (value > max)
			{
				//alwaysLog(Logger.severity.WARNING, "capFloat", "value too high " + value + " > " + max, CNS.moveState.ToString(), CNS.rotateState.ToString());
				value = max;
			}
		}

		private static TimeSpan stoppedAfter = new TimeSpan(0, 0, 0, 1);
		private DateTime stoppedMovingAt;

		private void checkStopped()
		{
			if (CNS.moveState == NavSettings.Moving.NOT_MOVE)
				return;

			bool isStopped;

			//log("checking movementSpeed "+movementSpeed, "checkStopped()", Logger.severity.TRACE);
			if (movementSpeed == null || movementSpeed > 0.1f)
			{
				//log("fast", "checkStopped()", Logger.severity.TRACE);
				stoppedMovingAt = DateTime.UtcNow + stoppedAfter;
				isStopped = false;
			}
			else
			{
				//log("stopped in " + (stoppedMovingAt - DateTime.UtcNow).TotalMilliseconds, "checkStopped()", Logger.severity.TRACE);
				isStopped = DateTime.UtcNow > stoppedMovingAt;
			}

			if (isStopped)
			{
				if (CNS.moveState == NavSettings.Moving.STOP_MOVE)
					//log("now stopped");
					CNS.moveState = NavSettings.Moving.NOT_MOVE;
				else //if (CNS.moveState == NavSettings.Moving.MOVING)
					CNS.moveState = NavSettings.Moving.STOP_MOVE;
			}
		}

		private DateTime stoppedRotatingAt;
		/// <summary>
		/// this is based on ship forward
		/// </summary>
		private Vector3D? facing = null;

		private static float notRotPrecision = 0.01f;

		private bool isNotRotating()
		{
			Vector3D origin = myGrid.GetPosition();
			Vector3D forward = myGrid.GridIntegerToWorld(Vector3I.Forward);
			Vector3D currentFace = forward - origin;

			bool currentlyRotating;
			if (facing == null)
				currentlyRotating = true;
			else
			{
				Vector3D prevFace = (Vector3D)facing;
				if (Math.Abs(currentFace.X - prevFace.X) > notRotPrecision || Math.Abs(currentFace.Y - prevFace.Y) > notRotPrecision || Math.Abs(currentFace.Z - prevFace.Z) > notRotPrecision)
				{
					currentlyRotating = true;
					//log("rotating at this instant, dx=" + Math.Abs(currentFace.X - prevFace.X) + ", dy=" + Math.Abs(currentFace.Y - prevFace.Y) + ", dz=" + Math.Abs(currentFace.Z - prevFace.Z) + ", S.A.=" + stoppedRotatingAt, "isNotRotating()", Logger.severity.TRACE);
				}
				else
				{
					currentlyRotating = false;
					//log("not rotating at this instant, dx=" + Math.Abs(currentFace.X - prevFace.X) + ", dy=" + Math.Abs(currentFace.Y - prevFace.Y) + ", dz=" + Math.Abs(currentFace.Z - prevFace.Z) + ", S.A.=" + stoppedRotatingAt, "isNotRotating()", Logger.severity.TRACE);
				}
			}
			facing = currentFace;

			if (currentlyRotating)
			{
				//log("rotating");
				stoppedRotatingAt = DateTime.UtcNow + stoppedAfter;
				return false;
			}
			else
				return DateTime.UtcNow > stoppedRotatingAt;
		}

		//private double startOfDecelMeasureSpeed = 0;
		//private Vector3D? startOfDecelMeasureVec = null;

		/// <summary>
		/// for other kinds of stop use moveOrder(Vector3.Zero) or similar
		/// </summary>
		internal void fullStop()
		{
			reportState(ReportableState.STOPPING);
			log("full stop");
			currentMove = Vector3.Zero;
			currentRotate = Vector2.Zero;
			currentRoll = 0;
			CNS.clearSpeedInternal();

			setDampeners();
			currentRCcontrol.MoveAndRotateStopped();

			//if (movementSpeed > 1 && CNS.moveState == NavSettings.Moving.MOVING)
			//{
			//	//CNS.moveState = NavSettings.Moving.STOPING_M;
			//	startOfDecelMeasureSpeed = (double)movementSpeed;
			//	startOfDecelMeasureVec = currentPos;
			//}
			CNS.moveState = NavSettings.Moving.STOP_MOVE;
			CNS.rotateState = NavSettings.Rotating.STOP_ROTA;
			pitchNeedToRotate = 0;
			yawNeedToRotate = 0;
		}

		private Vector3 currentMove = Vector3.Zero;
		private Vector2 currentRotate = Vector2.Zero;
		private float currentRoll = 0;

		private void moveOrder(Vector3 move)
		{
			//log("entered moveOrder("+move+")");
			move = Vector3.Normalize(move);
			if (!Vector3.IsValid(move))
				move = Vector3.Zero;
			if (currentMove == move)
				return;
			currentMove = move;
			moveAndRotate();
		}

		private void moveOrder(RelativeVector3 move)
		{
			moveOrder(move.getBlock(currentRCblock));
		}

		private void rotateOrder(Vector2 rotate)
		{
			//log("entered rotateOrder("+rotate+")");
			if (currentRotate == rotate)
				return;
			currentRotate = rotate;
			moveAndRotate();
		}

		private void rollOrder(float roll)
		{
			//log("entered rollOrder("+roll+")");
			if (currentRoll == roll)
				return;
			currentRoll = roll;
			moveAndRotate();
		}

		private void moveAndRotate()
		{
			//isCruising = false;
			if (currentMove == Vector3.Zero && currentRotate == Vector2.Zero && currentRoll == 0)
			{
				log("MAR is actually stop");
				currentRCcontrol.MoveAndRotateStopped();
			}
			else
			{
				log("doing MAR(" + currentMove + ", " + currentRotate + ", " + currentRoll + ")");
				currentRCcontrol.MoveAndRotate(currentMove, currentRotate, currentRoll);
			}
		}

		private bool dampenersOn()
		{
			return ((myGrid.GetObjectBuilder() as MyObjectBuilder_CubeGrid).DampenersEnabled);
		}

		internal void setDampeners(bool dampenersOn = true)
		{
			if ((myGrid.GetObjectBuilder() as MyObjectBuilder_CubeGrid).DampenersEnabled != dampenersOn)
			{
				currentRCcontrol.SwitchDamping();
				if (!dampenersOn)
					log("speed control: disabling dampeners. speed=" + movementSpeed + ", cruise=" + CNS.getSpeedCruise() + ", slow=" + CNS.getSpeedSlow(), "setDampeners()", Logger.severity.TRACE);
				else
					log("speed control: enabling dampeners. speed=" + movementSpeed + ", cruise=" + CNS.getSpeedCruise() + ", slow=" + CNS.getSpeedSlow(), "setDampeners()", Logger.severity.TRACE);
			}
		}

		private static Vector3 cruiseForward = new Vector3(0, 0, -0.001); // hopefully this minimum is consistent
		/// <summary>
		/// call every run, needed to enable dampeners
		/// two options for cruise: use cruiseForward, or disable dampeners
		/// </summary>
		private void checkAndCruise() //float rotLengthSq)
		{
			//log("entered checkAndCruise, speed="+movementSpeed+", slow="+CNS.getSpeedSlow()+", cruise="+CNS.getSpeedCruise());

			switch (CNS.moveState)
			{
				case NavSettings.Moving.MOVING:
				case NavSettings.Moving.SIDELING:
					break; // continue method
				default:
					setDampeners();
					return;
			}
			/*if (CNS.moveState != NavSettings.Moving.MOVING)
			{
				setDampeners();
				return;
			}*/

			if (movementSpeed > CNS.getSpeedSlow())
			{
				setDampeners();
				moveOrder(Vector3.Zero);
				return;
			}
			if (movementSpeed < CNS.getSpeedCruise())
			{
				// as long as there is acceleration, do not calcAndMove
				if (currentMove == Vector3.Zero)
				{
					setDampeners();
					calcAndMove(CNS.moveState == NavSettings.Moving.SIDELING);
				}
				return;
			}

			// between cruise and slow speed
			if (CNS.rotateState == NavSettings.Rotating.NOT_ROTA) // as long as state change comes after checkAndCruise, this will work
			{
				// disable dampeners
				setDampeners(false);
				moveOrder(Vector3D.Zero);
				return;
			}
			else
			{
				// use cruise vector
				moveOrder(cruiseForward);
				setDampeners();
				return;
			}
		}

		//private static double decelMeasureCoefficient = 1f;

		//private double getStoppingDistance(double? speed)
		//{
		//	// TODO sideling / actually calculate

		//	//if (CNS.decelMeasureCoefficient >= 0.1)
		//	return decelMeasureCoefficient * (double)speed;
		//	//else
		//	//return moveDistance * decelerateMovement;
		//}

		public override string ToString()
		{
			return "Nav:" + myGrid.DisplayName;
		}

		public enum ReportableState : byte { OFF, PATHFINDING, ROTATING, MOVING, STOPPING, NO_PATH, NO_DEST, MISSILE, ENGAGING, LANDED, PLAYER };
		private ReportableState currentReportable = ReportableState.OFF;

		/// <summary>
		/// may ignore the given state, if Nav is actually in another state
		/// </summary>
		/// <param name="newState"></param>
		internal void reportState(ReportableState newState)
		{
			//log("entered reportState()", "reportState()", Logger.severity.TRACE);
			if (currentRemoteControl_Value == null)
			{
				//log("cannot report without RC", "reportState()", Logger.severity.TRACE);
				return;
			}

			string displayName = (currentRemoteControl_Value as Sandbox.ModAPI.IMyCubeBlock).DisplayNameText;
			if (displayName == null)
			{
				alwaysLog(Logger.severity.WARNING, "reportState()", "cannot report without display name");
				return;
			}

			if (CNS.noWayForward)
			{
				//log("changing report to NO_PATH(noWayForward)", "reportState()", Logger.severity.TRACE);
				newState = ReportableState.NO_PATH;
			}
			if (CNS.EXIT)
			{
				newState = ReportableState.OFF;
			}
			if (CNS.landingState == NavSettings.LANDING.LOCKED)
				newState = ReportableState.LANDED;

			// did state actually change?
			if (newState == currentReportable)
				return;
			currentReportable = newState;

			// cut old state, if any
			int endOfState = displayName.IndexOf('>');
			if (endOfState != -1)
				displayName = displayName.Substring(endOfState + 1);

			// add new state
			StringBuilder newName = new StringBuilder();
			newName.Append('<');
			newName.Append(newState);
			newName.Append('>');
			newName.Append(displayName);
			//RCDisplayName = newName.ToString();

			//ignore_RemoteControl_nameChange = true;
			(currentRemoteControl_Value as Ingame.IMyRemoteControl).SetCustomName(newName);
			//ignore_RemoteControl_nameChange = false;
			log("added ReportableState to RC: " + newState, "reportState()", Logger.severity.TRACE);
		}

		//private bool ignore_RemoteControl_nameChange = false;
		private string instructions;
		private void remoteControl_OnNameChanged(Sandbox.ModAPI.IMyTerminalBlock whichBlock)
		{
			string instructionsInBlock = getInstructionsFromRC(whichBlock as Sandbox.ModAPI.IMyCubeBlock);
			if (instructions == null || !instructions.Equals(instructionsInBlock))
			{
				log("RC name changed: " + whichBlock.CustomName+"; inst were: "+instructions+"; are now: "+instructionsInBlock, "remoteControl_OnNameChanged()", Logger.severity.DEBUG);
				instructions = instructionsInBlock;
				remoteControlIsNotReady = true;
				reset();
				CNS.waitUntilNoCheck = DateTime.UtcNow.AddSeconds(1);
			}
		}

		private static string getInstructionsFromRC(Sandbox.ModAPI.IMyCubeBlock rc)
		{
			string displayName = rc.DisplayNameText;
			int start = displayName.IndexOf('[') + 1;
			int end = displayName.IndexOf(']');
			if (start > 0 && end > start) // has appropriate brackets
			{
				int length = end - start;
				return displayName.Substring(start, length);
			}
			return null;
		}

		private static string getRCNameOnly(IMyCubeBlock rc)
		{
			string displayName = rc.DisplayNameText;
			int start = displayName.IndexOf('>') + 1;
			int end = displayName.IndexOf('[');
			if (start > 0 && end > start)
			{
				int length = end - start;
				return displayName.Substring(start, length);
			}
			if (end > 0)
			{
				return displayName.Substring(0, end);
			}
			return null;
		}
	}
}
