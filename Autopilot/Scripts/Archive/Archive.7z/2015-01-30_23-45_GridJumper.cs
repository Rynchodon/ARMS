﻿#define LOG_ENABLED //remove on build

using System;
using System.Collections.Generic;
//using System.Linq;
//using System.Text;

using Sandbox.Common;
using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.ModAPI;
using Ingame = Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;

using VRageMath;

namespace Rynchodon.Autopilot.Jumper
{
	public class GridJumper
	{
		public enum State : byte { OFF, CHARGING, READY, SUCCESS, FAILED }
		public State currentState = State.OFF;

		private static int jumpEnergyDivisor = 100;
		private static float setGravity_On = 0.01f;

		// values from CubeBlocks.sbc
		/// <summary>
		/// in Watts
		/// </summary>
		private static float largeChargerOutput = 1000 * 1000, smallChargerOutput = 100 * 1000;
		private static float BasePowerInput = 1000;
		private static float ConsumptionPower = 3;

		/// <summary>
		/// in Watts
		/// </summary>
		private float mySizeChargerOutput;

		private IMyCubeGrid myGrid;
		private Vector3D destination;

		private List<JumpDrive> allJumpDrives;
		private List<JumpCharger> allJumpChargers;

		private Logger myLogger;
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{ alwaysLog(toLog, method, level); }
		private void alwaysLog(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			if (myLogger == null) myLogger = new Logger(myGrid.DisplayName, "GridJumper");
			myLogger.log(level, method, toLog);
		}

		public GridJumper(IMyCubeGrid grid, Vector3D destination)
		{
			this.myGrid = grid;
			this.destination = destination;

			if (myGrid.GridSizeEnum == MyCubeSize.Large)
				mySizeChargerOutput = largeChargerOutput;
			else
				mySizeChargerOutput = smallChargerOutput;

			allJumpDrives = new List<JumpDrive>();
			allJumpChargers = new List<JumpCharger>();

			List<IMySlimBlock> allBlocks = new List<IMySlimBlock>();
			myGrid.GetBlocks(allBlocks);//, block => block.FatBlock != null);
			foreach (IMySlimBlock block in allBlocks)
			{
				if (block.FatBlock == null)
					continue;
				//log("checking " + block.FatBlock.DisplayNameText + " for drive/charger", ".ctor()", Logger.severity.TRACE);
				if (block.FatBlock is Ingame.IMyBatteryBlock)
				{
					//log("... is a battery", ".ctor()", Logger.severity.TRACE);
					JumpCharger currentCharger;
					if (JumpCharger.tryGetJumpCharger(out currentCharger, block.FatBlock))
					{
						//log("JumpCharger is " + currentCharger, ".ctor()", Logger.severity.TRACE);
						allJumpChargers.Add(currentCharger);
						//log("added OK", ".ctor()", Logger.severity.TRACE);
					}
				}
				else if (block.FatBlock is Ingame.IMyGravityGeneratorSphere)
				{
					//log("... is a spherical generator", ".ctor()", Logger.severity.TRACE);
					JumpDrive currentDrive;
					if (JumpDrive.tryGetJumpDrive(out currentDrive, block.FatBlock))
						allJumpDrives.Add(currentDrive);
				}
			}
		}

		public bool canJump()
		{
			if (allJumpChargers.Count < 1 || allJumpDrives.Count < 1)
				return false;

			// energy available
			log("energy needed = "+getEnergyNeeded()+", energy available = "+getEnergyAvailable(), "canJump()", Logger.severity.DEBUG);
			if (getEnergyNeeded() > getEnergyAvailable())
				return false;

			// collision avoidance (speed is more important than getting close to the target)

			return true;
		}

		public bool trySetJump()
		{
			if (!canJump())
			{
				currentState = State.FAILED;
				return false;
			}

			// transfer energy
			// bring drives online
			foreach (JumpDrive drive in allJumpDrives)
			{
				drive.myBlock.IsWorkingChanged += drive_IsWorkingChanged;
				drive.gravity = setGravity_On;
				drive.enabled = true;
			}

			// bring chargers online
			foreach (JumpCharger charger in allJumpChargers)
			{
				charger.myBlock.IsWorkingChanged += charger_IsWorkingChanged;
				charger.producer = true;
			}

			log("starting to charge for "+destination, "trySetJump()", Logger.severity.INFO);
			currentState = State.CHARGING;
			timeLastCalculatePower = DateTime.UtcNow;
			return true;
		}

		public void stopCharging()
		{
			// take drives offline
			foreach (JumpDrive drive in allJumpDrives)
			{
				drive.myBlock.IsWorkingChanged -= drive_IsWorkingChanged;
				drive.gravity = 0;
				drive.radius = 0;
				drive.enabled = false;
			}

			// take chargers offline
			foreach (JumpCharger charger in allJumpChargers)
			{
				charger.myBlock.IsWorkingChanged -= charger_IsWorkingChanged;
				charger.producer = false;
			}
			currentState = State.OFF;
			log("stopped charging", "stopCharging()", Logger.severity.DEBUG);
		}

		public void update()
		{
			switch (currentState)
			{
				case State.OFF:
					{
						log("state is OFF", "update()", Logger.severity.TRACE);
						return;
					}
				case State.CHARGING:
					{
						calculatePower();
						log("energyTransfered=" + energyTransfered + ", energyNeeded=" + getEnergyNeeded(), "update()", Logger.severity.TRACE);
						if (energyTransfered >= getEnergyNeeded())
						{
							stopCharging();
							currentState = State.READY;
							log("finished charging successfully", "update()", Logger.severity.DEBUG);
						} return;
					}
			}
		}

		private float value__getEnergyNeeded = -1;
		/// <summary>
		/// mass * distance / jumpEnergyDivisor
		/// units: Wh
		/// </summary>
		/// <returns></returns>
		private float getEnergyNeeded()
		{
			if (value__getEnergyNeeded < 0)
			{
				float distance = (float)Math.Abs((myGrid.Physics.CenterOfMassWorld - destination).Length());
				value__getEnergyNeeded = myGrid.Physics.Mass * distance / jumpEnergyDivisor;
				log("distance=" + distance + ", mass=" + myGrid.Physics.Mass + ", EnergyNeeded=" + value__getEnergyNeeded, "getEnergyNeeded()", Logger.severity.TRACE);
			}
			return value__getEnergyNeeded;
		}

		private float value__getEnergyAvailable = -1;
		/// <summary>
		/// sum all the available energy in chargers
		/// units: Wh
		/// </summary>
		/// <returns></returns>
		private float getEnergyAvailable()
		{
			if (value__getEnergyAvailable < 0)
			{
				value__getEnergyAvailable = 0;
				foreach (JumpCharger charger in allJumpChargers)
				{
					value__getEnergyAvailable += charger.getEnergyStored() * 1000000; // stored is in MWh
					log("adding " + charger.getEnergyStored(), "getEnergyAvailable()", Logger.severity.TRACE);
				}
			}
			return value__getEnergyAvailable;
		}

		private int drivesOnline = 0;

		private void drive_IsWorkingChanged(IMyCubeBlock block)
		{
			calculatePower();
			if (block.IsWorking)
				drivesOnline++;
			else
				drivesOnline--;
			log("number of drives is now " + drivesOnline, "drive_IsWorkingChanged()", Logger.severity.TRACE);
			distributePower();
		}

		private int chargersOnline = 0;

		private void charger_IsWorkingChanged(IMyCubeBlock block)
		{
			calculatePower();
			if (block.IsWorking)
				chargersOnline++;
			else
				chargersOnline--;
			// TODO if too many chargers are online, take some down
			log("number of chargers is now " + chargersOnline, "charger_IsWorkingChanged()", Logger.severity.TRACE);
			distributePower();
		}

		/// <summary>
		/// if this is not reset, it may be possible to resume a jump, though it is likely we will need to allow for ship movement
		/// </summary>
		private float energyTransfered = 0;
		private DateTime timeLastCalculatePower;
		/// <summary>
		/// time change in seconds * current rate
		/// </summary>
		private void calculatePower()
		{
			float rate = chargersOnline * mySizeChargerOutput;
			TimeSpan elapsed = DateTime.UtcNow - timeLastCalculatePower;
			energyTransfered += (float)elapsed.TotalMilliseconds * rate / 1000;
			timeLastCalculatePower = DateTime.UtcNow;

			log("calculated power. rate="+rate+", elapsed="+elapsed.TotalMilliseconds+", energy="+energyTransfered, "calculatePower()", Logger.severity.TRACE);
		}

		/// <summary>
		/// set radius for drives so they will match output of chargers
		/// </summary>
		private void distributePower()
		{
			float rate = chargersOnline * mySizeChargerOutput;
			float powerPerDrive = rate / drivesOnline;
			float radius = (float)Math.Pow(powerPerDrive / BasePowerInput / setGravity_On, 1 / ConsumptionPower);

			log("calculated radius. rate=" + rate + ", powerPerDrive=" + powerPerDrive + ", radius=" + radius, "distributePower()", Logger.severity.TRACE);

			foreach (JumpDrive drive in allJumpDrives)
				if (drive.myBlock.IsWorking)
					drive.radius = radius;
		}
	}
}
