﻿#define LOG_ENABLED //remove on build

using System;
using System.Collections.Generic;
//using System.Linq;
//using System.Text;

using Sandbox.Common;
using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.ModAPI;
using Ingame = Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;

namespace Rynchodon.Autopilot.Jumper
{
	[MyEntityComponentDescriptor(typeof(MyObjectBuilder_BatteryBlock))]
	public class JumpCharger : MyGameLogicComponent
	{
		public bool recharge = true;

		private MyObjectBuilder_EntityBase builder_base = null;

		private IMyCubeBlock myBlock = null;
		private Ingame.IMyBatteryBlock myBatBlock = null;

		private ITerminalAction action_recharge = null;
		private ITerminalAction action_off = null;
		private bool recharge_toggled = false;
		private bool off_toggled = false;

		private static Logger myLogger = new Logger(null, "JumpCharger");
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private static void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{			myLogger.log(level, method, toLog);		}

		public override void Init(MyObjectBuilder_EntityBase objectBuilder)
		{
			//log("entered Init", "Init()", Logger.severity.TRACE);
			builder_base = objectBuilder;

			myBlock = Entity as IMyCubeBlock;
			myBatBlock = Entity as Ingame.IMyBatteryBlock;
			if (myBlock == null || myBatBlock == null)
				return;
			action_recharge = myBatBlock.GetActionWithName("Recharge");
			action_off = myBatBlock.GetActionWithName("OnOff_Off");

			log("passed tests", "Init()", Logger.severity.TRACE);

			//List<ITerminalAction> allActions = new List<ITerminalAction>();
			//myBatBlock.GetActions(allActions);

			//foreach (ITerminalAction action in allActions)
			//{
			//	log("got action: " + action.Name, "UpdateAfterSimulation()", Logger.severity.TRACE);
			//}

			Entity.NeedsUpdate |= MyEntityUpdateEnum.EACH_FRAME;
		}

		public override void UpdateAfterSimulation()
		{
			log("entered UpdateAfterSimulation", "UpdateAfterSimulation()", Logger.severity.TRACE);
			MyObjectBuilder_BatteryBlock builder = myBlock.GetObjectBuilderCubeBlock() as MyObjectBuilder_BatteryBlock;

			log("builder="+builder+", producer="+builder.ProducerEnabled+", semiauto="+builder.SemiautoEnabled);
			// verify recharge / semi-auto
			if (builder.ProducerEnabled != recharge)
			{
				if (recharge_toggled)
					return;
				log("do not touch that switch! producer was " + !recharge, "UpdateAfterSimulation()", Logger.severity.TRACE);
				action_recharge.Apply(myBatBlock);
				recharge_toggled = true;
			}
			else
				recharge_toggled = false;
			if (builder.SemiautoEnabled && builder.Enabled)
			{
				if (off_toggled)
					return;
				log("do not touch that switch! semiauto was on", "UpdateAfterSimulation()", Logger.severity.TRACE);
				action_off.Apply(myBatBlock);
				off_toggled = true;
			}
			else
				off_toggled = false;
		}

		public override MyObjectBuilder_EntityBase GetObjectBuilder(bool copy = false)
		{
			return builder_base;
		}
	}
}
