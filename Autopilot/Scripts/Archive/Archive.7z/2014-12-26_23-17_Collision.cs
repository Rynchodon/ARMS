﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Sandbox.Common;
using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.Definitions;
using Sandbox.Engine;
using Sandbox.Game;
using Sandbox.ModAPI;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using VRageMath;
using Autopilot;

namespace AutoPilot
{
	internal class Collision
	{
		//private static float minBufferFront = 10f;
		//private static float bufferSide = 2.5f;
		//private static float minLength = 10f;

		// metres distance relative to grid
		//private float start.X, start.Y, start.Z, end.X, end.Y, end.Z;
		private Vector3 start, end;

		// blocks distance relative to grid
		//private int centreX, centreY, centreZ;

		//private Vector3I locationOfCentre;

		private Sandbox.ModAPI.IMyCubeGrid myGrid;
		Sandbox.ModAPI.IMyCubeBlock myRC;
		//private Base6Directions.Direction directionRC;
		private MyLogger logger;

		/// <summary>
		/// builds the collision object for a given RC
		/// </summary>
		/// <param name="ship"></param>
		public Collision(Sandbox.ModAPI.IMyCubeBlock remoteControl, MyLogger loggerToUse = null)
		{
			if (remoteControl == null)
				log("ArgumentNullException at collision("+ remoteControl + ")");

			logger = loggerToUse;
			myGrid = remoteControl.CubeGrid;
			myRC = remoteControl;

			Vector3[] allCorners = myGrid.LocalAABB.GetCorners();
			bool firstCorner = true;
			foreach (Vector3 corner in allCorners)
			{
				// 0,0,0 may not be part of ship, so start with a corner
				if (firstCorner)
				{
					start = corner; end = corner;
					firstCorner = false;
					continue;
				}
				//log("\tcorner: " + corner.ToString());
				if (corner.X > start.X)
					start.X = corner.X;
				else if (corner.X < end.X)
					end.X = corner.X;

				if (corner.Y > start.Y)
					start.Y = corner.Y;
				else if (corner.Y < end.Y)
					end.Y = corner.Y;

				if (corner.Z > start.Z)
					start.Z = corner.Z;
				else if (corner.Z < end.Z)
					end.Z = corner.Z;
			}
			//log("ship bounds are " + end.X + ":" + start.X + ", " + end.Y + ":" + start.Y + ", " + end.Z + ":" + start.Z);

			//centreX = (int)Math.Round((start.X - end.X) / myGrid.GridSize);
			//centreY = (int)Math.Round((start.Y - end.Y) / myGrid.GridSize);
			//centreZ = (int)Math.Round((start.Z - end.Z) / myGrid.GridSize);

			RCmetresGrid = myRC.Position * myGrid.GridSize;
			radius = 0;

			// set radius to highest distance to edge from RC
			calcDistToEdge(Base6Directions.GetFlippedDirection(myRC.Orientation.Left));
			calcDistToEdge(myRC.Orientation.Left);
			calcDistToEdge(Base6Directions.GetFlippedDirection(myRC.Orientation.Up));
			calcDistToEdge(myRC.Orientation.Up);
			//log("radius is now "+radius);
		}

		/// <summary>
		/// how far is the edge of the ship in the given direction
		/// </summary>
		/// <param name="direction"></param>
		/// <returns></returns>
		private float getLimit(Base6Directions.Direction direction)
		{
			Vector3 unit = Base6Directions.GetVector(direction);
			float minC = start.Dot(unit);
			float maxC = end.Dot(unit);

			if (minC > maxC)
				return minC;
			else
				return maxC;
		}

		Vector3 RCmetresGrid;
		private float radius;
		private void calcDistToEdge(Base6Directions.Direction direction)
		{
			float coordinate = RCmetresGrid.Dot(Base6Directions.GetVector(direction));
			/*switch (direction)
			{
				case Base6Directions.Direction.Right:
				case Base6Directions.Direction.Up:
				case Base6Directions.Direction.Backward:
					coordinate = RCmetresGrid.Dot(Base6Directions.GetVector(direction));
					break;
				default:
					coordinate = RCmetresGrid.Dot(Base6Directions.GetVector(Base6Directions.GetFlippedDirection(direction)));
					break;
			}*/
			float limit = getLimit(direction);

			float newRadius = limit - coordinate;
			if (newRadius < 0)
				log("Error at calcDistToEdge(" + direction + "): " + newRadius + "(" + limit + " - " + coordinate + ") < 0");

			//log("distance to edge "+direction+" is "+newRadius);
			radius = Math.Max(radius, newRadius);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="distanceInFront">how far in front of the RC the Spheres should start</param>
		/// <param name="offset1"></param>
		/// <param name="offset2"></param>
		/// <returns></returns>
		public Spheres getWorldCollision(int distanceInFront, int offset1, int offset2, float radiusMultiplier, int speed)
		{
			Vector3 rightward = Base6Directions.GetVector(myRC.Orientation.Left) * offset1;
			Vector3 upward = Base6Directions.GetVector(myRC.Orientation.Up) * offset1;
			Vector3 backward = Base6Directions.GetVector(myRC.Orientation.Forward) * distanceInFront;

			Vector3 inBlocks = (rightward + upward + backward) / myGrid.GridSize;
			Vector3D startOfSpheres = myGrid.GridIntegerToWorld(Vector3I.Round(inBlocks));

			log("start of spheres: " + startOfSpheres + ", rounded vector: " + Vector3I.Round(inBlocks));

			return new Spheres(startOfSpheres, myRC, radius, speed, logger);

			// force distance in front to minimum of radius + minDistanceBetweenShipAndCollision
			//int minDist = (int)Math.Ceiling(radius) + minDistanceBetweenShipAndCollision;
			//if (distanceInFront < minDist)
			//distanceInFront = minDist;

			//float gridSize = myGrid.GridSize;
			//offset1 = (int)(offset1 / gridSize);
			//offset2 = (int)(offset2 / gridSize);

			// get centre of collision
		/*	Vector3D centreOfCollision;
			switch (myRC.Orientation.Forward)
			{
				case Base6Directions.Direction.Right:
					centreOfCollision = myGrid.GridIntegerToWorld(new Vector3I((int)Math.Ceiling(((float)start.X + distanceInFront) / gridSize), offset1 + centreY, offset2 + centreZ));
					break;
				case Base6Directions.Direction.Left:
					centreOfCollision = myGrid.GridIntegerToWorld(new Vector3I((int)Math.Ceiling(((float)end.X - distanceInFront) / gridSize), offset1 + centreY, offset2 + centreZ));
					break;
				case Base6Directions.Direction.Up:
					centreOfCollision = myGrid.GridIntegerToWorld(new Vector3I(offset1 + centreX, (int)Math.Ceiling(((float)start.Y + distanceInFront) / gridSize), offset2 + centreZ));
					break;
				case Base6Directions.Direction.Down:
					centreOfCollision = myGrid.GridIntegerToWorld(new Vector3I(offset1 + centreX, (int)Math.Ceiling(((float)end.Y - distanceInFront) / gridSize), offset2 + centreZ));
					break;
				case Base6Directions.Direction.Backward:
					centreOfCollision = myGrid.GridIntegerToWorld(new Vector3I(offset1 + centreX, offset2 + centreY, (int)Math.Ceiling(((float)start.Z + distanceInFront) / gridSize)));
					break;
				case Base6Directions.Direction.Forward:
					centreOfCollision = myGrid.GridIntegerToWorld(new Vector3I(offset1 + centreX, offset2 + centreY, (int)Math.Ceiling(((float)end.Z - distanceInFront) / gridSize)));
					//log("z is " + end.Z + " - " + distanceInFront + " = " + (end.Z - distanceInFront));
					break;
				default: // unreachable
					log("invalid direction at getWorldCollison // get centre of collison");
					centreOfCollision = new Vector3D();
					break;
			}

			/*if (offset1 == 0 && offset2 == 0)
			{
				log("grid size is " + myGrid.GridSize);
				log("ship position is " + myGrid.GetPosition());
				log("getWorldCollision(" + distanceInFront + ") centre is " + centreOfCollision + " radius is " + radius);
				log("distance between the two is " + (myGrid.GetPosition() - centreOfCollision).Length());
			}*/

			//return new BoundingSphereD(centreOfCollision, radius);
		}

		private void log(string toLog)
		{
			if (logger == null)
				return;
			logger.WriteLine("col(" + myGrid.DisplayName + "): " + toLog);
		}

		/// <summary>
		/// iterates over a series of BoundingSphereD between two points
		/// </summary>
		internal class Spheres
		{
			private MyLogger logger;

			private Vector3D start;
			private Vector3D end;
			/// <summary>
			/// vector in the direction start to end, with magnitude of diameter
			/// </summary>
			private Vector3D startToEnd;
			private Sandbox.ModAPI.IMyCubeGrid cutOff;
			private float radius;
			//private float minDistance;

			private int sphereNum;

			public Spheres(Vector3D start, Sandbox.ModAPI.IMyCubeBlock remoteControl, float radius, int speed, MyLogger logger = null)
			{
				this.start = start;
				this.end = remoteControl.GetPosition() - remoteControl.CubeGrid.GridIntegerToWorld(new Vector3I(0,0,-speed));
				cutOff = remoteControl.CubeGrid;
				this.radius = radius;
				this.logger = logger;
				sphereNum = 0;

				startToEnd = end - start;
				startToEnd.Normalize();
				startToEnd *= 2 * radius;

				log("end is " + end + " dist from RC is " + (remoteControl.GetPosition() - end).Length());
			}

			public bool next(out BoundingSphereD result)
			{
				Vector3D centre = start + startToEnd * sphereNum;
				sphereNum++;
				result = new BoundingSphereD(centre, radius);

				// if grid is in sphere return false
				//log("result contains: "+result.Contains(cutOff.WorldAABB));
				//if (result.Contains(cutOff.WorldAABB) != ContainmentType.Disjoint)
				log("centre - end: "+(centre-end).Length());
				if ((centre - end).Length() < 3 * radius)
				{
					log("too close");
					return false;
				}

				return true;
			}

			private void log(string toLog)
			{
				if (logger == null)
					return;
				logger.WriteLine("col.s: " + toLog);
			}
		}
	}
}
