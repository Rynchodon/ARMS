﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Text.RegularExpressions;
using System.Threading.Tasks;

using Sandbox.Common;
using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.Definitions;
using Sandbox.Engine;
using Sandbox.Game;
using Sandbox.ModAPI;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using VRageMath;
using Autopilot;

namespace AutoPilot
{
	class GridHandler
	{
//		private static string nameRCBase = "Autopilot";

		private MyLogger Logger;
		private Sandbox.ModAPI.IMyCubeGrid myGrid;
		private bool needToUpdateRemoteControls;

		private List<Sandbox.ModAPI.IMySlimBlock> remoteControlBlocks;
		private IMyControllableEntity currentRemoteControl;
		// list of sensors for proximity test

		private Queue<string> instructions;
		private Stack<Vector3D> pathToDestination;

		private navState myNavState;
		private enum navState
		{
			STOPPING,
			ROTATING,
			DEROTATE, // decelerate rotation
			MOVING,
			DEMOVE, // decelerate motion
			DESTINATION
		}

		public GridHandler(Sandbox.ModAPI.IMyCubeGrid grid, MyLogger logger=null)
		{
			Logger = logger;

			myGrid = grid;
//			needToUpdateRemoteControls = true;

			// TODO: move the rest to an init function, which is only called if gridCanNavigate()
			log("handler installing...");
			updateRemoteControls();

			instructions = new Queue<string>();
			pathToDestination = new Stack<Vector3D>();
//			pathToDestination.Add(Vector3D.Zero);
//			pathToDestination.Add(new Vector3D(100,0,0));
//			pathToDestination.Add(new Vector3D(0, 100, 0));
//			pathToDestination.Add(new Vector3D(0, 0, 100));

			myNavState = navState.STOPPING;

			// TODO: register for events
		}

		public void update()
		{
			if (needToUpdateRemoteControls)
				updateRemoteControls();
			if (pathToDestination.Count > 0)
			{
				if (myNavState == navState.DESTINATION)
				{
					pathToDestination.Pop();
					myNavState = navState.STOPPING;
					if (pathToDestination.Count > 0)
						log("next waypoint is " + pathToDestination.Peek());
				}
				if (pathToDestination.Count > 0)
					navigate(pathToDestination.Peek());
			}
			else // no waypoints
			{
				if (instructions.Count > 0)
				{
					while (pathToDestination.Count == 0 && instructions.Count > 0)
						addInstruction(instructions.Dequeue());
				}
				else
				{ // find a remote control with instructions
					foreach (Sandbox.ModAPI.IMySlimBlock remoteControlBlock in remoteControlBlocks)
					{
						Sandbox.ModAPI.IMyCubeBlock fatBlock = remoteControlBlock.FatBlock;
						if ( remoteControlIsOn(fatBlock) )
						{
							//	parse display name
							string displayName = fatBlock.DisplayNameText;
//							log("RC name: "+displayName);
							int start = displayName.IndexOf('[') + 1;
							int end = displayName.IndexOf(']');
							if (start > 0 && end > start)
							{
								int length = end - start;

								string[] inst = displayName.Substring(start, length).Split(':');
								instructions = new Queue<string>( inst );
							}
						}
					}
				}
			}
		}

		/// <summary>
		/// adds a single instruction to this handler
		/// </summary>
		/// <param name="instruction">the instruction to add</param>
		// TODO: add more types of instructions
		public void addInstruction(string instruction)
		{
			string lowerCase = instruction.ToLower();
			//	coordinates
			if (lowerCase[0] == 'c')
			{
				lowerCase = lowerCase.Substring(1);
				string[] coordsString = lowerCase.Split(',');
				if (coordsString.Length == 3)
				{
					log("have coords "+instruction);
					double[] coordsDouble = new double[3];
					for (int i = 0; i < coordsDouble.Length; i++)
						if (!Double.TryParse(coordsString[i], out coordsDouble[i]))
						{
							log("failed to parse: "+coordsString[i]);
							return;
						}
					Vector3D destination = new Vector3D(coordsDouble[0], coordsDouble[1], coordsDouble[2]);
					pathToDestination.Push(destination);
					return;
				}
			}
			log("unknown instruction: "+instruction);
		}

/*		private static Regex extractDoubleRegex = new Regex(@"(\d+.\d+)");

/*		/// <summary>
		/// pulls a double from a string, ignoring all irrelevant characters
		/// </summary>
		/// <param name="s">string that contains a double</param>
		/// <returns>double that is in the string</returns>
		private double extractDouble(string s)
		{
			string toParse = extractDoubleRegex.Match(s).Value;
			log("string: \""+s+"\", toParse: \""+toParse+"\"");
			return Double.Parse( toParse );
		}*/

		/// <summary>
		/// checks for is a station, is owned by current session's player
		/// </summary>
		/// <returns>iff it is possible for this grid to navigate</returns>
		// TODO: should be checked by Update()
		public bool gridCanNavigate()
		{
			if (myGrid.IsStatic)
				return false;
			long playerId = MyAPIGateway.Session.Player.PlayerID;
			if (!myGrid.BigOwners.Contains(playerId))
				return false;

			return true;
		}

		// TODO: should be checked by Update()
		private static bool remoteControlIsOn(Sandbox.ModAPI.IMyCubeBlock remoteControl)
		{
			if (!remoteControl.IsFunctional || !remoteControl.IsWorking)
				return false;
				
			MyObjectBuilder_RemoteControl builder = remoteControl.GetObjectBuilderCubeBlock() as MyObjectBuilder_RemoteControl;
			return (builder.ControlThrusters);
		}

		private void updateRemoteControls()
		{
			needToUpdateRemoteControls = false;

			//	find remote control blocks
			remoteControlBlocks = new List<Sandbox.ModAPI.IMySlimBlock>();
			MyObjectBuilderType remoteControlType = (new MyObjectBuilder_RemoteControl() as MyObjectBuilder_Base).TypeId;
			myGrid.GetBlocks(remoteControlBlocks, block => block.FatBlock != null && block.FatBlock.BlockDefinition.TypeId == remoteControlType);
			log("# of RC blocks is " + remoteControlBlocks.Count);
		}

		private double needToRotateX;
		private double needToRotateY;
		private double previousX;
		private double previousY;

		private float decelerate = 1f / 2f; // how much of rotation should be deceleration
		private static float decelerateAdjustment = 0.9f; // adjust decelerate by this much when overshoot/undershoot, must be > 0 and < 1

		// TODO: add deceleration for moving
		// TODO: speed adjustment
		// TODO: proximity to waypoint
		// TODO: proximity to obstruction
		private void navigate(Vector3D currentWaypoint)
		{
			if (currentRemoteControl == null)
				return;

			var dir = currentWaypoint - myGrid.GetPosition();

			var dirNorm = Vector3D.Normalize(dir); // unit vector
			var x = -(currentRemoteControl as IMyEntity).WorldMatrix.Up.Dot(dirNorm); // dot product to get x
			var y = -(currentRemoteControl as IMyEntity).WorldMatrix.Left.Dot(dirNorm); // dot product to get y

			if (Math.Abs(x) < 0.01f)
				x = 0;
			else
				x *= 10f;
			if (Math.Abs(y) < 0.01f)
				y = 0;
			else
				y *= 10f;

			var rot = new Vector2((float)x, (float)y);

			if (Math.Abs(rot.Length()) > 0) // need to rotate
			{
				switch (myNavState)
				{
					case navState.MOVING:
						//	TODO: make minor ajustments in-flight
						//log("Math.Abs(rot.Length()): " + Math.Abs(rot.Length()));
						if (Math.Abs(rot.Length()) > 1.0)
						{
							log("stopping to rotate");
							currentRemoteControl.MoveAndRotateStopped();
							myNavState = navState.STOPPING;
						}
						break;
					case navState.DEROTATE:
					case navState.STOPPING:
						if (Math.Abs(previousX - x) < 0.01f && Math.Abs(previousY - y) < 0.01f) // actually stopped
						{
							if (myNavState == navState.DEROTATE)
							{
								int overUnder = 0;
								//	check for overshoot/undershoot
								if (x!= 0)
									// assume (needToRotateX != 0)
									if ( (x > 0 && needToRotateX > 0) || (x < 0 && needToRotateX < 0) )
										overUnder--;
									else
										overUnder++;
								if (y!= 0)
									// assume (needToRotateY != 0)
									if ( (y > 0 && needToRotateY > 0) || (y < 0 && needToRotateY < 0) )
										overUnder--;
									else
										overUnder++;

								if (overUnder != 0)
								{
									if (overUnder > 0)
										decelerate /= decelerateAdjustment;
									else
										decelerate *= decelerateAdjustment;
									log("adjusted decelerate, new value is " + decelerate);
								}
							}
							log("starting rotation: " + x + ", " + y);
							needToRotateX = x;
							needToRotateY = y;
							currentRemoteControl.MoveAndRotate(Vector3D.Zero, rot, 0); // rotate towards target
							myNavState = navState.ROTATING;
						}
						break;
					case navState.ROTATING:
						// check for need to decelerate
						if  ((needToRotateX > 0 && x < needToRotateX * decelerate)
							|| (needToRotateX < 0 && x > needToRotateX * decelerate) 
							|| (needToRotateY > 0 && y < needToRotateY * decelerate) 
							|| (needToRotateY < 0 && y > needToRotateY * decelerate))
						{
							log("decelerate rotation ("+x+", "+y+", "+needToRotateX+", "+needToRotateY+")");
							currentRemoteControl.MoveAndRotateStopped();
//							var revRot = new Vector2((float)-needToRotateX, (float)-needToRotateY);
//							rcBlock.MoveAndRotate(Vector3D.Zero, revRot, 0); // stop rotating
							myNavState = navState.DEROTATE;
						}
						break;
					default:
						break;
				}
			}
			else // no need to rotate
			{
				if (myNavState == navState.DEROTATE || myNavState == navState.ROTATING)
				{
					log("stopping rotation");
					currentRemoteControl.MoveAndRotateStopped(); // stop rotating
					myNavState = navState.STOPPING;
				}
				if (dir.Length() < 10) // at destination
				{
					switch (myNavState)
					{
						case navState.MOVING:
							log("stopping at destination");
							currentRemoteControl.MoveAndRotateStopped();
							myNavState = navState.STOPPING;
							break;
						case navState.STOPPING:
							log("reached destination");
							myNavState = navState.DESTINATION;
							break;
						default:
							break;
					}
				}
				else // not at destination
				{
					if (myNavState == navState.STOPPING)
					{
						currentRemoteControl.MoveAndRotate(Vector3D.Forward, Vector2.Zero, 0); // move
						log("moving");
						myNavState = navState.MOVING;
					}
				}
			}

			previousX = x;
			previousY = y;
		}

		private void OnBlockOwnershipChanged(Sandbox.ModAPI.IMyCubeGrid changedBlock)
		{
			needToUpdateRemoteControls = true;
		}

		private void OnBlockAdded(Sandbox.ModAPI.IMySlimBlock addedBlock)
		{
			needToUpdateRemoteControls = true;
		}

		private void OnBlockRemoved(Sandbox.ModAPI.IMySlimBlock removedBlock)
		{
			needToUpdateRemoteControls = true;
		}

		private void log(string toLog)
		{
			if (Logger == null)
				return;
			Logger.WriteLine("GH: "+toLog);
		}
	}
}
