﻿//#define LOG_ENABLED

using System;
using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//using Sandbox.Common;
//using Sandbox.Common.Components;
//using Sandbox.Common.ObjectBuilders;
//using Sandbox.Definitions;
//using Sandbox.Engine;
//using Sandbox.Game;
//using Sandbox.ModAPI;
//using Sandbox.ModAPI.Ingame;
//using Sandbox.ModAPI.Interfaces;
using VRageMath;

namespace Rynchodon.Autopilot
{
	internal class NavSettings
	{
		public enum Moving : byte { NOT_MOVING, MOVING, STOPPING_M }
		public enum Rotating : byte	{	NOT_ROTATING,	ROTATING, STOPPING_R}

		public Moving moveState;
		public Rotating rotateState;

		//public State curNavState;
		public int destinationRadius;
		public bool isAMissile;
		public DateTime waitUntil;
		public DateTime waitUntilNoCheck;
		//public Sandbox.ModAPI.IMyCubeGrid gridDestination; // If the destination is a grid, it should be added here. This should only be checked when CNS.waypoints is empty.
		public string destinationBlockName;
		public Queue<string> instructions;
		//public Stack<Vector3D> waypoints;
		//public bool inflightAdjustment;
		//public int cruiseSpeedSet;
		//public Sandbox.ModAPI.IMyCubeBlock closestCube;
		public TARGET lockOnTarget;
		public int lockOnRange;
		public string lockOnBlock;
		public string tempBlockName;
		public bool noWayForward;
		public bool EXIT = false;
		//public COL_DEST collAtDest;

		public enum TARGET : byte { OFF, MISSILE, ENEMY }
		//public enum COL_DEST : byte { NOT_AT, AT_DEST, SLOWING, CRUISING }

		private Navigator myNav;

		public NavSettings(Navigator nav)
		{
			//if (logger != null)
			//logger.WriteLine("initialized navigation settings");
			instructions = new Queue<string>();
			moveState = Moving.NOT_MOVING;
			rotateState = Rotating.NOT_ROTATING;
			destinationRadius = 100;
			isAMissile = false;
			waitUntil = DateTime.UtcNow;
			waitUntilNoCheck = DateTime.UtcNow;
			destinationBlockName = null;
			//inflightAdjustment = false;
			//cruiseSpeedSet = 100;
			closestBlock = null;
			//stoppedAfter = new TimeSpan(0, 0, 1);
			lockOnTarget = TARGET.OFF;
			lockOnRange = 0;
			lockOnBlock = null;
			tempBlockName = null;
			noWayForward = false;
			//collAtDest = COL_DEST.NOT_AT;
			speedCruise_internal = int.MaxValue;
			speedSlow_internal = int.MaxValue;
			speedCruise_external = int.MaxValue;
			speedSlow_external = int.MaxValue;

			// private vars
			myNav = nav;
			waypoints = new Stack<Vector3D>();
			coordDestination = null;
			gridDestination = null;
			//speedLimit_value = ushort.MaxValue;
		}

		private Stack<Vector3D> waypoints;
		private Vector3D? coordDestination;
		public Sandbox.ModAPI.IMyCubeGrid gridDestination { get; private set; }
		private Sandbox.ModAPI.IMyCubeBlock closestBlock;
		/// <summary>
		/// to keep ship from moving until at least one collision check has happend.
		/// updated for new destination, not for new waypoint. updated for atWayDest
		/// </summary>
		//public int collisionUpdateSinceWaypointAdded = 0;

		/// <summary>
		/// reset on Navigator.FullStop()
		/// </summary>
		public int speedCruise_internal { private get; set; }
		/// <summary>
		/// reset on Navigator.FullStop()
		/// </summary>
		public int speedSlow_internal { private get; set; }
		public int speedCruise_external { private get; set; }
		public int speedSlow_external { private get; set; }

		public bool speedInternalSet()
		{ return (speedCruise_internal < int.MaxValue || speedSlow_internal < int.MaxValue); }

		public int getSpeedCruise()
		{
			int minSetting = Math.Min(Math.Min(speedCruise_internal, speedCruise_external), 100);
			int maxSetting = getSpeedSlow();
			log("min of (" + speedCruise_internal + ", " + speedCruise_external + ", " + 100 + ", " + maxSetting + ")", "getCruiseSpeed", Logger.severity.DEBUG);
			if (minSetting < maxSetting)
				return minSetting;
			else
				return maxSetting - 1;
		}
		public int getSpeedSlow()
		{
			log("min of (" + speedSlow_internal + ", " + speedSlow_external + ")", "getSpeedSlow", Logger.severity.DEBUG);
			return Math.Min(speedSlow_internal, speedSlow_external);
		}

		/*private ushort speedLimit_value;
		private static ushort speedLimtAtDest = 10;
		public ushort speedLimit
		{
			get
			{
				if (collAtDest)
					return Math.Min(speedLimtAtDest, (ushort)(speedLimit_value/10));
				else
					return speedLimit_value;
			}
			set
			{
				speedLimit_value = value;
			}
		}*/

		private Logger myLogger = null;// = new Logger(myGrid.DisplayName, "Collision");
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			if (myLogger == null)
				myLogger = new Logger(myNav.myGrid.DisplayName, "NavSettings");
			myLogger.log(level, method, toLog);
		}

		private bool isValidDestination(double distance)
		{
			if (isAMissile) return true; // distance is not important for missile
			return (distance > 2 * destinationRadius);
		}

		private bool isValidDestination(Vector3D destination)
		{
			if (isAMissile) return true; // distance is not important for missile
			return isValidDestination((myNav.getMyPosition() - destination).Length());
		}

		public bool setDestination(Vector3D coordinates)
		{
			//collisionUpdateSinceWaypointAdded = 0;
			bool isValid = isValidDestination(coordinates);
			if (isValid)
				coordDestination = coordinates;
			return isValid;
		}
		public bool setDestination(Sandbox.ModAPI.IMyCubeGrid grid)
		{
			//collisionUpdateSinceWaypointAdded = 0;
			bool isValid = isValidDestination(grid.WorldAABB.Distance(myNav.getMyPosition()));
			//bool isValid = isValidDestination(GridWorld.getClosestCorner(myNav.getMyPosition(), grid).location);
			if (isValid)
				gridDestination = grid;
			return isValid;
		}
		public bool setDestination(Sandbox.ModAPI.IMyCubeBlock block)
		{
			//collisionUpdateSinceWaypointAdded = 0;
			bool isValid = isValidDestination(block.GetPosition());
			if (isValid)
				closestBlock = block;
			return isValid;
		}
		public bool setDestination(Sandbox.ModAPI.IMyCubeGrid grid, Sandbox.ModAPI.IMyCubeBlock block)
		{
			//collisionUpdateSinceWaypointAdded = 0;
			if (block == null) { return setDestination(grid); }
			if (grid == null) { return setDestination(block); }

			if (isValidDestination(block.GetPosition()))
			{
				gridDestination = grid;
				closestBlock = block;
				return true;
			}
			return false;
		}
		public bool addWaypoint(Vector3D waypoint)
		{
			//speedCruise_internal = int.MaxValue;
			//speedSlow_internal = int.MaxValue;
			bool isValid = isValidDestination(waypoint);
			if (isValid)
				waypoints.Push(waypoint);
			return isValid;
		}

		/// <summary>
		/// removes one waypoint or destination
		/// </summary>
		public void atWayDest()
		{
			//collisionUpdateSinceWaypointAdded = 0;
			atWayDest(getTypeOfWayDest());
		}

		/// <summary>
		/// removes one waypoint or destination of the specified type
		/// </summary>
		/// <param name="typeToRemove"></param>
		public void atWayDest(TypeOfWayDest typeToRemove)
		{
			switch (typeToRemove)
			{
				case TypeOfWayDest.BLOCK:
				case TypeOfWayDest.GRID:
					closestBlock = null;
					gridDestination = null;
					return;
				case TypeOfWayDest.COORDINATES:
					coordDestination = null;
					return;
				case TypeOfWayDest.WAYPOINT:
					waypoints.Pop();
					return;
				default:
					return;
			}
		}

		/// <summary>
		/// get next waypoint or destination
		/// </summary>
		/// <returns></returns>
		public Vector3D? getWayDest()
		{
			switch(getTypeOfWayDest()){
				case TypeOfWayDest.BLOCK:
					return closestBlock.GetPosition();
				case TypeOfWayDest.COORDINATES:
					return coordDestination;
				case TypeOfWayDest.GRID:
					return GridWorld.getMiddle(gridDestination);
				case TypeOfWayDest.WAYPOINT:
					return waypoints.Peek();
				default:
					return null;
			}
		}

		public string getDestGridName()
		{
			if (gridDestination == null)
				return null;
			return gridDestination.DisplayName;
		}

		public enum TypeOfWayDest : byte { NULL, COORDINATES, GRID, BLOCK, WAYPOINT }
		public TypeOfWayDest getTypeOfWayDest()
		{
			if (waypoints.Count > 0)
				return TypeOfWayDest.WAYPOINT;

			if (gridDestination != null)
			{
				if (closestBlock != null)
					return TypeOfWayDest.BLOCK;
				else
					return TypeOfWayDest.GRID;
			}
			
			if (coordDestination != null)
				return TypeOfWayDest.COORDINATES;

			return TypeOfWayDest.NULL;
		}
	}
}
