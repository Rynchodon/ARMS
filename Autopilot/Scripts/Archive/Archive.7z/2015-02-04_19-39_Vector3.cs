﻿#define LOG_ENABLED //remove on build

using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

using Sandbox.ModAPI;
using VRageMath;

namespace Rynchodon.Autopilot
{
	class AbsoluteVector3D
	{
		private Vector3D? value__world;
		private Vector3D? value__grid;
		private Vector3D? value__block;

		private IMyCubeGrid cubeGrid; // allways filled on create
		private IMyCubeBlock cubeBlock;

		private Logger myLogger;
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{ alwaysLog(toLog, method, level); }
		private void alwaysLog(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			if (myLogger == null) myLogger = new Logger(cubeGrid.DisplayName, "AbsoluteVector3D");
			myLogger.log(level, method, toLog);
		}

		private AbsoluteVector3D() { }

		public static AbsoluteVector3D createFromBlock(Vector3D fromBlock, IMyCubeBlock block)
		{
			AbsoluteVector3D result = new AbsoluteVector3D();
			result.value__world = null;
			result.value__grid = null;
			result.value__block = fromBlock;
			result.cubeGrid = block.CubeGrid;
			result.cubeBlock = block;
			result.log("value__block = " + result.value__block, "createFromBlock()", Logger.severity.TRACE);
			return result;
		}

		private const float precisionMultiplier = 1024;

		public Vector3D world
		{
			get
			{
				if (value__world != null)
					return (Vector3D)value__world;

				// create from grid
				Vector3I gridInt = Vector3I.Round((Vector3)grid * precisionMultiplier / cubeGrid.GridSize);
				value__world = cubeGrid.GridIntegerToWorld(gridInt) / precisionMultiplier;
				log("created from grid. grid = " + (Vector3D)value__grid + ", world = " + (Vector3D)value__world, "get_grid()", Logger.severity.TRACE);
				log("grid location = " + cubeGrid.GetPosition() + ", grid direction = " + cubeGrid.WorldMatrix.Forward, "get_grid()", Logger.severity.TRACE);
				return (Vector3)world;
			}
		}

		public Vector3D grid
		{
			get
			{
				if (value__grid != null)
					return (Vector3D)value__grid;

				// create from block
				// orient according to block
				Vector3D resultant = Vector3D.Zero;
				Vector3D blockRelative = (Vector3D)value__block;
				Base6Directions.Direction RCdirection = cubeBlock.Orientation.Left;
				resultant -= (Vector3D)Base6Directions.GetVector(RCdirection) * blockRelative.X;
				RCdirection = cubeBlock.Orientation.Up;
				resultant += (Vector3D)Base6Directions.GetVector(RCdirection) * blockRelative.Y;
				RCdirection = cubeBlock.Orientation.Forward;
				resultant -= (Vector3D)Base6Directions.GetVector(RCdirection) * blockRelative.Z;
				
				// add block position
				value__grid = resultant + cubeBlock.Position * cubeGrid.GridSize;
				log("created from block. block = " + (Vector3D)value__block + ", grid = " + (Vector3D)value__grid, "get_grid()", Logger.severity.TRACE);
				return (Vector3D)value__grid;
			}
		}
	}

	class RelativeVector3F
	{
		// one of these will always be set on create
		private Vector3? value__world;
		private Vector3? value__grid;
		//private Vector3? block = null;

		//private IMyCubeBlock cubeBlock = null;
		private IMyCubeGrid cubeGrid; // always set on create

		private Logger myLogger;
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{ alwaysLog(toLog, method, level); }
		private void alwaysLog(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			if (myLogger == null) myLogger = new Logger(cubeGrid.DisplayName, "RelativeVector3F");
			myLogger.log(level, method, toLog);
		}

		private RelativeVector3F() { }

		public static RelativeVector3F createFromWorld(Vector3 world, IMyCubeGrid cubeGrid)
		{
			RelativeVector3F result = new RelativeVector3F();
			result.value__world = world;
			result.cubeGrid = cubeGrid;
			return result;
		}

		public static RelativeVector3F createFromGrid(Vector3 grid, IMyCubeGrid cubeGrid)
		{
			RelativeVector3F result = new RelativeVector3F();
			result.value__grid = grid;
			result.cubeGrid = cubeGrid;
			return result;
		}

		//public static RelativeVector3F createFromBlock(Vector3 block, IMyCubeBlock cubeBlock) { } // might need this at some point

		private const float precisionMultiplier = 1024;

		public Vector3 getWorld()
		{
			if (value__world != null)
				return (Vector3)value__world;

			// create from grid
			Vector3I gridInt = Vector3I.Round((Vector3)value__grid * precisionMultiplier / cubeGrid.GridSize);
			value__world = (cubeGrid.GridIntegerToWorld(gridInt) - cubeGrid.GetPosition()) / precisionMultiplier;
			return (Vector3)value__world;
		}

		public Vector3 getGrid()
		{
			if (value__grid != null)
				return (Vector3)value__grid;

			// create from world
			Vector3I gridInt = cubeGrid.WorldToGridInteger((Vector3)value__world * precisionMultiplier + cubeGrid.GetPosition());
			value__grid = (gridInt * cubeGrid.GridSize) / precisionMultiplier;
			return (Vector3)value__grid;
		}

		public Vector3 getBlock(Sandbox.ModAPI.IMyCubeBlock cubeBlock)
		{
			// create from grid
			Vector3 v3;
			MatrixD matrix;
			if (value__grid != null)
			{
				v3 = ((Vector3)this.value__grid);
				matrix = cubeBlock.LocalMatrix;
			}
			else // assuming (world != null)
			{
				v3 = ((Vector3)this.value__world);
				matrix = cubeBlock.WorldMatrix;
			}

			Vector3 resultant = v3.Dot(matrix.Right) * Base6Directions.GetVector(Base6Directions.Direction.Right);
			resultant += v3.Dot(matrix.Up) * Base6Directions.GetVector(Base6Directions.Direction.Up);
			resultant += v3.Dot(matrix.Backward) * Base6Directions.GetVector(Base6Directions.Direction.Backward);
			return resultant;
		}
	}
}
