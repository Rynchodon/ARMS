﻿using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

using Sandbox.Common;
using Sandbox.ModAPI;

namespace Rynchodon.Autopilot
{
	public class Settings
	{
		// Settings
		public bool allow_jumps = true;

		// 
		private static string settings_file_name = "AutopilotSettings.txt";
		private static System.IO.TextReader settingsReader;
		private static System.IO.TextWriter settingsWriter;

		private static int latestVersion = 1;

		internal static void open()
		{
			if (readAll() != latestVersion)
				MyAPIGateway.Utilities.ShowNotification("Autopilot has been updated.", 10000, MyFontEnum.White);

			readAll();
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns>version of file</returns>
		private static int readAll()
		{
			if (!MyAPIGateway.Utilities.FileExistsInLocalStorage(settings_file_name, typeof(Settings)))
				return -1;

			settingsReader = MyAPIGateway.Utilities.ReadFileInLocalStorage(settings_file_name, typeof(Settings));

			//int version = read<int>();
			//allow_jumps = read<bool>();
			string buffer = settingsReader.ReadLine();
			MyAPIGateway.Utilities.SerializeFromXML<Settings>(buffer);

			settingsReader.Close();
			settingsReader = null;
			return 1;
		}

		internal static void writeAll()
		{
			// write to file
			settingsWriter = MyAPIGateway.Utilities.WriteFileInLocalStorage(settings_file_name, typeof(Settings));

			//write(latestVersion);
			//write(allow_jumps);
			string XML = MyAPIGateway.Utilities.SerializeToXML<Settings>(new Settings());
			settingsWriter.WriteLine(XML);

			settingsWriter.Flush();
			settingsWriter.Close();
			settingsWriter = null;
		}

		private static void write<T>(T objToSerialize) { 
			string XML = MyAPIGateway.Utilities.SerializeToXML<T>(objToSerialize);
			settingsWriter.WriteLine(XML);
		}

		private static T read<T>() {
			string buffer = settingsReader.ReadLine();
			return MyAPIGateway.Utilities.SerializeFromXML<T>(buffer);
		}
	}
}
