﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Sandbox.Common;
using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.Definitions;
using Sandbox.Engine;
using Sandbox.Game;
using Sandbox.ModAPI;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using AutoPilot;

namespace Autopilot
{
	[Sandbox.Common.MySessionComponentDescriptor(Sandbox.Common.MyUpdateOrder.BeforeSimulation)]
	public class Core : Sandbox.Common.MySessionComponentBase
	{
		private static MyLogger Logger;
		bool initialized;

		private int count;

		private Dictionary<Sandbox.ModAPI.IMyCubeGrid, GridHandler> allGridHandlers; // for tracking which grids already have handlers and for iterating through handlers

		public override void UpdateBeforeSimulation()
		{
			if (!initialized)
			{
				init();
				return;
			}
			if (count % 10 == 0)
			{
				foreach (KeyValuePair<Sandbox.ModAPI.IMyCubeGrid, GridHandler> entry in allGridHandlers)
				{
					entry.Value.update();
				}
			}

			count++;
		}

		private void init()
		{
			if (Logger == null)
			{
				Logger = new MyLogger("Autopilot.log");
			}
			Logger.WriteLine("Initialized");

			allGridHandlers = new Dictionary<Sandbox.ModAPI.IMyCubeGrid, GridHandler>();
			build();
			initialized = true;
		}

		// TODO: call from time to time to find additional entities
		private void build()
		{
			Logger.WriteLine("building...");
			HashSet<IMyEntity> entities = new HashSet<IMyEntity>();
			MyAPIGateway.Entities.GetEntities(entities, e => e is Sandbox.ModAPI.IMyCubeGrid);
			foreach (IMyEntity entity in entities)
			{
				if (entity == null)
					continue;
				Logger.WriteLine("entity is "+entity);
				Sandbox.ModAPI.IMyCubeGrid grid = entity as Sandbox.ModAPI.IMyCubeGrid;
				if (grid == null)
					continue;
				Logger.WriteLine("line 76");
				if (!allGridHandlers.ContainsKey(grid))
				{
					Logger.WriteLine("line 79");
					GridHandler cGridHandler = new GridHandler(grid, Logger);
					allGridHandlers.Add(grid, cGridHandler);
				}
			}
		}

		protected override void UnloadData()
		{
			base.UnloadData();
			Logger.Close();
			Logger = null;
		}
	}
}
