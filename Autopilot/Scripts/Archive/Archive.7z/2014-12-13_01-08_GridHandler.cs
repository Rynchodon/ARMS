﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Sandbox.Common;
using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.Definitions;
using Sandbox.Engine;
using Sandbox.Game;
using Sandbox.ModAPI;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using VRageMath;

namespace AutoPilot
{
	class GridHandler
	{
		private Scripts.KSWH.MyLogger Logger;
		private Sandbox.ModAPI.IMyCubeGrid myGrid;
		private bool needToUpdateRemoteControls;

		private List<Sandbox.ModAPI.IMySlimBlock> remoteControlBlocks;
		// list of sensors for proximity test

		//	destinations
		private List<Vector3D> pathToDestination;

		private navState myNavState;
		private enum navState
		{
			STOPPING,
			ROTATING,
			DEROTATE, // decelerate rotation
			MOVING,
			DESTINATION
		}

		public GridHandler(Scripts.KSWH.MyLogger logger, Sandbox.ModAPI.IMyCubeGrid grid)
		{
			Logger = logger;

			myGrid = grid;
//			needToUpdateRemoteControls = true;

			log("handler installing...");
			updateRemoteControls();

			pathToDestination = new List<Vector3D>();
			pathToDestination.Add(Vector3D.Zero);
			pathToDestination.Add(new Vector3D(0,0,100));

			myNavState = navState.STOPPING;

			// TODO: register for events
		}

		public void update()
		{
			if (needToUpdateRemoteControls)
				updateRemoteControls();
			if (pathToDestination.Count > 0)
			{
				if (myNavState == navState.DESTINATION)
				{
					pathToDestination.RemoveAt(0);
					myNavState = navState.STOPPING;
					if (pathToDestination.Count > 0)
						log("next waypoint is " + pathToDestination[0]);
				}
				if (pathToDestination.Count > 0)
					navigate(pathToDestination[0]);
			}
		}

		private void updateRemoteControls()
		{
			needToUpdateRemoteControls = false;

			//	find remote control blocks
			remoteControlBlocks = new List<Sandbox.ModAPI.IMySlimBlock>();
			MyObjectBuilderType remoteControlType = (new MyObjectBuilder_RemoteControl() as MyObjectBuilder_Base).TypeId;
			myGrid.GetBlocks(remoteControlBlocks, block => block.FatBlock != null && block.FatBlock.BlockDefinition.TypeId == remoteControlType);
			log("# of RC blocks is " + remoteControlBlocks.Count);
		}

		private double needToRotateX;
		private double needToRotateY;
		private double previousX;
		private double previousY;

		private float decelerate = 1f / 2f; // how much of rotation should be deceleration
		private static float decelerateAdjustment = 0.9f; // adjust decelerate by this much when overshoot/undershoot, must be > 0 and < 1

		//	modified from EnemyShip.Update(int count) in Mission 01 by KSWH, id=315628704 on steam
		private void navigate(Vector3D currentWaypoint)
		{
			IMyControllableEntity rcBlock = remoteControlBlocks[0].FatBlock as IMyControllableEntity;

			var dir = currentWaypoint - myGrid.GetPosition();

			var dirNorm = Vector3D.Normalize(dir); // unit vector
			var x = -(rcBlock as IMyEntity).WorldMatrix.Up.Dot(dirNorm); // dot product to get x
			var y = -(rcBlock as IMyEntity).WorldMatrix.Left.Dot(dirNorm); // dot product to get y

			if (Math.Abs(x) < 0.01f)
				x = 0;
			else
				x *= 10f;
			if (Math.Abs(y) < 0.01f)
				y = 0;
			else
				y *= 10f;

			var rot = new Vector2((float)x, (float)y);

			if (Math.Abs(rot.Length()) > 0) // need to rotate
			{
				switch (myNavState)
				{
					case navState.MOVING:
						//	TODO: make minor ajustments in-flight
						//log("Math.Abs(rot.Length()): " + Math.Abs(rot.Length()));
						if (Math.Abs(rot.Length()) > 1.0)
						{
							log("stopping to rotate");
							rcBlock.MoveAndRotateStopped();
							myNavState = navState.STOPPING;
						}
						break;
					case navState.DEROTATE:
					case navState.STOPPING:
						if (Math.Abs(previousX - x) < 0.01f && Math.Abs(previousY - y) < 0.01f) // actually stopped
						{
							if (myNavState == navState.DEROTATE)
							{
								int overUnder = 0;
								//	check for overshoot/undershoot
								if (x!= 0)
									// assume (needToRotateX != 0)
									if ( (x > 0 && needToRotateX > 0) || (x < 0 && needToRotateX < 0) )
										overUnder--;
									else
										overUnder++;
								if (y!= 0)
									// assume (needToRotateY != 0)
									if ( (y > 0 && needToRotateY > 0) || (y < 0 && needToRotateY < 0) )
										overUnder--;
									else
										overUnder++;

								if (overUnder != 0)
								{
									if (overUnder > 0)
										decelerate /= decelerateAdjustment;
									else
										decelerate *= decelerateAdjustment;
									log("adjusted decelerate, new value is " + decelerate);
								}
							}
							log("starting rotation: " + x + ", " + y);
							needToRotateX = x;
							needToRotateY = y;
							rcBlock.MoveAndRotate(Vector3D.Zero, rot, 0); // rotate towards target
							myNavState = navState.ROTATING;
						}
						break;
					case navState.ROTATING:
						// check for need to decelerate
						if  ((needToRotateX > 0 && x < needToRotateX * decelerate)
							|| (needToRotateX < 0 && x > needToRotateX * decelerate) 
							|| (needToRotateY > 0 && y < needToRotateY * decelerate) 
							|| (needToRotateY < 0 && y > needToRotateY * decelerate))
						{
							log("decelerate rotation ("+x+", "+y+", "+needToRotateX+", "+needToRotateY+")");
							rcBlock.MoveAndRotateStopped();
//							var revRot = new Vector2((float)-needToRotateX, (float)-needToRotateY);
//							rcBlock.MoveAndRotate(Vector3D.Zero, revRot, 0); // stop rotating
							myNavState = navState.DEROTATE;
						}
						break;
					default:
						break;
				}
			}
			else // no need to rotate
			{
				if (myNavState == navState.DEROTATE || myNavState == navState.ROTATING)
				{
					log("stopping rotation");
					rcBlock.MoveAndRotateStopped(); // stop rotating
					myNavState = navState.STOPPING;
				}
				if (dir.Length() < 10) // at destination
				{
					switch (myNavState)
					{
						case navState.MOVING:
							log("stopping at destination");
							rcBlock.MoveAndRotateStopped();
							myNavState = navState.STOPPING;
							break;
						case navState.STOPPING:
							log("reached destination");
							myNavState = navState.DESTINATION;
							break;
						default:
							break;
					}
				}
				else // not at destination
				{
					if (myNavState == navState.STOPPING)
					{
						rcBlock.MoveAndRotate(Vector3D.Forward, Vector2.Zero, 0); // move
						log("moving");
						myNavState = navState.MOVING;
					}
				}
			}

			previousX = x;
			previousY = y;
		}

		private void OnBlockOwnershipChanged(Sandbox.ModAPI.IMyCubeGrid changedBlock)
		{
			needToUpdateRemoteControls = true;
		}

		private void OnBlockAdded(Sandbox.ModAPI.IMySlimBlock addedBlock)
		{
			needToUpdateRemoteControls = true;
		}

		private void OnBlockRemoved(Sandbox.ModAPI.IMySlimBlock removedBlock)
		{
			needToUpdateRemoteControls = true;
		}

		private void log(string toLog)
		{
			Logger.WriteLine("GH: "+toLog);
		}
	}
}
