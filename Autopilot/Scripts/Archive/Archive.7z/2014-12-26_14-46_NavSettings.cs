﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Sandbox.Common;
using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.Definitions;
using Sandbox.Engine;
using Sandbox.Game;
using Sandbox.ModAPI;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using VRageMath;
using Autopilot;

namespace AutoPilot
{
	internal struct NavSettings
	{
		public enum State
		{
			STOPPING,
			ROTATING,
			DEROTATE, // decelerate rotation
			MOVING,
			DEMOVE, // decelerate motion
			DESTINATION,
			COLLISION, // collision rerouting failed
			STOPPED
		}

		public State curNavState;
		public int destinationRadius;
		public bool isAMissile;
		public DateTime waitUntil;
		//public Sandbox.ModAPI.IMyCubeGrid gridDestination; // If the destination is a grid, it should be added here. This should only be checked when CNS.waypoints is empty.
		public string destinationBlockName;
		public Queue<string> instructions;
		//public Stack<Vector3D> waypoints;
		public bool inflightAdjustment;
		public int speedLimit;
		public double decelMeasureCoefficient;
		//public Sandbox.ModAPI.IMyCubeBlock closestCube;
		public TimeSpan stoppedAfter;
		public TARGET lockOnTarget;
		public int lockOnRange;
		public string lockOnBlock;
		public string tempBlockName;

		public enum TARGET { OFF, MISSILE, ENEMY }

		private Navigator myNav;
		private MyLogger LOGGER;

		public NavSettings(Navigator nav, MyLogger logger=null)
		{
			//if (logger != null)
			//logger.WriteLine("initialized navigation settings");
			instructions = new Queue<string>();
			curNavState = State.STOPPING;
			destinationRadius = 100;
			isAMissile = false;
			waitUntil = DateTime.UtcNow;
			destinationBlockName = null;
			inflightAdjustment = false;
			speedLimit = 100;
			decelMeasureCoefficient = 0;
			closestBlock = null;
			stoppedAfter = new TimeSpan(0, 0, 1);
			lockOnTarget = TARGET.OFF;
			lockOnRange = 0;
			lockOnBlock = null;
			tempBlockName = null;

			// private vars
			myNav = nav;
			LOGGER = logger;
			waypoints = new Stack<Vector3D>();
			coordDestination = null;
			gridDestination = null;
		}

		private Stack<Vector3D> waypoints;
		private Vector3D? coordDestination;
		private Sandbox.ModAPI.IMyCubeGrid gridDestination;
		private Sandbox.ModAPI.IMyCubeBlock closestBlock;

		private void log(string toLog)
		{
			if (LOGGER != null)
				LOGGER.WriteLine("NS:"+myNav.ToString()+toLog);
		}

		private bool isValidDestination(Vector3D destination){
			if ((myNav.getMyPosition() - destination).Length() < destinationRadius)
			{
				log("destination is too close");
				return false;
			}
			else
			{
				log("destination is far enough");
				return true;
			}
		}

		public void setDestination(Vector3D coordinates)
		{
			if (isValidDestination(coordinates))
				coordDestination = coordinates;
		}
		public void setDestination(Sandbox.ModAPI.IMyCubeGrid grid)
		{
			if (isValidDestination(GridWorld.getClosestCorner(myNav.getMyPosition(), grid).location))
				gridDestination = grid;
		}
		public void setDestination(Sandbox.ModAPI.IMyCubeBlock block)
		{
			if (isValidDestination(block.GetPosition()))
				closestBlock = block;
		}
		public void setDestination(Sandbox.ModAPI.IMyCubeGrid grid, Sandbox.ModAPI.IMyCubeBlock block)
		{
			if (isValidDestination(block.GetPosition()))
			{
				gridDestination = grid;
				closestBlock = block;
			}
		}
		public void addWaypoint(Vector3D waypoint)
		{
			if (isValidDestination(waypoint))
				waypoints.Push(waypoint);
		}

		/// <summary>
		/// removes one waypoint or destination
		/// </summary>
		public void atWayDest()
		{
			atWayDest(getTypeOfWayDest());
		}

		/// <summary>
		/// removes one waypoint or destination of the specified type
		/// </summary>
		/// <param name="typeToRemove"></param>
		public void atWayDest(TypeOfWayDest typeToRemove)
		{
			switch (typeToRemove)
			{
				case TypeOfWayDest.BLOCK:
				case TypeOfWayDest.GRID:
					closestBlock = null;
					gridDestination = null;
					return;
				case TypeOfWayDest.COORDINATES:
					coordDestination = null;
					return;
				case TypeOfWayDest.WAYPOINT:
					waypoints.Pop();
					return;
				default:
					return;
			}
		}

		/// <summary>
		/// get next waypoint or destination
		/// </summary>
		/// <returns></returns>
		public Vector3D? getWayDest()
		{
			switch(getTypeOfWayDest()){
				case TypeOfWayDest.BLOCK:
					return closestBlock.GetPosition();
				case TypeOfWayDest.COORDINATES:
					return coordDestination;
				case TypeOfWayDest.GRID:
					return GridWorld.getMiddle(gridDestination);
				case TypeOfWayDest.WAYPOINT:
					return waypoints.Peek();
				default:
					return null;
			}
		}

		public string getDestGridName()
		{
			if (gridDestination == null)
				return null;
			return gridDestination.DisplayName;
		}

		public enum TypeOfWayDest { NULL, COORDINATES, GRID, BLOCK, WAYPOINT }
		public TypeOfWayDest getTypeOfWayDest()
		{
			if (waypoints.Count > 0)
				return TypeOfWayDest.WAYPOINT;

			if (gridDestination != null)
			{
				if (closestBlock != null)
					return TypeOfWayDest.BLOCK;
				else
					return TypeOfWayDest.GRID;
			}
			
			if (coordDestination != null)
				return TypeOfWayDest.COORDINATES;

			return TypeOfWayDest.NULL;
		}
	}
}
