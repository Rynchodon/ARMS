﻿#define LOG_ENABLED // remove on build

using System;
using System.Collections.Generic;
//using System.Linq;
//using System.Text;

using Sandbox.Common.ObjectBuilders;
using Sandbox.ModAPI;
using ingame = Sandbox.ModAPI.Ingame;
using VRageMath;

namespace Rynchodon.Autopilot.Pathfinder
{
	public class AttachedGrids
	{
		private static Dictionary<IMyCubeGrid, AttachedGrids> registry = new Dictionary<IMyCubeGrid, AttachedGrids>();
		private HashSet<AttachedGrids> attachedToMe = new HashSet<AttachedGrids>();

		private HashSet<IMySlimBlock> allPistonBases = new HashSet<IMySlimBlock>(); // for objectbuilder.TopBlockId
		private HashSet<IMySlimBlock> allPistonTops = new HashSet<IMySlimBlock>();
		private HashSet<IMySlimBlock> allMotorBases = new HashSet<IMySlimBlock>(); // for objectbuilder.RotorEntityId
		private HashSet<IMySlimBlock> allMotorRotors = new HashSet<IMySlimBlock>();
		private HashSet<IMySlimBlock> allConnectors = new HashSet<IMySlimBlock>(); // for objectbuilder.ConnectedEntityId
		private HashSet<IMySlimBlock> allLandingGears = new HashSet<IMySlimBlock>(); // horribly complicated

		private IMyCubeGrid myGrid;

		private Logger myLogger;
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{ alwaysLog(toLog, method, level); }
		private void alwaysLog(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			if (myLogger == null) myLogger = new Logger(myGrid.DisplayName, "AttachedGrids");
			myLogger.log(level, method, toLog);
		}

		private AttachedGrids() { }

		public static AttachedGrids getFor(IMyCubeGrid myGrid)
		{
			AttachedGrids instance;
			if (registry.TryGetValue(myGrid, out instance))
				return instance;
			instance = new AttachedGrids();
			instance.myGrid = myGrid;

			List<IMySlimBlock> allBlocks = new List<IMySlimBlock>();
			myGrid.GetBlocks(allBlocks);
			foreach (IMySlimBlock block in allBlocks)
				instance.myGrid_OnBlockAdded(block);

			myGrid.OnBlockAdded += instance.myGrid_OnBlockAdded;
			myGrid.OnBlockRemoved += instance.myGrid_OnBlockRemoved;
			registry.Add(myGrid, instance);
			instance.log("created for: " + myGrid.DisplayName, "getFor()");
			return instance;
		}

		private void myGrid_OnBlockAdded(IMySlimBlock added)
		{ addRemove(added, true); }

		private void myGrid_OnBlockRemoved(IMySlimBlock removed)
		{ addRemove(removed, false); }

		private static readonly MyObjectBuilderType type_pistonTop = (new MyObjectBuilder_PistonTop()).TypeId;
		private static readonly MyObjectBuilderType type_motorRotor = (new MyObjectBuilder_MotorRotor()).TypeId;

		private void addRemove(IMySlimBlock block, bool add)
		{
			IMyCubeBlock fatblock = block.FatBlock;
			if (fatblock == null)
				return;

			if (fatblock is IMyPistonBase)
				addRemove(allPistonBases, block, add);
			else if (fatblock.BlockDefinition.TypeId == type_pistonTop)
				addRemove(allPistonTops, block, add);
			else if (fatblock is ingame.IMyMotorBase)
				addRemove(allMotorBases, block, add);
			else if (fatblock.BlockDefinition.TypeId == type_motorRotor)
				addRemove(allMotorRotors, block, add);
			else if (fatblock is ingame.IMyShipConnector)
				addRemove(allConnectors, block, add);
			else if (fatblock is IMyLandingGear)
				addRemove(allLandingGears, block, add);
		}

		private void addRemove(HashSet<IMySlimBlock> blockSet, IMySlimBlock block, bool add)
		{
			if (add)
				blockSet.Add(block);
			else
				blockSet.Remove(block);
		}

		private static int build_iteration_ID = 0;
		private int last_build_ID = 0;

		private void destructAttached()
		{
			if (attachedToMe.Count == 0)
				return;
			log("destruct for : " + myGrid.DisplayName, "destructAttached()", Logger.severity.TRACE);
			HashSet<AttachedGrids> tempAttached = attachedToMe;
			attachedToMe = new HashSet<AttachedGrids>();
			foreach (AttachedGrids attached in tempAttached)
				attached.destructAttached();
		}

		public void rebuildAttached()
		{
			destructAttached();
			buildAttached(++build_iteration_ID);
		}

		private void buildAttached(int buildID)
		{
			List<IMyEntity> children = new List<IMyEntity>();
			myGrid.GetChildren(children);
			if (children != null)
				foreach (var child in children)
					log("child: " + child.DisplayName);
			log("parent: " + myGrid.Parent.DisplayName);

			//DateTime start = DateTime.UtcNow;
			if (last_build_ID == buildID)
			{
				//log("already building for : " + myGrid.DisplayName, "buildAttached()", Logger.severity.TRACE);
				return;
			}
			last_build_ID = buildID;
			log("building for : " + myGrid.DisplayName, "buildAttached()", Logger.severity.TRACE);

			// get all the potentially attached grids
			BoundingBoxD world = myGrid.WorldAABB;
			MatrixD scale = MatrixD.CreateScale(1.1);
			BoundingBoxD searchBox = world.Transform(scale);
			searchBox = searchBox.Translate(world.Center - searchBox.Center);
			//printDims(world);
			//log("scale = " + scale, "attachedGrids()", Logger.severity.TRACE);
			//printDims(searchBox);
			foreach (IMyEntity entity in MyAPIGateway.Entities.GetEntitiesInAABB(ref searchBox))
			{
				IMyCubeGrid grid = entity as IMyCubeGrid;
				if (grid == null || grid == myGrid)
					continue;
				AttachedGrids partner = getFor(grid);
				if (attachedToMe.Contains(partner))
				{
					//log("already attached: " + grid.DisplayName, "buildAttached()", Logger.severity.TRACE);
					continue;
				}

				// check each grid for isAttached
				log("checking grid: " + grid.DisplayName, "buildAttached()", Logger.severity.TRACE);
				if (isAttached_piston(partner) || partner.isAttached_piston(this)
					|| isAttached_motor(partner) || partner.isAttached_motor(this)
					|| isAttached_connector(partner) || partner.isAttached_connector(this)
					|| isAttached_landingGear(partner) || partner.isAttached_landingGear(this))
					continue;
			}
			HashSet<AttachedGrids> copy = new HashSet<AttachedGrids>(attachedToMe);
			foreach (AttachedGrids attached in copy)
			{
				//log("building for attached: " + grid.DisplayName, "buildAttached()", Logger.severity.TRACE);
				attached.buildAttached(buildID);
			}
			//log("time to build = " + (DateTime.UtcNow - start).TotalMilliseconds, "buildAttached()", Logger.severity.TRACE);
		}

		//private void printDims(BoundingBoxD box)
		//{
		//	Vector3D start = new Vector3D(), end = new Vector3D();
		//	Vector3D[] allCorners = box.GetCorners();
		//	bool firstCorner = true;
		//	foreach (Vector3D corner in allCorners)
		//	{
		//		// 0,0,0 may not be part of ship, so start with a corner
		//		if (firstCorner)
		//		{
		//			start = corner; end = corner;
		//			firstCorner = false;
		//			continue;
		//		}
		//		//log("\tcorner: " + corner.ToString());
		//		if (corner.X > start.X)
		//			start.X = corner.X;
		//		else if (corner.X < end.X)
		//			end.X = corner.X;

		//		if (corner.Y > start.Y)
		//			start.Y = corner.Y;
		//		else if (corner.Y < end.Y)
		//			end.Y = corner.Y;

		//		if (corner.Z > start.Z)
		//			start.Z = corner.Z;
		//		else if (corner.Z < end.Z)
		//			end.Z = corner.Z;
		//	}
		//	//log("ship bounds are " + end.X + ":" + start.X + ", " + end.Y + ":" + start.Y + ", " + end.Z + ":" + start.Z);
		//	//centre_grid = myGrid.LocalAABB.Center;
		//	//rc_pos_grid = myRC.Position * myGrid.GridSize;
		//	//log("middle is " + centre_grid + ", RC is " + rc_pos_grid, "..ctor", Logger.severity.DEBUG);

		//	double width = getDimension(Base6Directions.Direction.Right, start, end);
		//	double height = getDimension(Base6Directions.Direction.Up, start, end);
		//	double length = getDimension(Base6Directions.Direction.Backward, start, end);

		//	log("width=" + width + ", height=" + height + ", length=" + length+", position="+box.Center, "printDims()", Logger.severity.TRACE);
		//}

		//private double getDimension(Base6Directions.Direction direction, Vector3D start, Vector3D end)
		//{
		//	Vector3 unit = Base6Directions.GetVector(direction);
		//	double startC = start.Dot(unit);
		//	double endC = end.Dot(unit);

		//	return Math.Abs(startC - endC);
		//}

		private bool tryAddAttached(AttachedGrids toAttach)
		{
			if (toAttach == this || attachedToMe.Contains(toAttach))
			{
				//log("already attached " + toAttach.DisplayName, "tryAddAttached()", Logger.severity.TRACE);
				return false;
			}
			attachedToMe.Add(toAttach);
			toAttach.tryAddAttached(this);
			//foreach (AttachedGrids attached in attachedToMe)
			//	attached.tryAddAttached(toAttach);
			log("attached " + toAttach.myGrid.DisplayName, "tryAddAttached()", Logger.severity.TRACE);
			return true;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="partner"></param>
		/// <returns>true iff a new grid was attached</returns>
		private bool isAttached_piston(AttachedGrids partner)
		{
			foreach (IMySlimBlock pistonBase in allPistonBases)
			{
				MyObjectBuilder_PistonBase builder_base = pistonBase.GetObjectBuilder() as MyObjectBuilder_PistonBase;
				long topBlockId = builder_base.TopBlockId;
				foreach (IMySlimBlock pistonTop in partner.allPistonTops)
					if (topBlockId == pistonTop.FatBlock.EntityId)
					{
						log("matched " + myGrid.DisplayName + " : " + pistonBase.FatBlock.DefinitionDisplayNameText + " to " + partner.myGrid.DisplayName + " : " + pistonTop.FatBlock.DefinitionDisplayNameText, "isAttached_piston()", Logger.severity.TRACE);
						tryAddAttached(partner);
						//partner.tryAddAttached(myGrid);
						return true;
					}
			}
			return false;
		}

		private bool isAttached_motor(AttachedGrids partner)
		{
			foreach (IMySlimBlock motorBase in allMotorBases)
			{
				MyObjectBuilder_MotorBase builder_base = motorBase.GetObjectBuilder() as MyObjectBuilder_MotorBase;
				long rotorEntityId = builder_base.RotorEntityId;
				foreach (IMySlimBlock motorRotor in partner.allMotorRotors)
					if (rotorEntityId == motorRotor.FatBlock.EntityId)
					{
						log("matched " + myGrid.DisplayName + " : " + motorBase.FatBlock.DefinitionDisplayNameText + " to " + partner.myGrid.DisplayName + " : " + motorRotor.FatBlock.DefinitionDisplayNameText, "isAttached_motor()", Logger.severity.TRACE);
						tryAddAttached(partner);
						//partner.tryAddAttached(myGrid);
						return true;
					}
			}
			return false;
		}

		private bool isAttached_connector(AttachedGrids partner)
		{
			foreach (IMySlimBlock connector in allConnectors)
			{
				MyObjectBuilder_ShipConnector builder_conn = connector.GetObjectBuilder() as MyObjectBuilder_ShipConnector;
				long connectedEntityId = builder_conn.ConnectedEntityId;
				foreach	(IMySlimBlock connectPartner in partner.allConnectors)
					if (connectedEntityId == connectPartner.FatBlock.EntityId)
					{
						log("matched " + myGrid.DisplayName + " : " + connector.FatBlock.DefinitionDisplayNameText + " to " + partner.myGrid.DisplayName + " : " + connectPartner.FatBlock.DefinitionDisplayNameText, "isAttached_connector()", Logger.severity.TRACE);
						tryAddAttached(partner);
						//partner.tryAddAttached(myGrid);
						return true;
					}
			}
			return false;
		}

		private bool isAttached_landingGear(AttachedGrids partner)
		{
			return false;
		}

		private static int searchAttached_ID = 0;
		private int mySearchAttached_ID = 0;

		public bool isGridAttached(IMyCubeGrid grid)
		{
			return isGridAttached(getFor(grid), ++searchAttached_ID);
		}

		private bool isGridAttached(AttachedGrids searchFor, int searchID)
		{
			if (searchID == mySearchAttached_ID)
				return false; // already searching
			mySearchAttached_ID = searchID;

			if (attachedToMe.Contains(searchFor))
				return true; // found it
			foreach (AttachedGrids attached in attachedToMe)
				if (attached.isGridAttached(searchFor, searchID))
					return true; // attached through another

			return false; // not attached
		}
	}
}
