﻿#define LOG_ENABLED //remove on build

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//using Sandbox.Common;
//using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
//using Sandbox.Common.ObjectBuilders.Definitions;
//using Sandbox.Definitions;
//using Sandbox.Engine;
//using Sandbox.Game;
using Sandbox.ModAPI;
using Ingame = Sandbox.ModAPI.Ingame;
//using Sandbox.ModAPI.Interfaces;
using VRageMath;

namespace Rynchodon.Autopilot
{
	class Lander
	{
		private Logger myLogger = null;
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			if (myLogger == null)
				myLogger = new Logger(myGrid.DisplayName, "Lander");
			myLogger.log(level, method, toLog);
		}
		private void alwaysLog(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			if (myLogger == null)
				myLogger = new Logger(myGrid.DisplayName, "Lander");
			myLogger.log(level, method, toLog);
		}
		private void alwaysLog(Logger.severity level, string method, string toLog)
		{
			if (myLogger == null)
				myLogger = new Logger(myGrid.DisplayName, "Lander");
			myLogger.log(level, method, toLog);
		}

		private Navigator myNav;
		private NavSettings CNS;
		private IMyCubeGrid myGrid;

		public Lander(Navigator myNav)
		{
			this.myNav = myNav;
			this.CNS = myNav.CNS;
			this.myGrid = myNav.myGrid;
		}

		internal Vector3D? targetDirection = null;
		private Vector3D? targetRoll = null;
		private bool matchOrientation_finished_rotating = false;

		public void matchOrientation()
		{
			if (targetDirection == null)
			{
				CNS.getOrientationOfDest(out targetDirection, out targetRoll);
				if (targetDirection == null)
				{ matchOrientation_clear(); return; }
				log("targetDirection=" + targetDirection + ", targetRoll=" + targetRoll, "matchOrientation()", Logger.severity.DEBUG);
				matchOrientation_finished_rotating = false;
			}
			double rotX, rotY;
			//log("my Down=" + currentRCblock.WorldMatrix.Down + ", my Right=" + currentRCblock.WorldMatrix.Right, "matchOrientation()", Logger.severity.TRACE);
			myNav.getRotationC((Vector3D)targetDirection, out rotX, out rotY);
			float rotLenSq = Math.Abs((new Vector2((float)rotX, (float)rotY)).LengthSquared());
			//if (!matchOrientation_finished_rotating && rotLenSq > rotLenSq_inflight * 10)
			if (!matchOrientation_finished_rotating && (CNS.rotateState != NavSettings.Rotating.NOT_ROTA || rotLenSq > Navigator.rotLenSq_inflight * 10))
			{
				//log("rotX=" + rotX + ", rotY=" + rotY + ", rotX/power=" + rotX / rotationPower + ", rotY/power=" + rotY / rotationPower, "matchOrientation()", Logger.severity.TRACE);
				myNav.calcAndRotate(rotX, rotY);
			}
			else
			{
				if (!matchOrientation_finished_rotating)
				{
					log("direction successfully matched rotX=" + rotX + ", rotY=" + rotY + ", " + rotLenSq + " < " + Navigator.rotLenSq_inflight, "matchOrientation()", Logger.severity.DEBUG);
					//fullStop();
					matchOrientation_finished_rotating = true;
				}

				if (targetRoll == null)
				{ matchOrientation_clear(); return; }

				// roll time
				//Sandbox.ModAPI.IMyCubeBlock navigationBlock = getNavigationBlock();
				float roll = (float)myNav.currentRCblock.WorldMatrix.Right.Dot((Vector3D)targetRoll);
				if (myNav.currentRCblock.WorldMatrix.Up.Dot((Vector3D)targetRoll) < 0)
					if (roll > 0)
						roll = 2 - roll;
					else
						roll = -2 - roll;
				roll *= myNav.rotationPower;// / 10;
				if (CNS.rollState != NavSettings.Rolling.NOT_ROLL || Math.Abs(roll) > Navigator.rotLenSq_inflight)
				{
					//log("roll=" + roll, "matchOrientation()", Logger.severity.TRACE);
					myNav.calcAndRoll(roll);
				}
				else
				{
					log("roll successfully matched, roll=" + roll, "matchOrientation()", Logger.severity.DEBUG);
					//fullStop();
					matchOrientation_clear(); return;
				}
			}
		}

		private void matchOrientation_clear()
		{
			log("clearing", "matchOrientation_clear()", Logger.severity.DEBUG);
			CNS.match_direction = null;
			CNS.match_roll = null;
			targetDirection = null;
			targetRoll = null;
		}

		public void landGrid(double pitch, double yaw)
		{
			switch (CNS.landingState)
			{
				case NavSettings.LANDING.OFF:
					{
						log("started landing procedures ", "landGrid()", Logger.severity.DEBUG);
						//CNS.match_direction = Vector3.Normalize(Vector3.Negate(CNS.landOffset));
						CNS.landingSeparateWaypoint = CNS.getWayDest();
						CNS.landingSeparateBlock = CNS.landLocalBlock;
						calcOrientationFromBlockDirection(CNS.landLocalBlock);
						matchOrientation(); // start
						CNS.landingState = NavSettings.LANDING.ORIENT;
						return;
					}
				case NavSettings.LANDING.ORIENT:
					{
						if (targetDirection != null)
							matchOrientation(); //continue
						else
						{
							log("starting to land", "landGrid()", Logger.severity.DEBUG);
							CNS.landingState = NavSettings.LANDING.LINEUP;
							//CNS.waitUntilNoCheck= DateTime.UtcNow.AddSeconds(1);
							//CNS.landOffset = Vector3.Normalize(CNS.landOffset) * 2; // reduce offset to 2 metres
						}
						return;
					}
				case NavSettings.LANDING.LINEUP:
					//log("LINEUP: getDistNavToWayDest()=" + getDistNavToWayDest(), "landGrid()", Logger.severity.TRACE);
					if (CNS.moveState == NavSettings.Moving.NOT_MOVE && myNav.getDistNavToWayDest() < 1)
						CNS.landingState = NavSettings.LANDING.LAND;
					goto case NavSettings.LANDING.LAND;
				case NavSettings.LANDING.LAND:
					{
						//log("LAND: getDistNavToWayDest()=" + getDistNavToWayDest(), "landGrid()", Logger.severity.TRACE);
						//if (getDistNavToWayDest() < 5)// && CNS.moveState == NavSettings.Moving.NOT_MOVE)
						//{
						//fullStop();
						// do lock

						if (lockLanding())
						{
							//log("locked", "landGrid()", Logger.severity.DEBUG);
							CNS.landingState = NavSettings.LANDING.LOCKED;
							myNav.reportState(Navigator.ReportableState.LANDED);
							myNav.fullStop();
							myNav.setDampeners(false); // dampeners should be off while docked, incase another grid is to fly

							CNS.atWayDest(NavSettings.TypeOfWayDest.LAND);
							CNS.waitUntilNoCheck = DateTime.UtcNow.AddSeconds(1);
							return;
						}
						//}
						//log("landing", "landGrid()", Logger.severity.TRACE);
						myNav.collisionCheckMoveAndRotate(pitch, yaw);
						//if (CNS.moveState == NavSettings.Moving.NOT_MOVE)
						//{
						//	log("re-orienting", "landGrid()", Logger.severity.TRACE);
						//	CNS.landingState = NavSettings.LANDING.ORIENT;
						//}
						//calcMoveAndRotate(pitch, yaw);
						//calcAndMove(true);
						return;
					}
				// do not access CNS.landLocalBlock or CNS.landOffset after this point
				case NavSettings.LANDING.LOCKED:
					{
						log("separate landing", "landGrid()", Logger.severity.DEBUG);
						if (!unlockLanding())
							return;
						if (CNS.landingSeparateWaypoint == null)
							alwaysLog(Logger.severity.ERROR, "landGrid()", "landingSeparateWaypoint == null");
						else
							if (CNS.addWaypoint((Vector3D)CNS.landingSeparateWaypoint))
								log("added separate waypoint", "landGrid()", Logger.severity.TRACE);
							else
								alwaysLog(Logger.severity.ERROR, "landGrid()", "failed to add separate waypoint");
						CNS.landingState = NavSettings.LANDING.SEPARATE;
						return;
					}
				case NavSettings.LANDING.SEPARATE:
					{
						//IMyPlayer controllingPlayer = MyAPIGateway.Players.GetPlayerControllingEntity(myGrid);
						//if (controllingPlayer != null) // this is a bug in Space Engineers, when undocking with a player in a passenger seat
						//{
						//	MyAPIGateway.Players.RemoveControlledEntity(myGrid);
						//	IMyPlayer originalPlayer = controllingPlayer;
						//	controllingPlayer = MyAPIGateway.Players.GetPlayerControllingEntity(myGrid);
						//	if (controllingPlayer == null)
						//		log("successfully removed player control, player = " + originalPlayer.DisplayName, "landGrid()", Logger.severity.TRACE);
						//	else
						//		alwaysLog(Logger.severity.ERROR, "landGrid()", "failed to remove player control, player = " + controllingPlayer.DisplayName);
						//}
						if (myNav.getDistNavToWayDest() < 2.5)
						{
							log("separated, landing procedures completed", "landGrid()", Logger.severity.DEBUG);
							myNav.fullStop();
							CNS.landingState = NavSettings.LANDING.OFF;
							//CNS.landLocalBlock = null;
							//CNS.landOffset = Vector3.Zero;
							CNS.landingSeparateBlock = null;
							CNS.landingSeparateWaypoint = null;
							CNS.atWayDest(NavSettings.TypeOfWayDest.WAYPOINT);
							return;
						}
						//log("moving to separate waypoint", "landGrid()", Logger.severity.TRACE);
						myNav.collisionCheckMoveAndRotate(pitch, yaw);
						//calcMoveAndRotate(pitch, yaw);
						return;
					}
			}
		}

		private MyObjectBuilder_Character hasPilot_value = null;

		private bool hasPilot()
		{
			List<Sandbox.ModAPI.IMySlimBlock> allCockpits = new List<Sandbox.ModAPI.IMySlimBlock>();
			myGrid.GetBlocks(allCockpits, block => block.FatBlock != null && block.FatBlock is Ingame.IMyCockpit);
			foreach (IMySlimBlock cockpit in allCockpits)
			{
				MyObjectBuilder_Character pilot = (cockpit.FatBlock.GetObjectBuilderCubeBlock() as MyObjectBuilder_Cockpit).Pilot;
				if (pilot != null)
				{
					if (hasPilot_value != pilot)
						log("got a pilot in " + cockpit.FatBlock.DisplayNameText + ", pilot is " + pilot.DisplayName, "hasPilot()", Logger.severity.DEBUG);
					hasPilot_value = pilot;
					return true;
				}
			}
			hasPilot_value = null;
			return false;
		}

		private bool lockLanding()
		{
			Ingame.IMyShipConnector connector = CNS.landLocalBlock as Ingame.IMyShipConnector;
			if (connector != null)
			{
				if (!connector.IsLocked) // this actually checks for ready to lock (yellow light)
				{
					connector.GetActionWithName("OnOff_On").Apply(connector); // on
					return false;
				}
				log("trying to lock connector", "lockLanding()", Logger.severity.TRACE);
				connector.GetActionWithName("SwitchLock").Apply(connector); // lock
				return true;
			}

			log("unknown lander block type", "lockLanding()", Logger.severity.INFO);
			return true;
		}

		private bool unlockLanding()
		{
			if (CNS.landingSeparateBlock == null)
			{
				alwaysLog("CNS.landingSeparateBlock == null", "unlockLanding()", Logger.severity.FATAL);
				return false; // do not allow Navigator to proceed
			}

			Ingame.IMyShipConnector connector = CNS.landingSeparateBlock as Ingame.IMyShipConnector;
			if (connector != null)
			{
				// due to a bug in Space Engineers, Autopilot should not unlock a connector while a player is in any passenger seat
				if (hasPilot())
				{
					myNav.reportState(Navigator.ReportableState.PLAYER);
					return false;
				}

				if ((CNS.landingSeparateBlock.GetObjectBuilderCubeBlock() as MyObjectBuilder_ShipConnector).Connected)
				{
					log("switching lock", "unlockLanding()", Logger.severity.TRACE);
					connector.GetActionWithName("SwitchLock").Apply(connector); // unlock
					return false;
				}
				log("turning off", "unlockLanding()", Logger.severity.TRACE);
				connector.GetActionWithName("OnOff_Off").Apply(connector); // off
				//connector.GetActionWithName("OnOff_On").Apply(connector); // on
				return true;
			}

			log("unknown separate block type: " + CNS.landingSeparateBlock.DefinitionDisplayNameText, "unlockLanding()", Logger.severity.INFO);
			return true; // assume there is nothing to unlock
		}

		private Base6Directions.Direction? direction_RCfromGrid(Base6Directions.Direction gridDirection)
		{
			IMyCubeBlock myRC = myNav.currentRCblock;
			if (myRC.Orientation.Left == gridDirection)
				return Base6Directions.Direction.Left;
			if (Base6Directions.GetFlippedDirection(myRC.Orientation.Left) == gridDirection)
				return Base6Directions.Direction.Right;
			if (myRC.Orientation.Up == gridDirection)
				return Base6Directions.Direction.Up;
			if (Base6Directions.GetFlippedDirection(myRC.Orientation.Up) == gridDirection)
				return Base6Directions.Direction.Down;
			if (myRC.Orientation.Forward == gridDirection)
				return Base6Directions.Direction.Forward;
			if (Base6Directions.GetFlippedDirection(myRC.Orientation.Forward) == gridDirection)
				return Base6Directions.Direction.Backward;

			myLogger.log(Logger.severity.ERROR, "direction_RCfromGrid", "failed to match direction: " + gridDirection);
			return null;
		}

		private Base6Directions.Direction? direction_getLandRCdirection(IMyCubeBlock block)
		{
			if (block is Ingame.IMyShipConnector)
			{
				Base6Directions.Direction? result = direction_RCfromGrid(Base6Directions.GetFlippedDirection(block.Orientation.Forward));
				log("got direction of " + result, "direction_getLandRCdirection()", Logger.severity.DEBUG);
				return result;
			}



			return null;
		}

		private void calcOrientationFromBlockDirection(IMyCubeBlock block)
		{
			if (CNS.match_direction != null)
			{
				log("already have an orientation: "+CNS.match_direction+":"+CNS.match_roll, "calcOrientationFromBlockDirection()", Logger.severity.TRACE);
				return;
			}

			Base6Directions.Direction? blockDirection = direction_getLandRCdirection(block);
			if (blockDirection == null)
			{
				alwaysLog("could not get necissary direction from block: " + block.DefinitionDisplayNameText, "calcOrientationFromBlockDirection()", Logger.severity.WARNING);
				return;
			}

			switch (blockDirection)
			{
				case Base6Directions.Direction.Forward:
					CNS.match_direction = Base6Directions.Direction.Forward;
					// roll is irrelevant
					break;
				case Base6Directions.Direction.Backward:
					CNS.match_direction = Base6Directions.Direction.Backward;
					// roll is irrelevant
					break;
				case Base6Directions.Direction.Up:
					CNS.match_direction = Base6Directions.Direction.Down;
					CNS.match_roll = Base6Directions.Direction.Backward;
					break;
				case Base6Directions.Direction.Down:
					CNS.match_direction = Base6Directions.Direction.Up;
					CNS.match_roll = Base6Directions.Direction.Forward;
					break;
				case Base6Directions.Direction.Left:
					CNS.match_direction = Base6Directions.Direction.Right;
					CNS.match_roll = Base6Directions.Direction.Up;
					break;
				case Base6Directions.Direction.Right:
					CNS.match_direction = Base6Directions.Direction.Left;
					CNS.match_roll = Base6Directions.Direction.Up;
					break;
			}
			log("blockDirection = "+blockDirection+", match_direction = "+CNS.match_direction+", match_roll = "+CNS.match_roll, "calcOrientationFromBlockDirection()", Logger.severity.DEBUG);
		}
	}
}
