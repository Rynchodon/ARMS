﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Sandbox.Common;
using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.Definitions;
using Sandbox.Engine;
using Sandbox.Game;
using Sandbox.ModAPI;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using AutoPilot;

namespace Autopilot
{
	[Sandbox.Common.MySessionComponentDescriptor(Sandbox.Common.MyUpdateOrder.BeforeSimulation)]
	public class Core : Sandbox.Common.MySessionComponentBase
	{
		private static Scripts.KSWH.MyLogger Logger;
		bool initialized;

		private int count;
		public override void UpdateBeforeSimulation()
		{
			if (!initialized)
			{
				init();
				return;
			}

			count++;
		}

		private void init()
		{
			if (Logger == null)
			{
				Logger = new Scripts.KSWH.MyLogger("Autopilot.log");
			}
			Logger.WriteLine("Initialized");

			build();
			initialized = true;
		}

		private void build()
		{
			Logger.WriteLine("building...");
			HashSet<IMyEntity> entities = new HashSet<IMyEntity>();
			MyAPIGateway.Entities.GetEntities(entities, e => e is Sandbox.ModAPI.IMyCubeGrid);
//			long playerId = MyAPIGateway.Session.Player.PlayerID;
//			Logger.WriteLine("number of entities is "+entities.Count);
			foreach (IMyEntity entity in entities)
			{
				Sandbox.ModAPI.IMyCubeGrid grid = entity as Sandbox.ModAPI.IMyCubeGrid;
				if (grid.IsStatic)// && grid.BigOwners.Contains(playerId) ) // TODO: does GridHandler already exist?
					Logger.WriteLine("static object");
				else
					new GridHandler(Logger, grid);
			}
		}
	}
}
