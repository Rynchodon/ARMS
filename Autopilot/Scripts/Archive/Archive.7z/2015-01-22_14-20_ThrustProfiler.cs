﻿#define LOG_ENABLED //remove on build

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//using Sandbox.Common;
//using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.Common.ObjectBuilders.Definitions;
//using Sandbox.Definitions;
//using Sandbox.Engine;
//using Sandbox.Game;
using Sandbox.ModAPI;
//using Ingame = Sandbox.ModAPI.Ingame;
//using Sandbox.ModAPI.Interfaces;
using VRageMath;

namespace Rynchodon.Autopilot
{
	class ThrustProfiler
	{
		private Logger myLogger = null;
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			myLogger.log(level, method, toLog);
		}

		private Dictionary<Base6Directions.Direction, float> thrustProfile;

		private static MyObjectBuilderType thrusterID = (new MyObjectBuilder_Thrust()).TypeId;

		public ThrustProfiler(IMyCubeGrid grid)
		{
			List<IMySlimBlock> thrusters = new List<IMySlimBlock>();
			grid.GetBlocks(thrusters, block => block.FatBlock != null && block.FatBlock.BlockDefinition.TypeId == thrusterID);
			foreach (IMySlimBlock thrust in thrusters)
				addRemoveThruster(thrust.FatBlock, true);

			grid.OnBlockAdded += grid_OnBlockAdded;
			grid.OnBlockRemoved += grid_OnBlockRemoved;

			myLogger = new Logger("", "ThrustProfile");
		}

		private void addRemoveThruster(IMyCubeBlock thruster, bool add)
		{
			if (thruster == null)
			{
				log("null paramter", "addRemoveThruster()", Logger.severity.TRACE);
				return;
			}

			MyObjectBuilder_ThrustDefinition thrustDef = thruster.GetObjectBuilderCubeBlock() as MyObjectBuilder_Base as MyObjectBuilder_ThrustDefinition;
			if (thrustDef == null)
			{
				log("not a thruster: "+thruster, "addRemoveThruster()", Logger.severity.DEBUG);
				return;
			}

			float change = thrustDef.ForceMagnitude;
			if (!add)
				change = -change;

			Base6Directions.Direction direction = thruster.Orientation.Forward;

			log("thrust power change " + change + ":" + direction);
			thrustProfile[direction] += change;
		}

		private void grid_OnBlockAdded(IMySlimBlock added) { addRemoveThruster(added.FatBlock, true); }

		private void grid_OnBlockRemoved(IMySlimBlock removed) { addRemoveThruster(removed.FatBlock, false); }

	}
}
