﻿using System;
using System.Collections.Generic;
//using System.Linq;
//using System.Text;

using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.ModAPI;
using Ingame = Sandbox.ModAPI.Ingame;

using VRageMath;

namespace Rynchodon.Autopilot
{
	[MyEntityComponentDescriptor(typeof(MyObjectBuilder_TurretBase))]
	public class Turret : UpdateEnforcer
	{

		private IMyCubeBlock CubeBlock;
		private Ingame.IMyLargeTurretBase TurretBase;

		protected override void DelayedInit()
		{
			CubeBlock = Entity as IMyCubeBlock;
			TurretBase = Entity as Ingame.IMyLargeTurretBase;
			myLogger = new Logger(CubeBlock.CubeGrid.DisplayName, "Turret");

			myLogger.debugLog("created for: " + bestTarget.DisplayNameText, "UpdateAfterSimulation100()", Logger.severity.TRACE);
			EnforcedUpdate = Sandbox.Common.MyEntityUpdateEnum.EACH_100TH_FRAME;
		}

		public override void Close()
		{
			CubeBlock = null;
		}

		public override void UpdateAfterSimulation100()
		{
			IMyTerminalBlock bestTarget = getBestTarget();
			if (bestTarget == null)
			{
				myLogger.debugLog("no target", "UpdateAfterSimulation100()", Logger.severity.TRACE);
				TurretBase.RequestEnable(false);
			}
			else
			{
				myLogger.debugLog("engaging: " + bestTarget.DisplayNameText, "UpdateAfterSimulation100()", Logger.severity.TRACE);
				TurretBase.RequestEnable(true);
				TurretBase.TrackTarget(bestTarget);
			}
		}

		private IMyTerminalBlock getBestTarget()
		{
			// get priorities

			// find grids
			BoundingSphereD toSearch = new BoundingSphereD(CubeBlock.GetPosition(), 500);
			List<IMyEntity> inRange = MyAPIGateway.Entities.GetEntitiesInSphere_Safe(ref toSearch);

			IMyTerminalBlock bestTarget = null;
			foreach (IMyEntity entity in inRange)
			{
				IMyCubeGrid grid = entity as IMyCubeGrid;
				if (grid == null)
					continue;

				// find targets
				IReadOnlyCollection<IMyTerminalBlock> targets = CubeGridCache.GetFor(grid).GetBlocksByDefLooseContains("Decoy");

				// get best target (line-of-sight, highest priority, closest)
				foreach (IMyTerminalBlock target in targets)
				{
					myLogger.debugLog("got target: " + target.DisplayNameText, "getBestTarget()", Logger.severity.TRACE);
					bestTarget = target;
					return bestTarget;
				}
			}
			return bestTarget;
		}



		private Logger myLogger;
		protected override void alwaysLog(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			if (myLogger == null)
				myLogger = new Logger(null, "Turret");
			myLogger.log(toLog, method, level);
		}
	}
}
