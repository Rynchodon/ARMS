﻿#define LOG_ENABLED //remove on build

using System;
using System.Collections.Generic;
//using System.Linq;
//using System.Text;

using Sandbox.Common;
using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.ModAPI;
using Ingame = Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;

namespace Rynchodon.Autopilot.Jumper
{
	[MyEntityComponentDescriptor(typeof(MyObjectBuilder_BatteryBlock))]
	public class JumpCharger : MyGameLogicComponent
	{
		public bool producer = false;

		private static string SubTypeNameLarge = "LargeBlockJumpDriveChargerBlock";
		private static string SubTypeNameSmall = "SmallBlockJumpDriveChargerBlock";

		private static Dictionary<IMyCubeBlock, JumpCharger> registry = new Dictionary<IMyCubeBlock, JumpCharger>();

		private bool initialized = false;

		private MyObjectBuilder_EntityBase builder_base = null;
		private IMyCubeBlock myBlock = null;
		private Ingame.IMyBatteryBlock myBatBlock = null;

		private ITerminalAction action_recharge = null;
		private ITerminalAction action_off = null;
		private bool recharge_toggled = false;
		private bool off_toggled = false;

		private static Logger myLogger;// = new Logger(null, "JumpCharger");
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private static void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			if (myLogger == null) myLogger = new Logger(null, "JumpCharger");
			myLogger.log(level, method, toLog);
		}
		private static void alwaysLog(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			if (myLogger == null) myLogger = new Logger(null, "JumpCharger");
			myLogger.log(level, method, toLog);
		}

		public override void Init(MyObjectBuilder_EntityBase objectBuilder)
		{
			builder_base = objectBuilder;
			Entity.NeedsUpdate |= MyEntityUpdateEnum.EACH_FRAME;
		}

		private void setup()
		{
			try
			{
				myBlock = Entity as IMyCubeBlock;
				myBatBlock = Entity as Ingame.IMyBatteryBlock;

				//log("entered Init", "Init()", Logger.severity.TRACE);
				MyObjectBuilder_BatteryBlock builder = myBlock.GetObjectBuilderCubeBlock() as MyObjectBuilder_BatteryBlock;
				if (builder == null)
				{
					log("builder is null", "Init()", Logger.severity.WARNING);
					return;
				}
				else
				{

					log("SubtypeName=" + myBlock.BlockDefinition.SubtypeName + ", SubtypeId=" + myBlock.BlockDefinition.SubtypeId, "Init()", Logger.severity.TRACE);
					if (builder.SubtypeName != SubTypeNameLarge && builder.SubtypeName != SubTypeNameSmall)
					{
						log("SubtypeName=" + builder.SubtypeName + " did not match JumpDriveCharger", "Init()", Logger.severity.TRACE);
						return; // normal battery
					}
				}

				action_recharge = myBatBlock.GetActionWithName("Recharge");
				action_off = myBatBlock.GetActionWithName("OnOff_Off");

				//log("passed tests", "Init()", Logger.severity.TRACE);

				registry.Add(myBlock, this);
				
				initialized = true;
			}
			catch (Exception e) {
				alwaysLog("failed to setup"+e, "Init()", Logger.severity.FATAL);
				Close();
			}
		}

		public override void Close()
		{
			try
			{
				Entity.NeedsUpdate = MyEntityUpdateEnum.NONE;
				registry.Remove(myBlock);
			}
			catch (Exception e)
			{
				alwaysLog("exception on removing from registry: "+e, "Close()", Logger.severity.FATAL);
			}
			myBlock = null;
		}

		~JumpCharger() { if (initialized) Close(); }

		public override void UpdateAfterSimulation()
		{
			try
			{
				if (!initialized) { setup(); return; }

				log("entered UpdateAfterSimulation", "UpdateAfterSimulation()", Logger.severity.TRACE);
				MyObjectBuilder_BatteryBlock builder = myBlock.GetObjectBuilderCubeBlock() as MyObjectBuilder_BatteryBlock;

				log("builder=" + builder + ", producer=" + builder.ProducerEnabled + ", semiauto=" + builder.SemiautoEnabled);
				// verify producer / semi-auto
				if (builder.ProducerEnabled != producer)
				{
					if (recharge_toggled)
						return;
					log("do not touch that switch! producer was " + !producer, "UpdateAfterSimulation()", Logger.severity.TRACE);
					action_recharge.Apply(myBatBlock);
					recharge_toggled = true;
				}
				else
					recharge_toggled = false;
				if (builder.SemiautoEnabled && builder.Enabled)
				{
					if (off_toggled)
						return;
					log("do not touch that switch! semiauto was on", "UpdateAfterSimulation()", Logger.severity.TRACE);
					action_off.Apply(myBatBlock);
					off_toggled = true;
				}
				else
					off_toggled = false;
			}
			catch (Exception e)
			{
				log("Exception occured: " + e, "UpdateAfterSimulation()", Logger.severity.FATAL);
				Close();
			}
		}

		public override MyObjectBuilder_EntityBase GetObjectBuilder(bool copy = false)
		{
			return builder_base;
		}
	}
}
