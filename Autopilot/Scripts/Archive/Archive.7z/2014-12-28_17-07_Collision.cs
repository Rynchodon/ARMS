﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Sandbox.Common;
using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.Definitions;
using Sandbox.Engine;
using Sandbox.Game;
using Sandbox.ModAPI;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using VRageMath;
using Autopilot;

namespace AutoPilot
{
	internal class Collision
	{
		private Vector3 start, end;

		private Sandbox.ModAPI.IMyCubeGrid myGrid;
		Sandbox.ModAPI.IMyCubeBlock myRC;
		private MyLogger logger;

		/// <summary>
		/// builds the collision object for a given RC
		/// </summary>
		/// <param name="ship"></param>
		public Collision(Sandbox.ModAPI.IMyCubeBlock remoteControl, MyLogger loggerToUse = null)
		{
			if (remoteControl == null)
				log("ArgumentNullException at collision("+ remoteControl + ")");

			logger = loggerToUse;
			myGrid = remoteControl.CubeGrid;
			myRC = remoteControl;

			Vector3[] allCorners = myGrid.LocalAABB.GetCorners();
			bool firstCorner = true;
			foreach (Vector3 corner in allCorners)
			{
				// 0,0,0 may not be part of ship, so start with a corner
				if (firstCorner)
				{
					start = corner; end = corner;
					firstCorner = false;
					continue;
				}
				//log("\tcorner: " + corner.ToString());
				if (corner.X > start.X)
					start.X = corner.X;
				else if (corner.X < end.X)
					end.X = corner.X;

				if (corner.Y > start.Y)
					start.Y = corner.Y;
				else if (corner.Y < end.Y)
					end.Y = corner.Y;

				if (corner.Z > start.Z)
					start.Z = corner.Z;
				else if (corner.Z < end.Z)
					end.Z = corner.Z;
			}
			log("ship bounds are " + end.X + ":" + start.X + ", " + end.Y + ":" + start.Y + ", " + end.Z + ":" + start.Z);
			//log("remote faces "+myRC.Orientation.Forward);
			//centreX = (int)Math.Round((start.X - end.X) / myGrid.GridSize);
			//centreY = (int)Math.Round((start.Y - end.Y) / myGrid.GridSize);
			//centreZ = (int)Math.Round((start.Z - end.Z) / myGrid.GridSize);

			RCmetresGrid = myRC.Position * myGrid.GridSize;
			radius = 0;

			// set radius to highest distance to edge from RC
			calcDistToEdge(Base6Directions.GetFlippedDirection(myRC.Orientation.Left));
			calcDistToEdge(myRC.Orientation.Left);
			calcDistToEdge(Base6Directions.GetFlippedDirection(myRC.Orientation.Up));
			calcDistToEdge(myRC.Orientation.Up);
			log("RC is at "+RCmetresGrid+", radius is now "+radius);
		}

		/// <summary>
		/// how far is the edge of the ship in the given direction
		/// </summary>
		/// <param name="direction"></param>
		/// <returns></returns>
		private float getLimit(Base6Directions.Direction direction)
		{
			Vector3 unit = Base6Directions.GetVector(direction);
			float minC = start.Dot(unit);
			float maxC = end.Dot(unit);

			if (minC > maxC)
				return minC;
			else
				return maxC;
		}

		Vector3 RCmetresGrid;
		private float radius;
		private void calcDistToEdge(Base6Directions.Direction direction)
		{
			float coordinate = RCmetresGrid.Dot(Base6Directions.GetVector(direction));
			float limit = getLimit(direction);

			float newRadius = limit - coordinate;
			if (newRadius < 0)
				log("Error at calcDistToEdge(" + direction + "): " + newRadius + "(" + limit + " - " + coordinate + ") < 0");

			//log("distance to edge "+direction+" is "+newRadius);
			radius = Math.Max(radius, newRadius);
		}

		private enum canFlyToResult : byte { CAN_FLY_TO, CAN_FLY_PART, OBSTRUCTION, DEST_GRID }
		/// <summary>
		/// only set when canFlyToResult == OBSTRUCTION
		/// </summary>
		private BoundingSphereD canFlyToObstructionSphere;

		private static int maxSpheres = 10000;
		private int spheresChecked;

		private System.Collections.Generic.IEnumerable<canFlyToResult> canFlyTo(Vector3D destination, Sandbox.ModAPI.IMyCubeGrid gridDest)
		{
			//log("canFlyTo testing from "+myRC.GetPosition()+" to "+destination);
			Spheres collSpheres = new Spheres(destination, myRC, radius, logger);
			//int sphereCount = skipSpheres;

			BoundingSphereD currentSphere;
			while (collSpheres.next(out currentSphere))
			{
				// if count > maxSpheres, pause
				if (spheresChecked >= maxSpheres)
					yield return canFlyToResult.CAN_FLY_PART; // canFlyToResult.success(spheresChecked, false);
				spheresChecked++;

				List<IMyEntity> entitiesInSphere = MyAPIGateway.Entities.GetEntitiesInSphere(ref currentSphere);
				if (entitiesInSphere.Count > 0)
				{
					foreach (IMyEntity entity in entitiesInSphere)
						if (ignoreCollision(entity))
							entitiesInSphere.Remove(entity);
					if (entitiesInSphere.Count > 0) // encountered a non-ignorable entity
					{
						if (entitiesInSphere.Contains(gridDest as IMyEntity))
							yield return canFlyToResult.DEST_GRID;
						else
						{
							yield return canFlyToResult.OBSTRUCTION; //canFlyToResult.failed(spheresChecked, entitiesInSphere, currentSphere);
							canFlyToObstructionSphere = currentSphere;
						}
						yield break;
					}
				}
			}
			// completed successfully with no obstacles
			yield return canFlyToResult.CAN_FLY_TO; //canFlyToResult.success(sphereCount, true);
		}

		public enum collisionAvoidResult : byte { NO_OBSTRUCTION, ALTERED_PATH, NO_WAY_FORWARD, AT_DEST_GRID }

		private System.Collections.Generic.IEnumerator<collisionAvoidResult> myEnumerator;

		private NavSettings CNS;
		private uint lastUpdate = 0;

		// mask for CollisionAvoidance
		public collisionAvoidResult avoidCollisions(ref NavSettings CNS, double stopFromDestGrid, uint updateCount, int tryCount = 10)
		{
			if (myEnumerator == null || lastUpdate + 1 != updateCount)
			{
				this.CNS = CNS;
				myEnumerator = collisionAvoidance(stopFromDestGrid).GetEnumerator();
			}
			lastUpdate = updateCount;
			if (!myEnumerator.MoveNext())
			{
				if (tryCount <= 0)
				{
					log("Error at Collision.avoidCollisions: too many tries");
					return collisionAvoidResult.NO_WAY_FORWARD;
				}
				myEnumerator = null;
				return avoidCollisions(ref CNS, stopFromDestGrid, updateCount, tryCount - 1);
			}
			return myEnumerator.Current;
		}

		/// <summary>
		/// be sure to get a new one after a reset, CNS changes will not be respected
		/// </summary>
		/// <param name="stopFromDestGrid">how close to destination grid to stop, if destination is a grid</param>
		/// <returns></returns>
		private System.Collections.Generic.IEnumerable<collisionAvoidResult> collisionAvoidance(double stopFromDestGrid)
		{
			Vector3D wayDest = (Vector3D)CNS.getWayDest();
			Sandbox.ModAPI.IMyCubeGrid gridDestination = CNS.gridDestination;
			spheresChecked = 0;

			foreach (canFlyToResult result in canFlyTo(wayDest, gridDestination))
			{
				switch (result)
				{
					case canFlyToResult.CAN_FLY_PART:
						yield return collisionAvoidResult.NO_OBSTRUCTION;
						spheresChecked = 0;
						break;
					case canFlyToResult.CAN_FLY_TO:
						{ yield return collisionAvoidResult.NO_OBSTRUCTION; yield break; }
					case canFlyToResult.DEST_GRID:
						if ((wayDest - myRC.GetPosition()).Length() < stopFromDestGrid)
							{ yield return collisionAvoidResult.AT_DEST_GRID; yield break; }
						else
							{ yield return collisionAvoidResult.NO_OBSTRUCTION; yield break; }
					case canFlyToResult.OBSTRUCTION:
						goto FindAlternateRoutes;
				}
			}
			log("Error at collisionAvoidance: finished canFlyTo inconclusively"); yield break;

		FindAlternateRoutes:
			Vector3D obsPos = canFlyToObstructionSphere.Center;
			Vector3D routeVector = wayDest - myRC.GetPosition();
			Vector3D[] altRoute = new Vector3D[4];
			altRoute[0] = Vector3D.CalculatePerpendicularVector(routeVector);
			altRoute[1] = routeVector.Cross(altRoute[0]);
			altRoute[2] = Vector3D.Negate(altRoute[0]);
			altRoute[3] = Vector3D.Negate(altRoute[1]);
		
			for (int multiplier = 10; multiplier < 2000; multiplier *= 2)
			{
				foreach (Vector3D direction in altRoute)
				{
					Vector3D waypoint = obsPos + multiplier * Vector3D.Normalize(direction);

					// do canFlyto for waypoint
					foreach (canFlyToResult result in canFlyTo(waypoint, null))
					{
						switch (result)
						{
							case canFlyToResult.CAN_FLY_PART:
								yield return collisionAvoidResult.NO_OBSTRUCTION;
								spheresChecked = 0;
								break;
							case canFlyToResult.CAN_FLY_TO:
								if (CNS.addWaypoint(waypoint))
								{
									log("collisionAvoidance added new waypoint " + waypoint + ", checked " + spheresChecked + " spheres");
									yield return collisionAvoidResult.ALTERED_PATH; yield break;
								}
								break;
							case canFlyToResult.OBSTRUCTION:
								// next direction
								break;
						}
					}
				}
			}
			log("Warning: no way forward" + ", checked " + spheresChecked + " spheres");
			yield return collisionAvoidResult.NO_WAY_FORWARD; yield break;
		}

		private bool ignoreCollision(IMyEntity entity)
		{
			MyObjectBuilder_EntityBase builder = entity.GetObjectBuilder();
			if (builder == null)
				return true; // do not know what this is but it is not stopping me
			if (builder is MyObjectBuilder_Character)
				return true; // squish the little shits
			if (entity == myGrid as IMyEntity)
				return true; // cannot run self over

			return false;
		}

		private string getEntityName(IMyEntity entity)
		{
			string name = entity.DisplayName;
			if (name == null || name == "")
			{
				name = entity.Name;
				if (name == null || name == "")
				{
					name = entity.GetFriendlyName();
					if (name == null || name == "")
					{
						name = "unknown";
					}
				}
			}
			MyObjectBuilder_EntityBase builder = entity.GetObjectBuilder();
			if (builder != null)
				name += "." + builder.TypeId;
			else
				name += "." + entity.EntityId;
			return name;
		}

		private void log(string toLog)
		{
			if (logger == null)
				return;
			if (Navigator.onlyLogFor != null && !Navigator.looseContains(myRC.CubeGrid.DisplayName, Navigator.onlyLogFor))
				return;
			logger.WriteLine("col(" + myGrid.DisplayName + "): " + toLog);
		}

		/// <summary>
		/// iterates over a series of BoundingSphereD between two points
		/// </summary>
		private class Spheres
		{
			private MyLogger logger;

			private Vector3D start;
			private Vector3D end;
			/// <summary>
			/// vector in the direction start to end, with magnitude of diameter
			/// </summary>
			private Vector3D startToEnd;
			private float radius;

			private int maxSphereNum;
			private int sphereNum;

			public Spheres(Vector3D end, Sandbox.ModAPI.IMyCubeBlock remoteControl, float radius, MyLogger logger = null)
			{
				this.logger = logger;
				this.end = end;
				this.start = GridWorld.RCtoWorld(remoteControl, new Vector3(0, 0, 0));
				this.radius = radius;
				sphereNum = 0;

				startToEnd = end - start; // set direction to start -> end
				maxSphereNum = (int)Math.Floor(startToEnd.Length() / (2 * radius));
				startToEnd.Normalize();
				startToEnd *= 2 * radius; // set magnitude to diameter

				//log("V3I " + new Vector3I(0, 0, -speed));
				//log("grid "+remoteControl.CubeGrid.GetPosition());
				//log("gw "+GridWorld.RCtoWorld(remoteControl, new Vector3(0,0,-speed)));
				//log("world " + remoteControl.CubeGrid.GridIntegerToWorld(new Vector3I(0, 0, -speed)));
				//log("end is " + end + ", speed is " + speed + ", dist from RC is " + (remoteControl.GetPosition() - end).Length());
			}

			public bool next(out BoundingSphereD result)
			{
				if (sphereNum > maxSphereNum)
				{
					result = new BoundingSphereD();
					return false;
				}
				Vector3D centre = start + startToEnd * sphereNum;
				sphereNum++;
				result = new BoundingSphereD(centre, radius);
				return true;
			}

			private void log(string toLog)
			{
				if (logger == null)
					return;
				logger.WriteLine("col.s: " + toLog);
			}
		}
	}
}
