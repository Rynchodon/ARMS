﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Text.RegularExpressions;
//using System.Threading;
//using System.Threading.Tasks;

using Sandbox.Common;
using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.Definitions;
using Sandbox.Engine;
using Sandbox.Game;
using Sandbox.ModAPI;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using VRageMath;
using Autopilot;

namespace AutoPilot
{
	class GridHandler
	{
		private MyLogger Logger;
		private Sandbox.ModAPI.IMyCubeGrid myGrid;

		
		private List<Sandbox.ModAPI.IMySlimBlock> remoteControlBlocks;
		private IMyControllableEntity currentRemoteControl;
		// list of sensors for proximity test

		private bool AIOverride; // overrides fetching instructions from display name
		private Queue<string> instructions;
		private Stack<Vector3D> pathToDestination;

		private navState myNavState;
		private enum navState
		{
			STOPPING,
			ROTATING,
			DEROTATE, // decelerate rotation
			MOVING,
			DEMOVE, // decelerate motion
			DESTINATION
		}

		public GridHandler(Sandbox.ModAPI.IMyCubeGrid grid, MyLogger logger=null)
		{
			Logger = logger;
			myGrid = grid;
		}

		private bool needToInit = true;

		private void init()
		{
			log("handler installing...");
			updateBlocks();

			instructions = new Queue<string>();
			pathToDestination = new Stack<Vector3D>();

			myNavState = navState.STOPPING; // do not start in navState.DESTINATION

			// register for events
			myGrid.OnBlockAdded += OnBlockAdded;
			myGrid.OnBlockOwnershipChanged += OnBlockOwnershipChanged;
			myGrid.OnBlockRemoved += OnBlockRemoved;

			needToInit = false;
		}

		private bool needToUpdateBlocks;

		/// <summary>
		/// makes a lists of all the necessary blocks in this grid
		/// </summary>
		private void updateBlocks()
		{
			needToUpdateBlocks = false;

			//	find remote control blocks
			remoteControlBlocks = new List<Sandbox.ModAPI.IMySlimBlock>();
			MyObjectBuilderType remoteControlType = (new MyObjectBuilder_RemoteControl() as MyObjectBuilder_Base).TypeId;
			myGrid.GetBlocks(remoteControlBlocks, block => block.FatBlock != null && block.FatBlock.BlockDefinition.TypeId == remoteControlType);
			log("# of RC blocks is " + remoteControlBlocks.Count);
		}

		/// <summary>
		/// Causes the ship to fly around, following instructions.
		/// Calling more often means more precise movements, calling too often (~ every frame) will break functionality.
		/// </summary>
		// TODO: add a safety to prevent too many calls
		public void update()
		{
			if (!gridCanNavigate())
				return;
			if (needToInit)
				init();
			if (needToUpdateBlocks)
				updateBlocks();
			if (waitUntil != null && waitUntil > DateTime.Now)
				return;

			if (pathToDestination.Count > 0)
			{
				if (myNavState == navState.DESTINATION)
				{
					pathToDestination.Pop();
					myNavState = navState.STOPPING;
					if (pathToDestination.Count > 0)
						log("next waypoint is " + pathToDestination.Peek());
					else
						return;
				}
				navigate(pathToDestination.Peek()); // navigate
			}
			else // no waypoints
			{
				if (instructions.Count > 0)
				{
					while (pathToDestination.Count == 0 && instructions.Count > 0) // keep adding until there is a destination
						addInstruction(instructions.Dequeue());
					if (pathToDestination.Count > 0)
						log("got a new destination");
				}
				else
					if (!AIOverride)
					{ // find a remote control with instructions
						foreach (Sandbox.ModAPI.IMySlimBlock remoteControlBlock in remoteControlBlocks)
						{
							Sandbox.ModAPI.IMyCubeBlock fatBlock = remoteControlBlock.FatBlock;
							if (remoteControlIsOn(fatBlock))
							{
								//	parse display name
								string displayName = fatBlock.DisplayNameText;
								int start = displayName.IndexOf('[') + 1;
								int end = displayName.IndexOf(']');
								if (start > 0 && end > start) // has appropriate brackets
								{
									int length = end - start;

									string[] inst = displayName.Substring(start, length).Split(':');
									instructions = new Queue<string>(inst);
									currentRemoteControl = fatBlock as IMyControllableEntity;
								}
							}
						}
					}
			}
		}

		private DateTime waitUntil;

		/// <summary>
		/// adds a single instruction to this handler
		/// </summary>
		/// <param name="instruction">the instruction to add</param>
		// TODO: add more types of instructions
		private void addInstruction(string instruction)
		{
			if (instruction.Length < 1)
				return;

			string lowerCase = instruction.ToLower();
			string data = lowerCase.Substring(1);

			switch (lowerCase[0])
			{
				case 'c': //	coordinates
					string[] coordsString = data.Split(',');
					if (coordsString.Length == 3)
					{
						double[] coordsDouble = new double[3];
						for (int i = 0; i < coordsDouble.Length; i++)
							if (!Double.TryParse(coordsString[i], out coordsDouble[i]))
							{
								return;
							}
						Vector3D destination = new Vector3D(coordsDouble[0], coordsDouble[1], coordsDouble[2]);
						if (Math.Abs((destination - myGrid.GetPosition()).Length()) > destinationRadius) // is destination far enough away to add?
							pathToDestination.Push(destination);
						return;
					}
					break;
				case 's': // how close RC needs to be to destination
					Double.TryParse(data, out destinationRadius);
					break;
				case 'w': // wait
					double seconds;
					Double.TryParse(data, out seconds);
					waitUntil = DateTime.Now.AddSeconds(seconds);
					log("setting wait for "+seconds);
					break;
				default:
					break;
			}
		}

		/// <summary>
		/// checks for is a station, is owned by current session's player
		/// </summary>
		/// <returns>iff it is possible for this grid to navigate</returns>
		public bool gridCanNavigate()
		{
			if (myGrid.IsStatic)
				return false;
			long playerId = MyAPIGateway.Session.Player.PlayerID;
			if (!(myGrid.BigOwners[0] == playerId)) // only go if first owner
				return false;

			return true;
		}

		/// <summary>
		/// checks the functional and working flags, current player owns it
		/// </summary>
		/// <param name="remoteControl">remote control to check</param>
		/// <returns>iff the remote control is functioning</returns>
		public static bool remoteControlIsOn(Sandbox.ModAPI.IMyCubeBlock remoteControl)
		{
			if (!remoteControl.IsFunctional || !remoteControl.IsWorking)
				return false;

			if (remoteControl.OwnerId != MyAPIGateway.Session.Player.PlayerID)
				return false;
				
			//MyObjectBuilder_RemoteControl builder = remoteControl.GetObjectBuilderCubeBlock() as MyObjectBuilder_RemoteControl;
			//return (builder.ControlThrusters);

			return true;
		}

		private double destinationRadius = 25;

		private double needToRotateX; // from start of rotation
		private double needToRotateY; // from start of rotation
		private double previousX;
		private double previousY;
		private double moveDistance; // from start of leg to waypoint
		private double distanceToWaypoint; // from current position
		private double previousDistance;

		private float decelerateRotation = 1f / 2f; // how much of rotation should be deceleration
		private float decelerateMovement = 1f / 3f; // how much of movement should be deceleration
		private static float decelerateAdjustment = 0.95f; // adjust decelerate by this much when overshoot/undershoot, must be > 0 and < 1

		// TODO: speed limit (movement)
		// TODO: control deceleration (movement) better
		// TODO: declerate (either) without stopping
		// TODO: proximity to obstruction
		// TODO: strafe short distances/manually
		private void navigate(Vector3D currentWaypoint)
		{
			if (currentRemoteControl == null)
			{
				log("no remote control");
				return;
			}
			if (!remoteControlIsOn(currentRemoteControl as Sandbox.ModAPI.IMyCubeBlock))
			{
				log("remote control is not on");
				return;
			}

			Vector3D displacement = currentWaypoint - myGrid.GetPosition();

			Vector3D dirNorm = Vector3D.Normalize(displacement); // unit vector
			double x = -(currentRemoteControl as IMyEntity).WorldMatrix.Up.Dot(dirNorm); // dot product to get x
			double y = -(currentRemoteControl as IMyEntity).WorldMatrix.Left.Dot(dirNorm); // dot product to get y
			

			if (Math.Abs(x) < 0.01f)
				x = 0;
			else
				x *= 10f;
			if (Math.Abs(y) < 0.01f)
				y = 0;
			else
				y *= 10f;

			if (x == 0 && y == 0)
			{
				double forw = (currentRemoteControl as IMyEntity).WorldMatrix.Forward.Dot(dirNorm); // dot product to get z
				if (forw < 0) // flying directly away from waypoint
				{
					log("need to 180");
					y = 10f;
				}
			}

			distanceToWaypoint = displacement.Length();

			if (displacement.Length() < destinationRadius) // at destination
			{
				log("reached destination");
				currentRemoteControl.MoveAndRotateStopped();
				myNavState = navState.DESTINATION;
				return;
			}

			var rot = new Vector2((float)x, (float)y);

			bool isStopped = getIsStopped(x, y, distanceToWaypoint);

			if (Math.Abs(rot.Length()) > 0) // need to rotate
			{
				switch (myNavState)
				{
					case navState.MOVING:
					case navState.DEMOVE:
						//	TODO: make minor ajustments in-flight
						if (Math.Abs(rot.Length()) > 1.0)
						{
							log("stopping to rotate");
							currentRemoteControl.MoveAndRotateStopped();
							myNavState = navState.STOPPING;
						}
						break;
					case navState.DEROTATE:
					case navState.STOPPING:
						if (isStopped)
						{
							if (myNavState == navState.DEROTATE)
							{
								int overUnder = 0;
								//	check for overshoot/undershoot
								if (x != 0)
									// assume (needToRotateX != 0)
									if ((x > 0 && needToRotateX > 0) || (x < 0 && needToRotateX < 0))
										overUnder--;
									else
										overUnder++;
								if (y != 0)
									// assume (needToRotateY != 0)
									if ((y > 0 && needToRotateY > 0) || (y < 0 && needToRotateY < 0))
										overUnder--;
									else
										overUnder++;

								if (overUnder != 0)
								{
									if (overUnder > 0)
										decelerateRotation /= decelerateAdjustment;
									else
										decelerateRotation *= decelerateAdjustment;
									log("adjusted decelerate, new value is " + decelerateRotation);
								}
							}
							log("starting rotation: " + x + ", " + y);
							needToRotateX = x;
							needToRotateY = y;
							currentRemoteControl.MoveAndRotate(Vector3D.Zero, rot, 0); // rotate towards target
							myNavState = navState.ROTATING;
						}
						break;
					case navState.ROTATING:
						// check for need to decelerate
//						log("checking rotation (" + x + ", " + y + ", " + needToRotateX + ", " + needToRotateY + ")");
						if ((needToRotateX > 0 && x < needToRotateX * decelerateRotation)
							|| (needToRotateX < 0 && x > needToRotateX * decelerateRotation)
							|| (needToRotateY > 0 && y < needToRotateY * decelerateRotation)
							|| (needToRotateY < 0 && y > needToRotateY * decelerateRotation))
						{
							log("decelerate rotation (" + x + ", " + y + ", " + needToRotateX + ", " + needToRotateY + ")");
							currentRemoteControl.MoveAndRotateStopped();
							//							var revRot = new Vector2((float)-needToRotateX, (float)-needToRotateY);
							//							rcBlock.MoveAndRotate(Vector3D.Zero, revRot, 0); // stop rotating
							myNavState = navState.DEROTATE;
						}
						break;
					default:
						break;
				}
			}
			else // no need to rotate
			{
				if (myNavState == navState.DEROTATE || myNavState == navState.ROTATING)
				{
					log("stopping rotation");
					currentRemoteControl.MoveAndRotateStopped(); // stop rotating
					myNavState = navState.STOPPING;
				}
				else // need to move
				{
					switch (myNavState)
					{
						case navState.MOVING:
							// check for need to demove
//							log("checking movement (" + displacement.Length() + ", " + moveDistance + ")");
							if (displacement.Length() < moveDistance * decelerateMovement)
							{
								log("decelerate movement (" + displacement.Length() + ", " + moveDistance + ")");
								currentRemoteControl.MoveAndRotateStopped();
								myNavState = navState.DEMOVE;
							}
							break;
						case navState.DEMOVE:
						case navState.STOPPING:
							if (isStopped)
							{
								currentRemoteControl.MoveAndRotate(Vector3D.Forward, Vector2.Zero, 0); // move
								moveDistance = distanceToWaypoint;
								log("moving " + moveDistance);
								myNavState = navState.MOVING;
							}
							break;
						default:
							break;
					}
				}
			}

			previousX = x;
			previousY = y;
			previousDistance = distanceToWaypoint;
		}

		private bool getIsStopped(double x, double y,double distance)
		{
			if (Math.Abs(x-previousX) > 0.01f)
				return false;
			if (Math.Abs(y-previousY) > 0.01f)
				return false;
			if (Math.Abs(distance - previousDistance) > 0.01f)
				return false;

			return true;
		}

		private void OnBlockOwnershipChanged(Sandbox.ModAPI.IMyCubeGrid changedBlock)
		{
			needToUpdateBlocks = true;
		}

		private void OnBlockAdded(Sandbox.ModAPI.IMySlimBlock addedBlock)
		{
			needToUpdateBlocks = true;
		}

		private void OnBlockRemoved(Sandbox.ModAPI.IMySlimBlock removedBlock)
		{
			needToUpdateBlocks = true;
		}

		private void log(string toLog)
		{
			if (Logger == null)
				return;
			Logger.WriteLine("GH("+myNavState+"): "+toLog);
		}
	}
}
