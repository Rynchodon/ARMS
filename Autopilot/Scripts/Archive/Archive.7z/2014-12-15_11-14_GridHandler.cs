﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Text.RegularExpressions;
//using System.Threading;
//using System.Threading.Tasks;

using Sandbox.Common;
using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.Definitions;
using Sandbox.Engine;
using Sandbox.Game;
using Sandbox.ModAPI;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using VRageMath;
using Autopilot;

namespace AutoPilot
{
	class GridHandler
	{
		private MyLogger Logger;
		private Sandbox.ModAPI.IMyCubeGrid myGrid;
		
		private List<Sandbox.ModAPI.IMySlimBlock> remoteControlBlocks;
		private IMyControllableEntity currentRemoteControl;
		// list of sensors for proximity test

		private bool AIOverride; // overrides fetching instructions from display name
		private string RCDisplayName; // if name changes, reset
		private Queue<string> instructions;
		private Stack<Vector3D> pathToDestination;
		private Sandbox.ModAPI.IMyCubeGrid gridDestination; // If the destination is a grid, it should be added here. This should only be checked when pathToDestination is empty.

		private navState myNavState;
		private enum navState
		{
			STOPPING,
			ROTATING,
			DEROTATE, // decelerate rotation
			MOVING,
			DEMOVE, // decelerate motion
			DESTINATION
		}

		public GridHandler(Sandbox.ModAPI.IMyCubeGrid grid, MyLogger logger=null)
		{
			Logger = logger;
			myGrid = grid;
		}

		private bool needToInit = true;

		private void init()
		{
			log("handler installing...");
			updateBlocks();

			instructions = new Queue<string>();
			pathToDestination = new Stack<Vector3D>();

			myNavState = navState.STOPPING; // do not start in navState.DESTINATION

			// register for events
			myGrid.OnBlockAdded += OnBlockAdded;
			myGrid.OnBlockOwnershipChanged += OnBlockOwnershipChanged;
			myGrid.OnBlockRemoved += OnBlockRemoved;

			reset();
			needToInit = false;
		}

		private bool needToUpdateBlocks;

		/// <summary>
		/// makes lists of all the necessary blocks in this grid
		/// </summary>
		private void updateBlocks()
		{
			needToUpdateBlocks = false;

			//	find remote control blocks
			remoteControlBlocks = new List<Sandbox.ModAPI.IMySlimBlock>();
			MyObjectBuilderType remoteControlType = (new MyObjectBuilder_RemoteControl() as MyObjectBuilder_Base).TypeId;
			myGrid.GetBlocks(remoteControlBlocks, block => block.FatBlock != null && block.FatBlock.BlockDefinition.TypeId == remoteControlType);
			log("# of RC blocks is " + remoteControlBlocks.Count);
		}

		/// <summary>
		/// Causes the ship to fly around, following instructions.
		/// Calling more often means more precise movements, calling too often (~ every frame) will break functionality.
		/// </summary>
		// TODO: add a safety to prevent too many calls
		public void update()
		{
			if (!gridCanNavigate())
				return;
			if (needToInit)
				init();
			if (needToUpdateBlocks)
				updateBlocks();
			if (waitUntil != null && waitUntil.CompareTo(DateTime.Now) > 0)
				return;

//			log("checking path");
			if (pathToDestination.Count > 0 || gridDestination != null)
			{
				if (myNavState == navState.DESTINATION)
				{
					if (pathToDestination.Count > 0)
						pathToDestination.Pop();
					else // gridDestination != null
					{
						gridDestination = null;
						destinationBlockName = null;
					}
					myNavState = navState.STOPPING;
					if (pathToDestination.Count > 0)
						log("next waypoint is " + pathToDestination.Peek());
					else
						if (gridDestination != null)
							if (destinationBlockName == null)
								log("next waypoint is a grid: "+gridDestination.DisplayName);
							else
								log("next waypoint is a block: "+destinationBlockName+" on grid"+gridDestination.DisplayName);
						else
							return;
				}
				// navigate
//				logWrite("navigating");
				if (pathToDestination.Count > 0)
				{
//					log(" to coords");
					navigate(pathToDestination.Peek());
				}
				else
					if (gridDestination != null)
						if (destinationBlockName == null)
						{
	//						log(" to grid");
							navigate(gridDestination.GetPosition());
						}
						else
						{
							// need to call findClosestCubeBlockOnGrid everytime, closest block could change
//							log(" to block");
							Sandbox.ModAPI.IMyCubeBlock closestCube = findClosestCubeBlockOnGrid(gridDestination, destinationBlockName, !isFriendly(gridDestination));
							if (closestCube == null)
							{
								log("could not get closestCube @ update()//navigate");
								reset();
								return;
							}
							else
								navigate(closestCube.GetPosition());
						}
//				log("finished navigating");
			}
			else // no waypoints
			{
//				log("no waypoints");
				if (instructions.Count > 0)
				{
					while ((pathToDestination.Count == 0 || gridDestination != null) && instructions.Count > 0) // keep adding until there is a destination
						addInstruction(instructions.Dequeue());
					if (pathToDestination.Count > 0)
						log("got a new destination");
					if (gridDestination != null)
						log("got a grid as a destination");
				}
				else
					if (!AIOverride)
					{ // find a remote control with instructions
//						log("searching for a ready remote control");
						foreach (Sandbox.ModAPI.IMySlimBlock remoteControlBlock in remoteControlBlocks)
						{
							Sandbox.ModAPI.IMyCubeBlock fatBlock = remoteControlBlock.FatBlock;
							if (remoteControlIsReady(fatBlock, true))
							{
//								log("found a ready remote control");
								//	parse display name
								string displayName = fatBlock.DisplayNameText;
								RCDisplayName = displayName;
								int start = displayName.IndexOf('[') + 1;
								int end = displayName.IndexOf(']');
								if (start > 0 && end > start) // has appropriate brackets
								{
									int length = end - start;
									string noSpaces = displayName.Substring(start, length).Replace(" ", ""); // remove all spaces
									string[] inst = noSpaces.Split(':'); // split into instructions
									instructions = new Queue<string>(inst);
									currentRemoteControl = fatBlock as IMyControllableEntity;
								}
							}
						}
					}
			}
		}

		private DateTime waitUntil;
		private string destinationBlockName;
		private bool isAMissile; // prevent grid from slowing down on approach

		/// <summary>
		/// adds a single instruction to this handler
		/// </summary>
		/// <param name="instruction">the instruction to add</param>
		// TODO: add more types of instructions
		private void addInstruction(string instruction)
		{
			string lowerCase = instruction.ToLower();
			if (instruction.Length < 2)
				return;
			string data = lowerCase.Substring(1);

			switch (lowerCase[0])
			{
				case 'b': // block, for friendly, search by name. for enemy, search by type
					destinationBlockName = data;
					return;
				case 'c': // coordinates
					string[] coordsString = data.Split(',');
					if (coordsString.Length == 3)
					{
						double[] coordsDouble = new double[3];
						for (int i = 0; i < coordsDouble.Length; i++)
							if (!Double.TryParse(coordsString[i], out coordsDouble[i]))
								return;
						Vector3D destination = new Vector3D(coordsDouble[0], coordsDouble[1], coordsDouble[2]);
						if (Math.Abs((destination - myGrid.GetPosition()).Length()) > destinationRadius) // is destination far enough away to add?
							pathToDestination.Push(destination);
					}
					return;
				case 'd': // dock, will need a target connector and a local one
					return;
				case 'e': // fly to nearest enemy, set max lock-on
				case 'm': // same as e, but will crash into target
					double maxLockOn = 0;
					Double.TryParse(data, out maxLockOn);
					Sandbox.ModAPI.IMyCubeGrid closestEnemy = findCubeGrid(false, null, destinationBlockName, maxLockOn);
					if (closestEnemy != null)
					{
						gridDestination = closestEnemy;
						if (lowerCase[0] == 'm')
							isAMissile = true;
						log("converted to missile");
					}
					return;
				case 'g': // grid, closest friendly grid that contains the string
					Sandbox.ModAPI.IMyCubeGrid closest = findCubeGrid(true, data, destinationBlockName);
					if (closest != null)
						gridDestination = closest;
					return;
				case 'o': // destination offset, should be cleared after every waypoint, should be relative to destination(not world) if it is a grid, if offset is used on a grid, match orientation
					return;
				case 'p': // how close ship needs to be to destination
					Double.TryParse(data, out destinationRadius);
					log("tried to change destinationRadius, value is " + destinationRadius);
					return;
				case 'r': // roll the ship, not sure how to describe roll
					return;
				case 'w': // wait
					double seconds = 0;
					Double.TryParse(data, out seconds);
					waitUntil = DateTime.Now.AddSeconds(seconds);
					log("setting wait for "+seconds);
					return;
				default:
					return;
			}
		}

		private static int maxLockOnRangeEnemy = 500; // only lock-onto enemies closer than this

		private Sandbox.ModAPI.IMyCubeGrid findCubeGrid(bool friend = true, string nameContains = null, string blockContains = null, double lockOnRangeEnemy = 0)
		{
			log("entered findCubeGrid: "+friend+", "+nameContains+", "+blockContains);
			string friendOrFoe;
			if (friend)
				friendOrFoe = "friendly";
			else
				friendOrFoe = "enemy";
			Sandbox.ModAPI.IMyCubeGrid closest = null;
			double distanceToClosest = 0;
			HashSet<IMyEntity> entities = new HashSet<IMyEntity>();
			MyAPIGateway.Entities.GetEntities(entities, e => e is Sandbox.ModAPI.IMyCubeGrid);
			foreach (IMyEntity entity in entities)
			{
				Sandbox.ModAPI.IMyCubeGrid grid = entity as Sandbox.ModAPI.IMyCubeGrid;
				if (grid == null)
					continue;
				if (nameContains == null || grid.DisplayName.ToLower().Contains(nameContains))
				{
					if (isFriendly(grid) != friend)
						continue;
					double distance = Math.Abs((myGrid.GetPosition() - grid.GetPosition()).Length());
					if (closest == null || distance < distanceToClosest)
					{
						if (blockContains == null || findClosestCubeBlockOnGrid(grid, blockContains, !friend, true) != null)
						{
							closest = grid;
							distanceToClosest = distance;
						}
	//					log("found first " + friendOrFoe + " grid with \"" + nameContains + "\" distance is " + distanceToClosest + " name is \"" + closest.DisplayName + "\"");
					}
/*					else
/*					{
						if (distance < distanceToClosest)
						{
							closest = grid;
							distanceToClosest = distance;
//							log("found closer " + friendOrFoe + " grid with \"" + nameContains + "\" distance is " + distanceToClosest + " name is \"" + closest.DisplayName + "\"");
						}
					}*/
				}
			}
			if (lockOnRangeEnemy < 1 || maxLockOnRangeEnemy < lockOnRangeEnemy)
				lockOnRangeEnemy = maxLockOnRangeEnemy;
			if ((friend || distanceToClosest < lockOnRangeEnemy) && (distanceToClosest > 0.1))
			{
				log("found closest " + friendOrFoe + " grid with \"" + nameContains+blockContains + "\" distance is " + distanceToClosest + " name is \"" + closest.DisplayName + "\"");
				return closest;
			}
			return null;
		}

		/// <summary>
		/// finds the closest block on a grid that contains the specified string
		/// </summary>
		/// <param name="grid"></param>
		/// <param name="blockContains"></param>
		/// <param name="searchByDefinition"></param>
		/// <returns></returns>
		private Sandbox.ModAPI.IMyCubeBlock findClosestCubeBlockOnGrid(Sandbox.ModAPI.IMyCubeGrid grid, string blockContains, bool searchByDefinition = false, bool getAny = false)
		{
			log("entered findClosestCubeBlockOnGrid: " + grid.DisplayName + ", " + blockContains + ", " + searchByDefinition + ", " + getAny);
			List<Sandbox.ModAPI.IMySlimBlock> allBlocks = new List<Sandbox.ModAPI.IMySlimBlock>();
			Sandbox.ModAPI.IMyCubeBlock closest = null;
			double distanceToClosest = 0;
			grid.GetBlocks(allBlocks);
//			log("reached for");
			foreach (Sandbox.ModAPI.IMySlimBlock blockInGrid in allBlocks)
			{
//				log("started...");
				if (blockInGrid.FatBlock == null)
					continue;
				Sandbox.ModAPI.IMyCubeBlock fatBlock = blockInGrid.FatBlock;
//				log("started " + fatBlock.DisplayNameText);
				string toSearch;
				if (searchByDefinition)
					toSearch = fatBlock.DefinitionDisplayNameText;
				else
					toSearch = fatBlock.DisplayNameText;
				toSearch = toSearch.ToLower();
//				log("searching " + toSearch + " for " + fatBlock.DisplayNameText);
				if (toSearch.Contains(blockContains))
				{
					double distance = Math.Abs((fatBlock.GetPosition() - grid.GetPosition()).Length());
					if (closest == null || distance < distanceToClosest)
					{
						closest = fatBlock;
						distanceToClosest = distance;
//						log("found close grid with block that contains \"" + blockContains + "\" distance is " + distanceToClosest + " name is \"" + closest.DisplayNameText + "\" of grid \"" + grid.DisplayName + "\"");
						if (getAny)
						{
//							log("leaving findClosestCubeBlockOnGrid");
							return closest;
						}
					}
				}
//				log("finished "+fatBlock.DisplayNameText);
			}
			if (closest != null)
				log("found closest grid with block that contains \"" + blockContains + "\" distance is " + distanceToClosest + " name is \"" + closest.DisplayNameText + "\" of grid \"" + grid.DisplayName + "\"");
//			log("leaving findClosestCubeBlockOnGrid");
			return closest;
		}

		/// <summary>
		/// does this id belong to a friendly player
		/// </summary>
		/// <param name="playerID"></param>
		/// <returns></returns>
		public static bool isFriendly(long playerID)
		{
			long localPlayerID = MyAPIGateway.Session.Player.PlayerID;
			if (localPlayerID == playerID)
				return true;

			// TODO: add alliance test
			return false;
		}

		/// <summary>
		/// is this grid friendly with the player
		/// </summary>
		/// <param name="grid"></param>
		/// <returns></returns>
		public static bool isFriendly(Sandbox.ModAPI.IMyCubeGrid grid)
		{
			foreach(long playerID in grid.BigOwners)
				if (isFriendly(playerID))
					return true;
			return false;
		}

/*		/// <summary>
		/// is this block friendly with the player
		/// </summary>
		/// <param name="?"></param>
		/// <returns></returns>
		private static bool isFriendly(Sandbox.ModAPI.IMyCubeBlock block)
		{
			return isFriendly(block.OwnerId);
		}*/

		/// <summary>
		/// checks for is a station, is owned by current session's player
		/// </summary>
		/// <returns>true iff it is possible for this grid to navigate</returns>
		public bool gridCanNavigate()
		{
/*			if (myGrid == null)
			{
				log("grid is gone...");
				return false;
			}*/
			if (myGrid.IsStatic)
				return false;
			long playerId = MyAPIGateway.Session.Player.PlayerID;
			if (myGrid.BigOwners.Count < 1 || !(myGrid.BigOwners[0] == playerId)) // only go if first owner
				return false;

			return true;
		}

		/// <summary>
		/// checks the functional and working flags, current player owns it, display name has not changed
		/// </summary>
		/// <param name="remoteControl">remote control to check</param>
		/// <returns>true iff the remote control is ready</returns>
		private bool remoteControlIsReady(Sandbox.ModAPI.IMyCubeBlock remoteControl, bool skipNameCheck=false)
		{
			if (remoteControl == null)
				return false;

			if (!remoteControl.IsFunctional || !remoteControl.IsWorking)
				return false;

			if (remoteControl.OwnerId != MyAPIGateway.Session.Player.PlayerID)
				return false;

			if (skipNameCheck)
				return true;
			return (remoteControl.DisplayNameText.Equals(RCDisplayName));
		}

		/// <summary>
		/// stop the ship, return navigation variables to their defaults
		/// </summary>
		private void reset()
		{
			log("resetting");
			if (currentRemoteControl != null)
			{
				currentRemoteControl.MoveAndRotateStopped();
				currentRemoteControl = null;
			}
			myNavState = navState.STOPPING;
			destinationRadius = 25;
			isAMissile = false;
			waitUntil = DateTime.Now;
			gridDestination = null;
			destinationBlockName = null;
			instructions.Clear();
			pathToDestination.Clear();
		}

		private double destinationRadius;

		private double needToRotateX; // from start of rotation
		private double needToRotateY; // from start of rotation
		private double? previousX = null;
		private double? previousY = null;
		private double moveDistance; // from start of leg to waypoint
		private double distanceToWaypoint; // from current position
		private double previousDistance;
		private DateTime? previousTime = null;
		private double movementSpeed;
		private double? previousMovementSpeed = null;
		private double movementAcceleration;

		private float decelerateRotation = 1f / 2f; // how much of rotation should be deceleration
		private float decelerateMovement = 1f / 2f; // how much of movement should be deceleration, only used when grid's deceleration is unknown
		private static float decelerateAdjustmentOver = 0.90f; // adjust decelerate by this much when overshoot, must be > 0 and < 1
		private static float decelerateAdjustmentUnder = 0.95f; // adjust decelerate by this much when undershoot, must be > 0 and < 1

		// TODO: speed limit (movement)
		// TODO: control deceleration (movement) better
		// TODO: declerate (either) without stopping
		// TODO: proximity to obstruction
		// TODO: strafe short distances/manually
		// TODO: for midflight adjustments, rotate, disable reverse thrusters, use stop function
		// TODO: do not wait for stop moving to rotate, can't move while rotating though
		private void navigate(Vector3D currentWaypoint)
		{
//			log("entered navigate(" + currentWaypoint + ")");
			if (!remoteControlIsReady(currentRemoteControl as Sandbox.ModAPI.IMyCubeBlock))
			{
				log("remote control is not ready");
				reset();
				return;
			}

			Vector3D displacement = currentWaypoint - myGrid.GetPosition();

			Vector3D dirNorm = Vector3D.Normalize(displacement); // unit vector
			double x = (currentRemoteControl as IMyEntity).WorldMatrix.Down.Dot(dirNorm);
			double y = (currentRemoteControl as IMyEntity).WorldMatrix.Right.Dot(dirNorm);
			double forw = (currentRemoteControl as IMyEntity).WorldMatrix.Forward.Dot(dirNorm);

			if (forw < 0)
			{
				logWrite("location is behind (x, y) is ("+x+", "+y+")");
				if (x > 0)
					x = 2 - x;
				else
					x = -2 - x;
//				if (y > 0)
//					y = 2 - y;
//				else
//					y = -2 - y;
				log(", new (x, y) is (" + x + ", " + y + ")");
			}

			if (Math.Abs(x) < 0.01f)
				x = 0;
			else
				x *= 10f;
			if (Math.Abs(y) < 0.01f)
				y = 0;
			else
				y *= 10f;

/*			if (x == 0 && y == 0)
			{
				double forw = (currentRemoteControl as IMyEntity).WorldMatrix.Forward.Dot(dirNorm);
				if (forw < 0) // flying directly away from waypoint
				{
					log("need to 180");
					y = 10f;
				}
			}*/

			distanceToWaypoint = displacement.Length();

			if (displacement.Length() < destinationRadius && !isAMissile) // at destination
			{
				log("reached destination");
				currentRemoteControl.MoveAndRotateStopped();
				myNavState = navState.DESTINATION;
				return;
			}

			if (myNavState == navState.DEMOVE)
			{
				// calculate speed & acceleration
				DateTime currentTime = DateTime.UtcNow;
				if (previousX != null && previousY != null && previousTime != null)
				{

					double elapsedTime = ((TimeSpan)(currentTime - previousTime)).TotalSeconds;
					double distanceTraveled = (new Vector2((float)(previousX - x), (float)(previousY - y))).Length();
					movementSpeed = distanceTraveled / elapsedTime;
					if (previousMovementSpeed != null)
					{
						movementAcceleration = (double)((movementSpeed - previousMovementSpeed) / elapsedTime);
						log("traveled " + distanceTraveled + "speed is " + movementSpeed + " and acceleration is " + movementAcceleration);
					}
				}
				previousTime = currentTime;
			}

			var rot = new Vector2((float)x, (float)y);

			bool isStopped = getIsStopped(x, y, distanceToWaypoint);
			if (isStopped)
//				if (myNavState != navState.MOVING && myNavState)
					myNavState = navState.STOPPING;

			if (Math.Abs(rot.Length()) > 0) // need to rotate
			{
				switch (myNavState)
				{
					case navState.MOVING:
					case navState.DEMOVE:
						//	TODO: make minor ajustments in-flight
						if (Math.Abs(rot.Length()) > 1.0)
						{
							log("stopping to rotate");
							currentRemoteControl.MoveAndRotateStopped();
							myNavState = navState.STOPPING;
						}
						break;
					//case navState.DEROTATE:
					case navState.STOPPING:
						if (isStopped)
						{
							if (myNavState == navState.DEROTATE)
							{
								int overUnder = 0;
								//	check for overshoot/undershoot
								if (x != 0)
									// assume (needToRotateX != 0)
									if ((x > 0 && needToRotateX > 0) || (x < 0 && needToRotateX < 0))
										overUnder--;
									else
										overUnder++;
								if (y != 0)
									// assume (needToRotateY != 0)
									if ((y > 0 && needToRotateY > 0) || (y < 0 && needToRotateY < 0))
										overUnder--;
									else
										overUnder++;

								if (overUnder != 0)
								{
									if (overUnder > 0)
										decelerateRotation /= decelerateAdjustmentOver;
									else
										decelerateRotation *= decelerateAdjustmentUnder;
									log("adjusted decelerate, new value is " + decelerateRotation);
								}
							}
							log("starting rotation: " + x + ", " + y);
							needToRotateX = x;
							needToRotateY = y;
							currentRemoteControl.MoveAndRotate(Vector3D.Zero, rot, 0); // rotate towards target
							myNavState = navState.ROTATING;
						}
						break;
					case navState.ROTATING:
						// check for need to decelerate
//						log("checking rotation (" + x + ", " + y + ", " + needToRotateX + ", " + needToRotateY + ")");
						if ((needToRotateX > 0 && x < needToRotateX * decelerateRotation)
							|| (needToRotateX < 0 && x > needToRotateX * decelerateRotation)
							|| (needToRotateY > 0 && y < needToRotateY * decelerateRotation)
							|| (needToRotateY < 0 && y > needToRotateY * decelerateRotation))
						{
							log("decelerate rotation (" + x + ", " + y + ", " + needToRotateX + ", " + needToRotateY + ")");
							currentRemoteControl.MoveAndRotateStopped();
							//							var revRot = new Vector2((float)-needToRotateX, (float)-needToRotateY);
							//							rcBlock.MoveAndRotate(Vector3D.Zero, revRot, 0); // stop rotating
							myNavState = navState.DEROTATE;
						}
						break;
					default:
						break;
				}
			}
			else // no need to rotate
			{
				if (myNavState == navState.DEROTATE || myNavState == navState.ROTATING)
				{
					log("stopping rotation");
					currentRemoteControl.MoveAndRotateStopped(); // stop rotating
					myNavState = navState.STOPPING;
				}
				else // need to move
				{
					switch (myNavState)
					{
						case navState.MOVING:
							if (isAMissile)
								break;
							// check for need to demove
//							log("checking movement (" + displacement.Length() + ", " + moveDistance + ")");
							if (displacement.Length() < moveDistance * decelerateMovement)
							{
								log("decelerate movement (" + displacement.Length() + ", " + moveDistance + ")");
								currentRemoteControl.MoveAndRotateStopped();
								myNavState = navState.DEMOVE;
							}
							break;
						case navState.DEMOVE:
						case navState.STOPPING:
							if (isStopped)
							{
								currentRemoteControl.MoveAndRotate(Vector3D.Forward, Vector2.Zero, 0); // move
								moveDistance = distanceToWaypoint;
								log("moving " + moveDistance);
								myNavState = navState.MOVING;
							}
							break;
						default:
							break;
					}
				}
			}

			previousX = x;
			previousY = y;
			previousDistance = distanceToWaypoint;
			previousMovementSpeed = movementSpeed;
		}

		// TODO: replace with measurements of rotation, movement
		private bool getIsStopped(double x, double y, double distance)
		{
			if (previousX == null || previousY == null || previousDistance == null)
				return false;
			if (Math.Abs((double)(x-previousX)) > 0.01f)
				return false;
			if (Math.Abs((double)(y-previousY)) > 0.01f)
				return false;
			if (Math.Abs(distance - previousDistance) > 1.00f)
				return false;

			return true;
		}

		private void OnBlockOwnershipChanged(Sandbox.ModAPI.IMyCubeGrid changedBlock)
		{
			needToUpdateBlocks = true;
		}

		private void OnBlockAdded(Sandbox.ModAPI.IMySlimBlock addedBlock)
		{
			needToUpdateBlocks = true;
		}

		private void OnBlockRemoved(Sandbox.ModAPI.IMySlimBlock removedBlock)
		{
			needToUpdateBlocks = true;
		}

		private StringBuilder partialLogLine = new StringBuilder();

		/// <summary>
		/// to write multiple strings to one line, call logWrite as many times as needed then call log
		/// </summary>
		/// <param name="toLog"></param>
		private void logWrite(string toLog)
		{
			partialLogLine.Append(toLog);
		}

		private void log(string toLog)
		{
			if (Logger == null)
				return;

			Logger.WriteLine("GH(" + myGrid.DisplayName + ":" + myNavState + "): " + partialLogLine + toLog);
			partialLogLine.Clear();
		}
	}
}
