﻿#define LOG_ENABLED //remove on build

using System;
using System.Collections.Generic;
//using System.Linq;
//using System.Text;

using Sandbox.Common;
using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.ModAPI;
using Ingame = Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;

namespace Rynchodon.Autopilot.Jumper
{
	[MyEntityComponentDescriptor(typeof(MyObjectBuilder_BatteryBlock))]
	public class JumpCharger : MyGameLogicComponent
	{
		public bool producer = false;

		private static Dictionary<IMyCubeBlock, JumpCharger> registry = new Dictionary<IMyCubeBlock, JumpCharger>();

		private static string SubTypeNameLarge = "LargeBlockJumpDriveChargerBlock";
		private static string SubTypeNameSmall = "SmallBlockJumpDriveChargerBlock";

		private static ITerminalAction action_recharge = null;
		//private static ITerminalAction action_off = null;
		//private static ITerminalAction action_on = null;

		private bool toggled_recharge = false;
		private bool toggled_off_semi = false;
		private bool toggled_on_prod = false;

		private MyObjectBuilder_EntityBase builder_base = null;
		private IMyCubeBlock myBlock = null;
		private Ingame.IMyBatteryBlock myBatBlock = null;

		private bool initialized = false;

		private static Logger myLogger;
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private static void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{ alwaysLog(toLog, method, level); }
		private static void alwaysLog(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			if (myLogger == null) myLogger = new Logger(null, "JumpCharger");
			myLogger.log(level, method, toLog);
		}

		public override void Init(MyObjectBuilder_EntityBase objectBuilder)
		{
			builder_base = objectBuilder;
			Entity.NeedsUpdate |= MyEntityUpdateEnum.EACH_FRAME;
		}

		private void setup()
		{
			try
			{
				myBlock = Entity as IMyCubeBlock;
				myBatBlock = Entity as Ingame.IMyBatteryBlock;

				if (myBlock.BlockDefinition.SubtypeName != SubTypeNameLarge && myBlock.BlockDefinition.SubtypeName != SubTypeNameSmall)
				{
					// normal battery
					log("SubtypeName=" + myBlock.BlockDefinition.SubtypeName + " did not match JumpDriveCharger", "Init()", Logger.severity.TRACE);
					Entity.NeedsUpdate = MyEntityUpdateEnum.NONE;
					return;
				}

				if (action_recharge == null)
					action_recharge = myBatBlock.GetActionWithName("Recharge");
				//if (action_off == null)
				//	action_off = myBatBlock.GetActionWithName("OnOff_Off");
				//if (action_on == null)
				//	action_on = myBatBlock.GetActionWithName("OnOff_On");

				registry.Add(myBlock, this);
				initialized = true;

				log("setup OK", "setup()", Logger.severity.INFO);
			}
			catch (Exception e)
			{
				alwaysLog("failed to setup" + e, "Init()", Logger.severity.FATAL);
				Close();
			}
		}

		public override void Close()
		{
			try
			{
				Entity.NeedsUpdate = MyEntityUpdateEnum.NONE;
				registry.Remove(myBlock);
			}
			catch (Exception e)
			{ alwaysLog("exception enabled removing from registry: " + e, "Close()", Logger.severity.FATAL); }
			myBlock = null;
		}

		~JumpCharger() { if (initialized) Close(); }

		public override void UpdateAfterSimulation()
		{
			try
			{
				if (!initialized) { setup(); return; }

				MyObjectBuilder_BatteryBlock builder = myBlock.GetObjectBuilderCubeBlock() as MyObjectBuilder_BatteryBlock;
				//log("builder=" + builder + ", producer=" + builder.ProducerEnabled + ", semiauto=" + builder.SemiautoEnabled);

				// block must be enabled while producer is enabled
				if (!builder.Enabled)
				{
					if (!producer)
						return; // block is off, producer is false, do not need to change anything

					// if producer is on, block must be on
					if (!toggled_on_prod)
					{
						//action_on.Apply(myBatBlock);
						myBatBlock.RequestEnable(true);
						toggled_on_prod = true;
						log("turned block on", "UpdateAfterSimulation()", Logger.severity.DEBUG);
					}
				}
				else
					toggled_on_prod = false;

				// block's producer switch must match JumpCharger's
				if (builder.ProducerEnabled != producer)
				{
					if (!toggled_recharge)
					{
						action_recharge.Apply(myBatBlock);
						toggled_recharge = true;
						log("toggled producer to " + producer, "UpdateAfterSimulation()", Logger.severity.DEBUG);
					}
				}
				else
					toggled_recharge = false;


				log("Enabled=" + myBatBlock.Enabled+":"+builder.Enabled + ", SemiautoEnabled=" + builder.SemiautoEnabled + ", producer=" + producer, "UpdateAfterSimulation()", Logger.severity.TRACE);
				// cannot set semiauto, so if it is enabled while block should be charging, turn block off
				// TODO experiment with semiauto while using to see if it messes with intentions
				// can script toggle ProducerEnabled while semiauto is enabled?
				if (builder.Enabled && builder.SemiautoEnabled && !producer) // only care if semiauto is enabled while charging
				{
					if (!toggled_off_semi)
					{
						//action_off.Apply(myBatBlock);
						myBatBlock.RequestEnable(false);
						toggled_off_semi = true;
						log("turned block off", "UpdateAfterSimulation()", Logger.severity.DEBUG);
					}
					else
						log("waiting for block to switch off", "UpdateAfterSimulation()", Logger.severity.TRACE);
				}
				else
				{
					if (toggled_off_semi)
						log("block switched off", "UpdateAfterSimulation()", Logger.severity.TRACE);
					toggled_off_semi = false;
				}

			}
			catch (Exception e)
			{
				log("Exception occured: " + e, "UpdateAfterSimulation()", Logger.severity.FATAL);
				Close();
			}
		}

		public override MyObjectBuilder_EntityBase GetObjectBuilder(bool copy = false)
		{ return builder_base; }

		public static bool tryGetJumpCharger(out JumpCharger forBlock, IMyCubeBlock block)
		{ return registry.TryGetValue(block, out forBlock); }
	}
}
