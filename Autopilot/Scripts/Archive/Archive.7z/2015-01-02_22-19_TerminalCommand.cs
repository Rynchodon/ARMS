﻿#define LOG_ENABLED

using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;

using Sandbox.ModAPI.Interfaces;
using VRageMath;

namespace Autopilot
{
	internal class TerminalCommand
	{
		/// <summary>
		/// overrids fetching commands from display name when true
		/// </summary>
		protected bool AIOverride;
		/// <summary>
		/// current navigation settings
		/// </summary>
		protected NavSettings CNS;
		protected abstract IMyControllableEntity currentRCcontrol { get; set; }
		protected abstract Sandbox.ModAPI.IMyCubeBlock currentRCblock { get; set; }
		protected Sandbox.ModAPI.IMyCubeGrid myGrid;

		/// <summary>
		/// stops fetching commands from display name, allows the use of addCommand
		/// </summary>
		/// <param name="remoteControl">which remote control to use; if remoteControl not provided, one will be chosen</param>
		public void modTakeControl(IMyControllableEntity remoteControl = null)
		{
			log("mod taking control", "modTakeControl()", Logger.severity.INFO);
			AIOverride = true;
			reset();
			currentRCcontrol = remoteControl;
		}

		/// <summary>
		/// resume fetching commands from display name, disables addCommand
		/// </summary>
		public void modReleaseControl()
		{
			log("mod release control", "modReleaseControl()", Logger.severity.INFO);
			AIOverride = false;
			reset();
		}

		/// <summary>
		/// Adds a command or a series separated by :
		/// </summary>
		/// <param name="command">command(s) to add</param>
		/// <returns>true iff successful</returns>
		public bool addCommand(string command)
		{
			if (AIOverride == false)
				return false;

			string noSpaces = command.Replace(" ", "");
			string[] inst = noSpaces.Split(':');
			foreach (string instruction in inst)
				CNS.instructions.Enqueue(instruction);

			return true;
		}

		/// <summary>
		/// Adds a string array of commands. Each string may contain multiple commands separated by :
		/// </summary>
		/// <param name="commands">command(s) to add</param>
		/// <returns>true iff successful</returns>
		public bool addCommand(string[] commands)
		{
			if (AIOverride == false)
				return false;

			foreach (string command in commands)
				addCommand(command);

			return true;
		}

		/// <summary>
		/// Adds a command or a series separated by :
		/// </summary>
		/// <param name="command">command(s) to add</param>
		/// <returns>true iff successful</returns>
		public bool addCommand(StringBuilder command)
		{
			if (AIOverride == false)
				return false;

			addCommand(command.ToString());

			return true;
		}

		/// <summary>
		/// adds a single instruction to this handler
		/// </summary>
		/// <param name="instruction">the instruction to add</param>
		protected void addInstruction(string instruction)
		{
			//log("entered addInstruction("+instruction+")");

			string lowerCase = instruction.ToLower();
			if (instruction.Length < 2)
				return;

			string data = lowerCase.Substring(1);

			if (looseContains(instruction, "EXIT"))
			{
				CNS.EXIT = true;
				return;
			}

			switch (lowerCase[0])
			{
				case 'b': // block, for friendly, search by name. for enemy, search by type
					CNS.tempBlockName = data;
					return;
				case 'c': // coordinates
					{
						string[] coordsString = data.Split(',');
						if (coordsString.Length == 3)
						{
							double[] coordsDouble = new double[3];
							for (int i = 0; i < coordsDouble.Length; i++)
								if (!Double.TryParse(coordsString[i], out coordsDouble[i]))
									return;
							Vector3D destination = new Vector3D(coordsDouble[0], coordsDouble[1], coordsDouble[2]);
							CNS.setDestination(destination);
						}
						return;
					}
				case 'd': // dock, will need a target connector and a local one
					return;
				case 'f': // fly a given distance relative to RC
					{
						string[] coordsString = data.Split(',');
						if (coordsString.Length == 3)
						{
							double[] coordsDouble = new double[3];
							for (int i = 0; i < coordsDouble.Length; i++)
								if (!Double.TryParse(coordsString[i], out coordsDouble[i]))
									return;
							Vector3D destination = new Vector3D(coordsDouble[0], coordsDouble[1], coordsDouble[2]);
							destination = GridWorld.RCtoWorld(currentRCblock, destination);
							CNS.setDestination(destination);
						}
						return;
					}
				case 'g': // grid, closest friendly grid that contains the string
					CNS.destinationBlockName = CNS.tempBlockName;
					CNS.tempBlockName = null;
					Sandbox.ModAPI.IMyCubeBlock closestBlock;
					Sandbox.ModAPI.IMyCubeGrid closestGrid = findCubeGrid(out closestBlock, true, data, CNS.destinationBlockName);
					if (closestGrid != null)
						CNS.setDestination(closestGrid, closestBlock);
					return;
				case 'e': // fly to nearest enemy, set max lock-on, block
				case 'm': // same as e, but will crash into target
					{
						double parsed;
						if (Double.TryParse(data, out parsed))
						{
							if (lowerCase[0] == 'e')
								CNS.lockOnTarget = NavSettings.TARGET.ENEMY;
							else
								CNS.lockOnTarget = NavSettings.TARGET.MISSILE;
							CNS.lockOnRange = (int)parsed;
							CNS.lockOnBlock = CNS.tempBlockName;
							CNS.tempBlockName = null;
						}
						else
						{
							CNS.lockOnTarget = NavSettings.TARGET.OFF;
							CNS.lockOnRange = 0;
							CNS.lockOnBlock = null;
							CNS.tempBlockName = null;
							log("stopped tracking enemies");
						}
						return;
					}
				case 'o': // destination offset, should be cleared after every waypoint, should be relative to destination(not world) if it is a grid, if offset is used on a grid, match orientation

					return;
				case 'p': // how close ship needs to be to destination
					{
						double parsed;
						if (double.TryParse(data, out parsed))
							CNS.destinationRadius = (int)parsed;
						return;
					}
				case 'r': // roll the ship, not sure how to describe roll
					return;
				case 'v': // speed limits
					{
						string[] speeds = data.Split(',');
						if (speeds.Length == 2)
						{
							double[] parsedArray = new double[2];
							for (int i = 0; i < parsedArray.Length; i++)
							{
								if (!Double.TryParse(speeds[i], out parsedArray[i]))
									return;
							}
							CNS.speedCruise_external = (int)parsedArray[0];
							CNS.speedSlow_external = (int)parsedArray[1];
						}
						else
						{
							double parsed;
							if (Double.TryParse(data, out parsed))
								CNS.speedCruise_external = (int)parsed;
							return;
						}
						return;
					}
				case 'w': // wait
					double seconds = 0;
					if (Double.TryParse(data, out seconds))
					{
						if (CNS.waitUntil < DateTime.UtcNow)
							CNS.waitUntil = DateTime.UtcNow.AddSeconds(seconds);
						//if (seconds > 1.1)
						//log("setting wait for " + CNS.waitUntil);
					}
					return;
				default:
					return;
			}
		}

		public static bool looseContains(string bigstring, string substring)
		{
			bigstring = bigstring.ToLower().Replace(" ", "");
			substring = substring.ToLower().Replace(" ", "");

			return bigstring.Contains(substring);
		}

		private Logger myLogger = null;// = new Logger(myGrid.DisplayName, "Collision");
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			if (myLogger == null)
				myLogger = new Logger(myGrid.DisplayName, "TerminalCommand");
			if (myLogger.canLog(level))
				myLogger.log(level, method, toLog, CNS.moveState.ToString(), CNS.rotateState.ToString());
		}

		public abstract void reset();
		private abstract Sandbox.ModAPI.IMyCubeGrid findCubeGrid(out Sandbox.ModAPI.IMyCubeBlock closestBlock, bool friend = true, string nameContains = null, string blockContains = null, double lockOnRangeEnemy = 0);
	}
}
