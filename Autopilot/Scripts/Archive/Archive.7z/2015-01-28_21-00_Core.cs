﻿#define LOG_ENABLED //remove on build

using System;
using System.Collections.Generic;
using System.Linq;
//using System.Text;

using Sandbox.Common;
//using Sandbox.Common.Components;
//using Sandbox.Common.ObjectBuilders;
//using Sandbox.Definitions;
//using Sandbox.Engine;
//using Sandbox.Game;
using Sandbox.ModAPI;
//using Sandbox.ModAPI.Ingame;
//using Sandbox.ModAPI.Interfaces;

//using VrageLib = System.Runtime.CompilerServices;

namespace Rynchodon.Autopilot
{
	[Sandbox.Common.MySessionComponentDescriptor(Sandbox.Common.MyUpdateOrder.BeforeSimulation)]
	public class Core : Sandbox.Common.MySessionComponentBase
	{
		private static Logger myLogger = new Logger(null, "Core");
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private static void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			myLogger.log(level, method, toLog);
		}

		private static int framesBetweenUpdates = 10;

		private static Core Instance;

		private int count;
		private int gridsPerFrame;

		private Dictionary<Sandbox.ModAPI.IMyCubeGrid, Navigator> allNavigators; // for tracking which grids already have handlers and for iterating through handlers

		//private static int exceptionFramesCount = 0;

		private static bool isUpdating = false;
		public override void UpdateBeforeSimulation()
		{
			if (isUpdating || terminated)
				return;
			isUpdating = true;
			//MyAPIGateway.Parallel.Start(doUpdate, updateCallback);
			doUpdate();
			isUpdating = false;
		}

		private void updateCallback() { isUpdating = false; }

		private void doUpdate()
		{
			//if (exceptionFramesCount >= 10)
			//{
			//	if (exceptionFramesCount == 10)
			//		try
			//		{
			//			exceptionFramesCount++;
			//			MyAPIGateway.Utilities.ShowNotification("Autopilot encountered too many exceptions and has been terminated.", 1000, MyFontEnum.Red);
			//		}
			//		catch (Exception) { }
			//	return;
			//}
			//int exceptionsThisFrame = 0;

			try
			{
				//log("start update", "UpdateBeforeSimulation()", Logger.severity.TRACE);

				if (!initialized)
				{
					init();
					return;
				}
				if (!controlGrids)
				{
					return;
				}

				// distribute load over frames
				int frame = count % framesBetweenUpdates;
				if (frame == 0)
				{
					build();

					gridsPerFrame = (int)Math.Ceiling(1.0 * allNavigators.Count / framesBetweenUpdates);
					//log("count is " + allNavigators.Count + " per frame is " + gridsPerFrame, "doUpdate()", Logger.severity.TRACE);
				}

				//log("for frame " + frame + " process " + (gridsPerFrame * frame) + " through " + (gridsPerFrame * (1 + frame)), "doUpdate()", Logger.severity.TRACE);

				// if frame == 1, go from gridsPerFrame * 1 to gridsPerFrame * 2 -1
				for (int index = gridsPerFrame * frame; index < gridsPerFrame * (1 + frame); index++)
				{
					if (index >= allNavigators.Count)
						break;
					//log("frame is: "+frame+", debug: index is "+index, "doUpdate()", Logger.severity.TRACE);
					Navigator current = allNavigators.ElementAt(index).Value;

					foreach (Navigator entry in allNavigators.Values)
					{
						try
						{
							entry.update();
						}
						catch (Exception updateEx)
						{
							//exceptionsThisFrame++;
							myLogger.log(Logger.severity.FATAL, null, "Exception on update: " + updateEx);
							try
							{
								entry.reset();
							}
							catch (Exception resetEx)
							{
								//exceptionsThisFrame++;
								terminate();
								myLogger.log(Logger.severity.FATAL, null, "Exception on reset: " + resetEx);
							}
						}
					}
				}
				//log("end update", "UpdateBeforeSimulation()", Logger.severity.TRACE);
				count++;
			}
			catch (Exception coreEx)
			{
				//exceptionsThisFrame++;
				terminate();
				myLogger.log(Logger.severity.FATAL, null, "Exception in core: " + coreEx);
			}

			//if (exceptionsThisFrame == 0)
			//	exceptionFramesCount = 0;
			//else
			//	exceptionFramesCount++;
		}

		private bool terminated = false;
		private void terminate()
		{
			if (terminated)
				return;
			terminated = true;
			MyAPIGateway.Utilities.ShowNotification("Autopilot encountered an exception and has been terminated.", 10000, MyFontEnum.Red);
		}

		private static bool initialized = false;
		private static bool controlGrids = false;

		private void init()
		{
			if (MyAPIGateway.Session == null)
				return;

			Instance = this;
			
			if (!MyAPIGateway.Multiplayer.MultiplayerActive)
			{
				log("I like to play offline so I control all grids!", "init()", Logger.severity.INFO);
				controlGrids = true;
			}
			else
				if (MyAPIGateway.Multiplayer.IsServer)
				{
					log("I am a server and I control all grids!", "init()", Logger.severity.INFO);
					controlGrids = true;
				}
				else
					log("I do not get to control any grids.", "init()", Logger.severity.INFO);

			if (controlGrids)
			{
				allNavigators = new Dictionary<Sandbox.ModAPI.IMyCubeGrid, Navigator>();
				build();
			}

			Settings.open();

			initialized = true;
		}

		private void build()
		{
			HashSet<IMyEntity> entities = new HashSet<IMyEntity>();
			MyAPIGateway.Entities.GetEntities(entities, e => e is Sandbox.ModAPI.IMyCubeGrid);
			foreach (IMyEntity entity in entities)
			{
				Sandbox.ModAPI.IMyCubeGrid grid = entity as Sandbox.ModAPI.IMyCubeGrid;
				if (grid == null)
					continue;
				if (!allNavigators.ContainsKey(grid)) // && canControl(grid))
				{
					log("new grid added "+grid.DisplayName, "build", Logger.severity.INFO);
					Navigator cGridHandler = new Navigator(grid);
					allNavigators.Add(grid, cGridHandler);
				}
			}
		}

		/// <summary>
		/// as Dictionary.TryGetValue()
		/// </summary>
		/// <param name="gridToLookup"></param>
		/// <param name="navForGrid"></param>
		/// <returns></returns>
		internal static bool getNavForGrid(Sandbox.ModAPI.IMyCubeGrid gridToLookup, out Navigator navForGrid)
		{
			if (Instance == null || Instance.allNavigators == null)
			{
				navForGrid = null;
				return false;
			}
			return Instance.allNavigators.TryGetValue(gridToLookup, out navForGrid);
		}

		public static bool isHostile(long identity1, long identity2)
		{
			if (identity1 == identity2)
				return false;

			List<IMyPlayer> playerMatchingID1 = new List<IMyPlayer>();
			MyAPIGateway.Players.GetPlayers(playerMatchingID1, p => p.PlayerID == identity1);
			if (playerMatchingID1.Count > 1)
				myLogger.log(Logger.severity.WARNING, "isHostile()", "Warning: too many matching players");
			else if (playerMatchingID1.Count == 0) // no player matches ID, therefore, it must be hostile
				return true;

			return (playerMatchingID1[0].GetRelationTo(identity2) == MyRelationsBetweenPlayerAndBlock.Enemies);
		}

		public static bool isHostile(long identity, Sandbox.ModAPI.IMyCubeGrid grid)
		{
			if (grid.BigOwners.Count == 0)
				return true; // unowned is hostile

			foreach (long gridOwner in grid.BigOwners)
				if (!isHostile(identity, gridOwner))
					return false;

			return true;
		}

		public static bool isHostile(Sandbox.ModAPI.IMyCubeGrid grid1, Sandbox.ModAPI.IMyCubeGrid grid2)
		{
			if (grid1.BigOwners.Count == 0 || grid2.BigOwners.Count == 0)
				return true; // unowned is hostile

			foreach (long grid1Owner in grid1.BigOwners)
				foreach (long grid2Owner in grid2.BigOwners)
					if (!isHostile(grid1Owner, grid2Owner))
						return false;

			return true;
		}

		protected override void UnloadData()
		{
			base.UnloadData();
			Logger.Close();
			Settings.writeAll();
		}
	}
}
