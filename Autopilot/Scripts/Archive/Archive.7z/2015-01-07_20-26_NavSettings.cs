﻿#define LOG_ENABLED //remove on build

using System;
using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//using Sandbox.Common;
//using Sandbox.Common.Components;
//using Sandbox.Common.ObjectBuilders;
//using Sandbox.Definitions;
//using Sandbox.Engine;
//using Sandbox.Game;
//using Sandbox.ModAPI;
//using Sandbox.ModAPI.Ingame;
//using Sandbox.ModAPI.Interfaces;
using VRageMath;

namespace Rynchodon.Autopilot
{
	internal class NavSettings
	{
		public enum Moving : byte { NOT_MOVE, MOVING, STOP_MOVE }
		public enum Rotating : byte	{	NOT_ROTA,	ROTATING, STOP_ROTA}
		public enum Rolling : byte { NOT_ROLL, ROLLING, STOP_ROLL }

		public Moving moveState = Moving.NOT_MOVE;
		public Rotating rotateState = Rotating.NOT_ROTA;
		public Rolling rollState = Rolling.NOT_ROLL;

		//public State curNavState;
		public int destinationRadius;
		public bool isAMissile;
		public DateTime waitUntil;
		public DateTime waitUntilNoCheck;
		//public Sandbox.ModAPI.IMyCubeGrid gridDestination; // If the destination is a grid, it should be added here. This should only be checked when CNS.waypoints is empty.
		public string destinationBlockName;
		public Queue<string> instructions;
		//public Stack<Vector3D> waypoints;
		//public bool inflightAdjustment;
		//public int cruiseSpeedSet;
		//public Sandbox.ModAPI.IMyCubeBlock closestCube;
		public TARGET lockOnTarget;
		public int lockOnRange;
		public string lockOnBlock;
		public string tempBlockName;
		public bool noWayForward;
		public bool EXIT = false;
		public Vector3I destination_offset = Vector3I.Zero;
		public Base6Directions.Direction? match_direction = null; // reset on reached dest
		public Base6Directions.Direction? match_roll = null;

		//public COL_DEST collAtDest;
	//	private float distance_from_RC_to_front;

		public enum TARGET : byte { OFF, MISSILE, ENEMY }
		//public enum COL_DEST : byte { NOT_AT, AT_DEST, SLOWING, CRUISING }

		//private Navigator myNav;
		private GridDimensions myGridDims;

		public NavSettings(GridDimensions gridDims) //(Navigator nav, float distance_from_RC_to_front)
		{
			this.myGridDims = gridDims;
			//if (logger != null)
			//logger.WriteLine("initialized navigation settings");
			instructions = new Queue<string>();
			//moveState = Moving.NOT_MOVE;
			//rotateState = Rotating.NOT_ROTA;
			//destinationRadius = 100;
			isAMissile = false;
			waitUntil = DateTime.UtcNow;
			waitUntilNoCheck = DateTime.UtcNow;
			destinationBlockName = null;
			//inflightAdjustment = false;
			//cruiseSpeedSet = 100;
			closestBlock = null;
			//stoppedAfter = new TimeSpan(0, 0, 1);
			lockOnTarget = TARGET.OFF;
			lockOnRange = 0;
			lockOnBlock = null;
			tempBlockName = null;
			noWayForward = false;
			//collAtDest = COL_DEST.NOT_AT;
			speedCruise_internal = float.MaxValue;
			speedSlow_internal = float.MaxValue;
			//speedCruise_external = float.MaxValue;
			//speedSlow_external = float.MaxValue;
			//this.distance_from_RC_to_front = distance_from_RC_to_front;

			// private vars
			//myNav = nav;
			waypoints = new Stack<Vector3D>();
			coordDestination = null;
			gridDestination = null;
			//speedLimit_value = ushort.MaxValue;

			endOfCommands(); // for consistency
		}

		/// <summary>
		/// variables that need to be rest at end of commands
		/// </summary>
		public void endOfCommands()
		{
			speedCruise_external = float.MaxValue;
			speedSlow_external = float.MaxValue;
			destinationRadius = 100;
		}

		private Stack<Vector3D> waypoints;
		private Vector3D? coordDestination;
		public Sandbox.ModAPI.IMyCubeGrid gridDestination { get; private set; }
		private Sandbox.ModAPI.IMyCubeBlock closestBlock;
		/// <summary>
		/// to keep ship from moving until at least one collision check has happend.
		/// updated for new destination, not for new waypoint. updated for atWayDest
		/// </summary>
		public int collisionUpdateSinceWaypointAdded = 0;

		/// <summary>
		/// reset on Navigator.FullStop()
		/// </summary>
		public float speedCruise_internal { private get; set; }
		/// <summary>
		/// reset on Navigator.FullStop()
		/// </summary>
		public float speedSlow_internal { private get; set; }
		public float speedCruise_external { private get; set; }
		public float speedSlow_external { private get; set; }

		/*public bool speedInternalSet()
		{ return (speedCruise_internal < int.MaxValue || speedSlow_internal < int.MaxValue); }*/

		public float getSpeedCruise()
		{
			float minSetting = Math.Max(Math.Min(Math.Min(speedCruise_internal, speedCruise_external), 100), 0.1f);
			float maxSetting = getSpeedSlow();
			//log("min of (" + speedCruise_internal + ", " + speedCruise_external + ", " + maxSetting + ")", "getCruiseSpeed", Logger.severity.TRACE);
			if (minSetting < maxSetting)
				return minSetting;
			else
				return maxSetting - 1;
		}
		public float getSpeedSlow()
		{
			//log("min of (" + speedSlow_internal + ", " + speedSlow_external +")", "getSpeedSlow", Logger.severity.TRACE);
			return Math.Max(Math.Min(speedSlow_internal, speedSlow_external), 1);
		}
		public void clearSpeedInternal()
		{
			speedCruise_internal = float.MaxValue;
			speedSlow_internal = float.MaxValue;
		}

		private Logger myLogger = null;// = new Logger(myGrid.DisplayName, "Collision");
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			if (myLogger == null)
				myLogger = new Logger(myGridDims.myGrid.DisplayName, "NavSettings");
			myLogger.log(level, method, toLog);
		}

		private bool isValidDestination(double distance)
		{
			if (isAMissile || destinationRadius == 0) 
				return true;
			distance -= (double)myGridDims.distance_to_front_from_RC; // assume we are facing the right way
			return (distance > 2 * destinationRadius);
		}

		private bool isValidDestination(Vector3D destination)
		{
			if (isAMissile || destinationRadius == 0)
				return true;
			return isValidDestination(myGridDims.getRCdistanceTo(destination));
		}

		private bool isValidDestination(BoundingBoxD destination)
		{
			if (isAMissile) return true; // distance is not important for missile
			return isValidDestination(myGridDims.getRCdistanceTo(destination));
		}

		private void onWayDestAddedRemoved()
		{
			collisionUpdateSinceWaypointAdded = 0;
			gridDestination = null;
			closestBlock = null;
			if (myGridDims == null)
				myLogger.log(Logger.severity.FATAL, "onWayDestAddedRemoved()", "myGridDims == null");
		}

		public bool setDestination(Vector3D coordinates)
		{
			onWayDestAddedRemoved();
			bool isValid = isValidDestination(coordinates);
			if (isValid)
				coordDestination = coordinates;
			return isValid;
		}
		public bool setDestination(Sandbox.ModAPI.IMyCubeGrid grid)
		{
			onWayDestAddedRemoved();
			bool isValid = isValidDestination(grid.WorldAABB);
			if (isValid)
				gridDestination = grid;
			return isValid;
		}
		public bool setDestination(Sandbox.ModAPI.IMyCubeBlock block)
		{
			onWayDestAddedRemoved();
			bool isValid = isValidDestination(block.GetPosition());
			if (isValid)
			{
				gridDestination = block.CubeGrid;
				closestBlock = block;
			}
			return isValid;
		}
		/// <summary>
		/// if block is not null use it, otherwise use grid
		/// </summary>
		public bool setDestination(Sandbox.ModAPI.IMyCubeBlock block, Sandbox.ModAPI.IMyCubeGrid grid)
		{
			if (block == null)
				return setDestination(grid);
			else
				return setDestination(block);
		}
		public bool addWaypoint(Vector3D waypoint)
		{
			onWayDestAddedRemoved();
			bool isValid = isValidDestination(waypoint);
			if (isValid)
				waypoints.Push(waypoint);
			return isValid;
		}

		/// <summary>
		/// removes one waypoint or destination
		/// </summary>
		public void atWayDest()
		{
			atWayDest(getTypeOfWayDest());
		}

		/// <summary>
		/// removes one waypoint or destination of the specified type
		/// </summary>
		/// <param name="typeToRemove"></param>
		public void atWayDest(TypeOfWayDest typeToRemove)
		{
			onWayDestAddedRemoved();
			switch (typeToRemove)
			{
				case TypeOfWayDest.BLOCK:
				case TypeOfWayDest.COORDINATES:
				case TypeOfWayDest.GRID:
				case TypeOfWayDest.OFFSET:
					closestBlock = null;
					gridDestination = null;
					coordDestination = null;
					destination_offset = Vector3I.Zero;
					match_direction = null;
					match_roll = null;
					return;
				case TypeOfWayDest.WAYPOINT:
					waypoints.Pop();
					return;
				default:
					log("unknown type "+typeToRemove, "atWayDest()", Logger.severity.ERROR);
					return;
			}
		}

		/// <summary>
		/// get next waypoint or destination
		/// </summary>
		/// <returns></returns>
		public Vector3D? getWayDest()
		{
			switch(getTypeOfWayDest()){
				case TypeOfWayDest.BLOCK:
					return closestBlock.GetPosition();
				case TypeOfWayDest.OFFSET:
					return closestBlock.GetPosition() + offsetToWorld();
				case TypeOfWayDest.COORDINATES:
					return coordDestination;
				case TypeOfWayDest.GRID:
					return gridDestination.WorldAABB.Center;
				case TypeOfWayDest.WAYPOINT:
					return waypoints.Peek();
				default:
					log("unknown type " + getTypeOfWayDest(), "getWayDest()", Logger.severity.ERROR);
					return null;
			}
		}

		public string getDestGridName()
		{
			if (gridDestination == null)
				return null;
			return gridDestination.DisplayName;
		}

		public enum TypeOfWayDest : byte { NULL, COORDINATES, GRID, BLOCK, WAYPOINT, OFFSET }
		public TypeOfWayDest getTypeOfWayDest()
		{
			if (waypoints.Count > 0)
				return TypeOfWayDest.WAYPOINT;

			if (gridDestination != null)
			{
				if (closestBlock != null)
				{
					if (destination_offset == Vector3I.Zero)
						return TypeOfWayDest.BLOCK;
					else
						return TypeOfWayDest.OFFSET;
				}
				else
					return TypeOfWayDest.GRID;
			}
			
			if (coordDestination != null)
				return TypeOfWayDest.COORDINATES;

			return TypeOfWayDest.NULL;
		}

		/// <summary>
		/// from front of grid
		/// </summary>
		/// <returns></returns>
		public double getDistanceToWayDest()
		{
			return myGridDims.getRCdistanceTo((Vector3D)getWayDest());
		}

		public double getDistanceToDestGrid()
		{
			if (gridDestination == null)
			{
				log("gridDestination == null", "getDistanceToDestGrid()", Logger.severity.ERROR);
				return 0;
			}
			return myGridDims.getRCdistanceTo(gridDestination);
		}

		private Vector3D offsetToWorld()
		{
			if (destination_offset == Vector3I.Zero || closestBlock == null)
				return Vector3D.Zero;

			Vector3 local = -destination_offset * Base6Directions.GetVector(closestBlock.Orientation.Left);
			local += destination_offset * Base6Directions.GetVector(closestBlock.Orientation.Up);
			local -= destination_offset * Base6Directions.GetVector(closestBlock.Orientation.Forward);

			Vector3D world = GridWorld.gridV3toWorldRelative(gridDestination, local);

			log("offset is " + destination_offset + ", local vector is " + local + ", world vector is " + world, "offsetToWorld()");
			return world;
		}

		public void getOrientationOfDest(out Vector3D? direction, out Vector3D? roll)
		{
			switch (getTypeOfWayDest())
			{
				case TypeOfWayDest.BLOCK:
				case TypeOfWayDest.OFFSET:
					//log("match_direction=" + match_direction + ", match_roll=" + match_roll);
					if (match_direction == null) { direction = null; roll = null; return; }

					// do direction
					direction = getDirectionOfClosestBlock((Base6Directions.Direction)match_direction);

					if (match_roll == null) { roll = null; return; }

					// do roll
					roll = getDirectionOfClosestBlock((Base6Directions.Direction)match_roll);
					return;
				default:
					{
						log("orientation not supported for " + getTypeOfWayDest(), "getOrientationOfDest()", Logger.severity.DEBUG);
						direction = null; roll = null; return;
					}
			}
		}

		private Vector3D getDirectionOfClosestBlock(Base6Directions.Direction whichDir)
		{
			Base6Directions.Direction blockDirection;
			switch (match_direction)
			{
				case Base6Directions.Direction.Forward: blockDirection = closestBlock.Orientation.Forward; break;
				case Base6Directions.Direction.Backward: blockDirection = Base6Directions.GetFlippedDirection(closestBlock.Orientation.Forward); break;
				case Base6Directions.Direction.Left: blockDirection = closestBlock.Orientation.Left; break;
				case Base6Directions.Direction.Right: blockDirection = Base6Directions.GetFlippedDirection(closestBlock.Orientation.Left); break;
				case Base6Directions.Direction.Up: blockDirection = closestBlock.Orientation.Up; break;
				case Base6Directions.Direction.Down: blockDirection = Base6Directions.GetFlippedDirection(closestBlock.Orientation.Up); break;
				default:
					myLogger.log(Logger.severity.WARNING, "getDirectionOfClosestBlock()", "some kind of weird direction, using forward");
					blockDirection = Base6Directions.Direction.Forward;
					break;
			}
			Vector3 blockDirVect = Base6Directions.GetVector(blockDirection) * 1000;
			log("blockDir=" + blockDirection + ", as vect=" + blockDirVect, "getDirectionOfClosestBlock()", Logger.severity.TRACE);
			return Vector3D.Normalize(GridWorld.gridV3toWorldRelative(gridDestination, blockDirVect));
		}
	}
}
