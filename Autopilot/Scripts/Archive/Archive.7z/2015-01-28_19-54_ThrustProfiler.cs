﻿#define LOG_ENABLED //remove on build

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//using Sandbox.Common;
//using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.Common.ObjectBuilders.Definitions;
//using Sandbox.Definitions;
//using Sandbox.Engine;
//using Sandbox.Game;
using Sandbox.ModAPI;
//using Ingame = Sandbox.ModAPI.Ingame;
//using Sandbox.ModAPI.Interfaces;
using VRageMath;

namespace Rynchodon.Autopilot
{
	class ThrustProfiler
	{
		private Logger myLogger = null;
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			myLogger.log(level, method, toLog);
		}

		private IMyCubeGrid myGrid;
		private class thrust_force
		{
			//public enum dirtyness : byte  { CALC, CLEAN, DIRTY }
			//public dirtyness dirty;
			public bool dirty;
			//private float force_value;
			///// <summary>
			///// max damping power
			///// </summary>
			//public float force
			//{
			//	get { return Math.Max(force_value, small_small); }
			//	set { force_value = value; }
			//}
			private float force = 0;
			public void setForce(float value) { force = value; }
			public float addForce(float value) { force += value; return force; }
			public float getForce() { return Math.Max(force, small_small); }

			public thrust_force(float force, bool dirty) { this.force = force; this.dirty = dirty; }
		}
		/// <summary>
		/// direction shall be direction of force on ship (opposite of thruster direction)
		/// </summary>
		private Dictionary<Base6Directions.Direction, thrust_force> thrustProfile;

		private static MyObjectBuilderType thrusterID = (new MyObjectBuilder_Thrust()).TypeId;

		public ThrustProfiler(IMyCubeGrid grid)
		{
			if (grid == null)
			{ (new Logger("", "ThrustProfiler")).log(Logger.severity.FATAL, "..ctor", "null parameter"); }
			myLogger = new Logger(grid.DisplayName, "ThrustProfiler");
			myGrid = grid;

			thrustProfile = new Dictionary<Base6Directions.Direction, thrust_force>();
			foreach (Base6Directions.Direction direction in Base6Directions.EnumDirections) //Enum.GetValues(typeof(Base6Directions.Direction)))
				thrustProfile.Add(direction, new thrust_force(0, false));

			List<IMySlimBlock> thrusters = new List<IMySlimBlock>();
			grid.GetBlocks(thrusters, block => block.FatBlock != null && block.FatBlock.BlockDefinition.TypeId == thrusterID);
			foreach (IMySlimBlock thrust in thrusters)
				addRemoveThruster(thrust.FatBlock, true);

			grid.OnBlockAdded += grid_OnBlockAdded;
			grid.OnBlockRemoved += grid_OnBlockRemoved;
		}

		/// <summary>
		/// force value of dampeners
		/// </summary>
		private static float small_small = 120000, small_large = 1440000, large_small = 1000000, large_large = 12000000;

		private bool allAreCalculated = true;

		private void addRemoveThruster(IMyCubeBlock thruster, bool add)
		{
			if (thruster == null)
			{
				//log("null parameter", "addRemoveThruster()", Logger.severity.TRACE);
				return;
			}

			if (thruster.BlockDefinition.TypeId != thrusterID)
			{
				//log("not a thruster: " + thruster.DefinitionDisplayNameText, "addRemoveThruster()", Logger.severity.TRACE);
				return;
			}

			Base6Directions.Direction direction = Base6Directions.GetFlippedDirection(thruster.Orientation.Forward);
			thrust_force Tforce = thrustProfile[direction];

			float change;
			switch (thruster.BlockDefinition.SubtypeId)
			{
				case "SmallBlockSmallThrust":
					change = small_small;
					break;
				case "SmallBlockLargeThrust":
					change = small_large;
					break;
				case "LargeBlockSmallThrust":
					change = large_small;
					break;
				case "LargeBlockLargeThrust":
					change = large_large;
					break;
				default:
					if (add)
					{
						log("unknown thruster(" + thruster.DefinitionDisplayNameText + "), using small_small value", "addRemoveThruster()", Logger.severity.TRACE);
						change = small_small;
						allAreCalculated = false;
						Tforce.dirty = true ;
						break;
					}
					else // removed
					{
						log("unknown thruster(" + thruster.DefinitionDisplayNameText + "), using large_large value", "addRemoveThruster()", Logger.severity.TRACE);
						change = large_large;
						allAreCalculated = false;
						Tforce.dirty = true;
						break;
					}
			}

			if (!add)
				change = -change;

			log("thrust power change " + change + ":" + direction, "addRemoveThruster()", Logger.severity.DEBUG);

			Tforce.addForce( change);
			//if (Tforce.force < small_small)
			//{
			//	Tforce.force = small_small;
			//	log("thrustProfile["+direction+"] is too low, setting to small_small", "addRemoveThruster()", Logger.severity.TRACE);
			//}
		}

		private void grid_OnBlockAdded(IMySlimBlock added) { addRemoveThruster(added.FatBlock, true); }

		private void grid_OnBlockRemoved(IMySlimBlock removed) { addRemoveThruster(removed.FatBlock, false); }

		/// <summary>
		/// if a way is found to get max force from thruster, this method becomes unnecissary
		/// </summary>
		/// <param name="damping"></param>
		internal void assessPower(bool damping = true)
		{
			//log("entered assessPower("+damping+")", "assessPower()", Logger.severity.TRACE);

			if (allAreCalculated)
			{
				//log("all are calculated", "assessPower()", Logger.severity.TRACE);
				return;
			}

			Vector3 acceleration = myGrid.Physics.LinearAcceleration;
			if (acceleration == Vector3.Zero)
			{
				if (myGrid.Physics.CanUpdateAccelerations)
				{
					myGrid.Physics.UpdateAccelerations();
					acceleration = myGrid.Physics.LinearAcceleration;
				}
				else {
					log("cannot update accelerations", "assessPower()", Logger.severity.WARNING);
					return;
				}
			}
			if (acceleration == Vector3.Zero) // not moving
				return;

			Vector3 accelerationGridRelative = acceleration.Dot(myGrid.WorldMatrix.Right) * Base6Directions.GetVector(Base6Directions.Direction.Right);
			accelerationGridRelative += acceleration.Dot(myGrid.WorldMatrix.Up) * Base6Directions.GetVector(Base6Directions.Direction.Up);
			accelerationGridRelative += acceleration.Dot(myGrid.WorldMatrix.Backward) * Base6Directions.GetVector(Base6Directions.Direction.Backward);

			if (!damping)
				accelerationGridRelative *= 10;

			//log("accelerations: "+acceleration+", "+accelerationGridRelative, "assessPower()", Logger.severity.TRACE);

			// for each direction, if there is acceleration in that direction, compare it to current value
			foreach (Base6Directions.Direction direction in Base6Directions.EnumDirections) //Enum.GetValues(typeof(Base6Directions.Direction)))
			{
				float accelerationInDirection = accelerationGridRelative.Dot(Base6Directions.GetVector(direction));
				if (accelerationInDirection > 0)
				{
					float currentForceInDirecion = accelerationInDirection * myGrid.Physics.Mass;
					thrust_force tForce = thrustProfile[direction];
					if (tForce.dirty || currentForceInDirecion > tForce.getForce())
					{
						log("dirty="+tForce.dirty+", thrustProfile[" + direction + "].force = " + currentForceInDirecion, "assessPower()", Logger.severity.TRACE);
						tForce.setForce(currentForceInDirecion);
						tForce.dirty = false;
					}
					//else
					//	log("in direction: "+direction+", force is less: " + currentForceInDirecion + " <= " + thrustProfile[direction].force, "assessPower()", Logger.severity.TRACE);
				}
				//else
				//	log("acceleration: "+accelerationGridRelative+" is not in direction: "+direction+", dot="+accelerationInDirection, "assessPower()", Logger.severity.TRACE);
			}
		}

		/// <summary>
		/// scales a movement vector by available thrust force
		/// </summary>
		/// <param name="movement"></param>
		/// <returns></returns>
		public RelativeVector3 scaleByForce(RelativeVector3 displacement, IMyCubeBlock remote)
		{
			//log("entered scaleVector("+movement+")", "scaleVector()", Logger.severity.TRACE);
			Vector3 displacementGrid = displacement.getGrid();
			log("displacementGrid=" + displacementGrid, "scaleByForce()", Logger.severity.TRACE);

			// get force-determinant direction
			// for each thrusting direction, compare needed thrust to max available
			//float minRatio = float.MaxValue;
			float minForce = float.MaxValue;
			foreach (Base6Directions.Direction direction in Base6Directions.EnumDirections) //Enum.GetValues(typeof(Base6Directions.Direction)))
			{
				//Base6Directions.Direction blockDirection = GridWorld.reverseGetBlockDirection(remote, direction);
				//log("direction = " + direction + ", blockDirection = " + blockDirection, "scaleByForce()", Logger.severity.TRACE);
				float movementInDirection = displacementGrid.Dot(Base6Directions.GetVector(direction));
				//log("directions=" + direction + ", movementInDirection=" + movementInDirection + ", displacementGrid=" + displacementGrid + ", dirVector=" + Base6Directions.GetVector(direction), "scaleByForce()", Logger.severity.TRACE);
				if (movementInDirection > 0)
				{
					minForce = Math.Min(minForce, thrustProfile[direction].getForce());
					//log("direction is "+direction+" min force is "+minForce, "scaleByForce()", Logger.severity.TRACE);
				}
			}

			// scale thrust to min
			Vector3 scaledMovement = Vector3.Zero;
			foreach (Base6Directions.Direction direction in Base6Directions.EnumDirections) //Enum.GetValues(typeof(Base6Directions.Direction)))
			{
				//Base6Directions.Direction blockDirection = GridWorld.reverseGetBlockDirection(remote, direction);
				float movementInDirection = displacementGrid.Dot(Base6Directions.GetVector(direction));
				if (movementInDirection > 0)
				{
					float scaleFactor = minForce / thrustProfile[direction].getForce();
					scaledMovement += movementInDirection * scaleFactor * Base6Directions.GetVector(direction);
					//log("direction is " + direction + " scaled movement is " + scaledMovement, "scaleByForce()", Logger.severity.TRACE);
				}
			}

			return RelativeVector3.createFromGrid(scaledMovement, remote.CubeGrid);
			//return Vector3.Normalize(scaledMovement);
		}

		/// <summary>
		/// the approximation that is used by this method is: stopping distance = speed * speed / (max acceleration * 2)
		/// </summary>
		/// <param name="movement">the direction of movement</param>
		/// <returns></returns>
		public float getStoppindDistance()
		{
			Vector3 velocityWorld = myGrid.Physics.LinearVelocity;
			Vector3 velocityGrid = GridWorld.relative_worldToGrid(myGrid, velocityWorld);

			//log("velocityWorld=" + velocityWorld + ", velocityGrid=" + velocityGrid, "getStoppindDistance()", Logger.severity.TRACE);

			// get determinant direction
			//Base6Directions.Direction determinantDirection;
			//float determinantRatio = float.MaxValue;
			float maxStopDistance = 0;
			foreach (Base6Directions.Direction direction in Base6Directions.EnumDirections) //Enum.GetValues(typeof(Base6Directions.Direction)))
			{
				float velocityInDirection = velocityGrid.Dot(Base6Directions.GetVector(direction));
				//log("velocityInDirection=" + velocityInDirection, "getStoppindDistance()", Logger.severity.TRACE);
				if (velocityInDirection < -0.1) // direction is opposite of velocityGrid
				{
					float acceleration = Math.Min(Math.Abs(thrustProfile[direction].getForce() / myGrid.Physics.Mass), Math.Abs(velocityInDirection / 2));
					//log("thrustProfile[direction].force = " + thrustProfile[direction].getForce() + ", max acceleration = " + thrustProfile[direction].getForce() / myGrid.Physics.Mass + ", half speed = " + velocityInDirection / 2 + ", acceleration = " + acceleration + ", myGrid.Physics.Mass = " + myGrid.Physics.Mass, "getStoppindDistance()", Logger.severity.TRACE);
					float stoppingDistance = velocityInDirection * velocityInDirection / (acceleration * 2);
					maxStopDistance = Math.Max(stoppingDistance, maxStopDistance);
					//log("velocityInDirection=" + velocityInDirection + ", acceleration=" + acceleration + ", stoppingDistance=" + stoppingDistance + ", maxStopDistance=" + maxStopDistance, "getStoppindDistance()", Logger.severity.TRACE);

					//float ratio = thrustProfile[direction].force / velocityInDirection;
					//if (ratio < determinantRatio)
					//{
					//	determinantRatio = ratio;
					//	determinantDirection = direction;
					//}
				}
			}

			//log("maxStopDistance=" + maxStopDistance, "getStoppindDistance()", Logger.severity.TRACE);
			return maxStopDistance;
		}
	}
}
