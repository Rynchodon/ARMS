﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Sandbox.Common;
using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.Definitions;
using Sandbox.Engine;
using Sandbox.Game;
using Sandbox.ModAPI;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using AutoPilot;

namespace Autopilot
{
	[Sandbox.Common.MySessionComponentDescriptor(Sandbox.Common.MyUpdateOrder.BeforeSimulation)]
	public class Core : Sandbox.Common.MySessionComponentBase
	{
		private static int framesBetweenUpdates = 10;

		private static Core Instance;

		private static MyLogger Logger;
		bool initialized;

		private int count;
		private int gridsPerFrame;

		private Dictionary<Sandbox.ModAPI.IMyCubeGrid, Navigator> allNavigators; // for tracking which grids already have handlers and for iterating through handlers

		public override void UpdateBeforeSimulation()
		{
			try
			{
				if (!initialized)
				{
					init();
					return;
				}

				// distribute load over frames, because it is fun
				int frame = count % framesBetweenUpdates;
				if (frame == 0)
				{
					build();

					gridsPerFrame = (int)Math.Ceiling(1.0 * allNavigators.Count / framesBetweenUpdates);
					//Logger.WriteLine("count is " + allGridHandlers.Count + " per frame is " + gridsPerFrame);
				}

				//Logger.WriteLine("for frame "+frame+" process "+(gridsPerFrame * frame)+" through "+(gridsPerFrame * (1+frame)));

				// if frame == 1, go from gridsPerFrame * 1 to gridsPerFrame * 2 -1
				for (int index = gridsPerFrame * frame; index < gridsPerFrame * (1 + frame); index++)
				{
					if (index >= allNavigators.Count)
						break;
					//Logger.WriteLine("frame is: "+frame+", debug: index is "+index);
					Navigator current = allNavigators.ElementAt(index).Value;

					foreach (Navigator entry in allNavigators.Values)
					{
						try
						{
							entry.update();
						}
						catch (Exception e)
						{
							Logger.WriteLine("Exception on update: " + e);
							try
							{
								entry.reset();
							}
							catch (Exception e2)
							{
								Logger.WriteLine("Exception on reset: " + e2);
								// TODO blacklist broken Navigator
							}
						}
					}
				}

				count++;
			}
			catch (Exception coreEx)
			{
				Logger.WriteLine("Exception in Core: "+coreEx);
			}
		}

		private void init()
		{
			// TODO get settings from file
			if (Logger == null)
			{
				Logger = new MyLogger("Autopilot.log");
			}
			Logger.WriteLine("Initialized");
			Instance = this;

			allNavigators = new Dictionary<Sandbox.ModAPI.IMyCubeGrid, Navigator>();
			build();
			if (MyAPIGateway.Multiplayer.IsServer || !MyAPIGateway.Multiplayer.MultiplayerActive)
				controlPlayerlessGrids = true;

			initialized = true;
		}

		// TODO: rework this so only entities the session can control have Navigators
		private void build()
		{
			HashSet<IMyEntity> entities = new HashSet<IMyEntity>();
			MyAPIGateway.Entities.GetEntities(entities, e => e is Sandbox.ModAPI.IMyCubeGrid);
			foreach (IMyEntity entity in entities)
			{
				Sandbox.ModAPI.IMyCubeGrid grid = entity as Sandbox.ModAPI.IMyCubeGrid;
				if (grid == null)
					continue;
				if (!allNavigators.ContainsKey(grid))
				{
					//Logger.WriteLine("new grid added "+grid.DisplayName);
					Navigator cGridHandler = new Navigator(grid, Logger);
					allNavigators.Add(grid, cGridHandler);
				}
			}
		}

		/// <summary>
		/// as Dictionary.TryGetValue()
		/// </summary>
		/// <param name="gridToLookup"></param>
		/// <param name="navForGrid"></param>
		/// <returns></returns>
		public static bool getNavForGrid(Sandbox.ModAPI.IMyCubeGrid gridToLookup, out Navigator navForGrid)
		{
			if (Instance == null || Instance.allNavigators == null)
			{
				navForGrid = null;
				return false;
			}
			return Instance.allNavigators.TryGetValue(gridToLookup, out navForGrid);
		}

		public static bool isHostile(long identity1, long identity2)
		{
			if (identity1 == identity2)
				return false;

			List<IMyPlayer> playerMatchingID1 = new List<IMyPlayer>();
			MyAPIGateway.Players.GetPlayers(playerMatchingID1, p => p.PlayerID == identity1);
			if (playerMatchingID1.Count > 1)
				Logger.WriteLine("Exception at isFriendly(): too many matching players");
			else if (playerMatchingID1.Count == 0) // no player matches ID, therefore it must be hostile
				return true;

			return (playerMatchingID1[0].GetRelationTo(identity2) == MyRelationsBetweenPlayerAndBlock.Enemies);
		}

		public static bool isHostile(long identity, Sandbox.ModAPI.IMyCubeGrid grid)
		{
			if (grid.BigOwners.Count == 0)
				return false;

			foreach (long gridOwner in grid.BigOwners)
				if (!isHostile(identity, gridOwner))
					return false;

			return true;
		}

		public static bool isHostile(Sandbox.ModAPI.IMyCubeGrid grid1, Sandbox.ModAPI.IMyCubeGrid grid2)
		{
			if (grid1.BigOwners.Count == 0 || grid2.BigOwners.Count == 0)
				return false;

			foreach (long grid1Owner in grid1.BigOwners)
				foreach (long grid2Owner in grid2.BigOwners)
					if (!isHostile(grid1Owner, grid2Owner))
						return false;

			return true;
		}

		private static bool controlPlayerlessGrids = false;

		/// <summary>
		/// Can a block or grid with the given ID be controlled by the current session?
		/// </summary>
		/// <param name="blockGridID"></param>
		/// <returns></returns>
		public static bool canControl(long blockGridID)
		{
			if (blockGridID == MyAPIGateway.Session.Player.PlayerID)
				return true;
			if (controlPlayerlessGrids)
			{
				// if ID does not belong to a player
				List<IMyPlayer> playerMatchingID = new List<IMyPlayer>();
				MyAPIGateway.Players.GetPlayers(playerMatchingID, p => p.PlayerID == blockGridID);
				if (playerMatchingID.Count == 0)
					return true;
			}
			return false;
		}

		protected override void UnloadData()
		{
			base.UnloadData();
			Logger.Close();
			Logger = null;
		}
	}
}
