﻿using System;
using System.Collections.Generic;
//using System.Linq;
//using System.Text;

using Sandbox.ModAPI;
using VRageMath;

using Rynchodon.AntennaRelay;

namespace Rynchodon.Autopilot
{
	public class GridDestination
	{
		private Navigator myNav;

		public LastSeen gridLastSeen { get; private set; }
		private ARRemoteControl seenBy;
		public IMyCubeGrid Grid { get; private set; }
		public IMyCubeBlock Block { get; private set; }

		public GridDestination(LastSeen gridLastSeen, IMyCubeBlock destBlock, IMyCubeBlock seenBy, Navigator owner)
		{
			this.myNav = owner;
			this.gridLastSeen = gridLastSeen;
			if (!ARRemoteControl.TryGet(seenBy, out this.seenBy))
				alwaysLog("failed to get ARRemoteControl", ".ctor()", Logger.severity.ERROR);
			this.Grid = gridLastSeen.Entity as IMyCubeGrid;
			if (Grid == null)
				(new Logger(null, "GridDestination")).log(Logger.severity.FATAL, ".ctor()", "Entity is not a grid");
			this.Block = destBlock;
		}

		public bool seenRecently()
		{ return (DateTime.UtcNow - gridLastSeen.LastSeenAt).TotalSeconds < 10; }

		/// <summary>
		/// if seen within 10seconds, get the actual position. otherwise, use LastSeen.predictPosition
		/// </summary>
		/// <returns></returns>
		public Vector3D GetGridPos()
		{
			if (myNav.CNS.isAMissile)
				return calculateInterceptionPoint(false);

			if (seenRecently())
			{
				log("seen recently(" + (DateTime.UtcNow - gridLastSeen.LastSeenAt).TotalSeconds + "), using actual grid centre: " + Grid.WorldAABB.Center, "GetGridPos()", Logger.severity.TRACE);
				return Grid.WorldAABB.Center;
			}
			log("it has been a while(" + (DateTime.UtcNow - gridLastSeen.LastSeenAt).TotalSeconds + "), using prediction " + gridLastSeen.predictPosition(), "GetGridPos()", Logger.severity.TRACE);
			return gridLastSeen.predictPosition();
		}

		/// <summary>
		/// if seen within 10seconds, get the actual position. otherwise, use LastSeen.predictPosition
		/// </summary>
		/// <returns></returns>
		public Vector3D GetBlockPos()
		{
			if (myNav.CNS.isAMissile)
				return calculateInterceptionPoint(true);

			if (seenRecently())
			{
				log("seen recently(" + (DateTime.UtcNow - gridLastSeen.LastSeenAt).TotalSeconds + "), using actual block position: " + Block.GetPosition(), "GetBlockPos()", Logger.severity.TRACE);
				return Block.GetPosition();
			}
			else
			{
				log("it has been a while(" + (DateTime.UtcNow - gridLastSeen.LastSeenAt).TotalSeconds + "), using prediction " + gridLastSeen.predictPosition(), "GetBlockPos()", Logger.severity.TRACE);
				return gridLastSeen.predictPosition();
			}
		}

		private Vector3D calculateInterceptionPoint(bool block)
		{
			Vector3D targetPosition, targetVelocity, targetAcceleration;
			if (seenRecently())
			{
				if (block)
					targetPosition = Block.GetPosition();
				else
					targetPosition = Grid.WorldAABB.Center;
				targetVelocity = Grid.Physics.LinearVelocity;
				targetAcceleration = Grid.Physics.GetLinearAcceleration();
			}
			else
			{
				targetPosition = gridLastSeen.predictPosition();
				targetVelocity = gridLastSeen.LastKnownVelocity;
				targetAcceleration = Vector3.Zero;
			}
			if (targetVelocity == Vector3D.Zero)
			{
				log("shorting: target velocity is zero", "calculateInterceptionPoint()", Logger.severity.TRACE);
				return targetPosition;
			}

			//Vector3D relativePosition = targetPosition - owner.getNavigationBlock().GetPosition();
			Vector3D targetToMe = myNav.getNavigationBlock().GetPosition() - targetPosition;

			//var myPhysics = owner.myGrid.Physics;
			//if (myPhysics.CanUpdateAccelerations && myPhysics.LinearAcceleration == Vector3.Zero)
			//{
			//	myPhysics.UpdateAccelerations();
			//	log("updating my acceleration", "calculateInterceptionPoint()", Logger.severity.TRACE);
			//}
			//Vector3D myVelocity = myPhysics.LinearVelocity + myPhysics.LinearAcceleration;

			double distanceTo_PathOfTarget = Vector3D.Normalize(targetVelocity).Cross(targetToMe).Length();
			//double distanceTo_PathOfTarget = (targetToMe - (targetToMe.Dot(targetVelocity)) * targetVelocity).Length();

			//double acceleration = owner.myGrid.Physics.GetLinearAcceleration().Length();
			//double mySpeed = owner.myGrid.Physics.LinearVelocity.Length();
			//double speedRatio = owner.myGrid.Physics.LinearVelocity.Length() / targetVelocity.Length();
			//double relativeSpeed = (myNav.myGrid.Physics.LinearVelocity - targetVelocity).Length();
			//if (relativeSpeed < 1)
			//{
			//	log("setting relative speed to 1, was " + relativeSpeed, "calculateInterceptionPoint()", Logger.severity.TRACE);
			//	relativeSpeed = 1;
			//}
			//double secondsToTarget = distToDestGrid / relativeSpeed;
			//relativeSpeed += acceleration;
			//double relativeAcceleration = (owner.myGrid.Physics.GetLinearAcceleration() - targetAcceleration).Length();
			//if (relativeAcceleration < 1)
			//{
			//	log("setting relative acceleration to 1, was " + relativeAcceleration, "calculateInterceptionPoint()", Logger.severity.TRACE);
			//	relativeAcceleration = 1;
			//}
			//double secondsToTarget = (relativeSpeed + Math.Pow(-2 * relativeAcceleration * relativePosition + relativeSpeed * relativeSpeed, 1/2)) / relativeAcceleration;

			double mySpeed = Math.Max(myNav.myGrid.Physics.LinearVelocity.Length(), 1);

			//log("secondsToTarget = " + secondsToTarget + ", relativePosition = " + relativePosition + ", relativeSpeed = " + relativeSpeed + ", relativeAcceleration = " + relativeAcceleration, "calculateInterceptionPoint()", Logger.severity.DEBUG);
			double secondsToTarget = distanceTo_PathOfTarget / mySpeed;
			//double secondsToTarget = relativePosition.Length() / relativeSpeed;
			
			
			//Vector3D result = targetPosition + targetVelocity * secondsToTarget; // disregarding acceleration
			Vector3D result = targetPosition + targetVelocity * secondsToTarget + targetAcceleration * secondsToTarget * secondsToTarget / 2;
			
			//log("result = " + result + ", targetPosition = " + targetPosition + ", targetVelocity = " + targetVelocity, "calculateInterceptionPoint()", Logger.severity.DEBUG);
			return result;
		}


		private Logger myLogger;
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{ alwaysLog(toLog, method, level); }
		private void alwaysLog(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			if (myLogger == null)
			{
				if (seenBy == null || Grid == null || Block == null)
				{
					(new Logger(null, "GridDestination")).log(level, method, toLog);
					return;
				}
				myLogger = new Logger((seenBy.Entity as IMyCubeBlock).CubeGrid.DisplayName, "GridDestination");
			}
			myLogger.log(level, method, toLog, Grid.DisplayName, Block.DisplayNameText);
		}
	}
}
