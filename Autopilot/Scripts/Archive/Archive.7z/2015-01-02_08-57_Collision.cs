﻿using System;
using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//using Sandbox.Common;
//using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
//using Sandbox.Definitions;
//using Sandbox.Engine;
//using Sandbox.Game;
using Sandbox.ModAPI;
//using Sandbox.ModAPI.Ingame;
//using Sandbox.ModAPI.Interfaces;
using VRageMath;

namespace Autopilot
{
	/// <summary>
	/// pathfinder
	/// </summary>
	internal class Collision
	{
		private Vector3 start, end;

		private Sandbox.ModAPI.IMyCubeGrid myGrid;
		Sandbox.ModAPI.IMyCubeBlock myRC;

		/// <summary>
		/// builds the collision object for a given RC
		/// </summary>
		/// <param name="ship"></param>
		public Collision(Sandbox.ModAPI.IMyCubeBlock remoteControl)
		{
			if (remoteControl == null)
				log("ArgumentNullException at collision("+ remoteControl + ")");

			myGrid = remoteControl.CubeGrid;
			myRC = remoteControl;

			Vector3[] allCorners = myGrid.LocalAABB.GetCorners();
			bool firstCorner = true;
			foreach (Vector3 corner in allCorners)
			{
				// 0,0,0 may not be part of ship, so start with a corner
				if (firstCorner)
				{
					start = corner; end = corner;
					firstCorner = false;
					continue;
				}
				//log("\tcorner: " + corner.ToString());
				if (corner.X > start.X)
					start.X = corner.X;
				else if (corner.X < end.X)
					end.X = corner.X;

				if (corner.Y > start.Y)
					start.Y = corner.Y;
				else if (corner.Y < end.Y)
					end.Y = corner.Y;

				if (corner.Z > start.Z)
					start.Z = corner.Z;
				else if (corner.Z < end.Z)
					end.Z = corner.Z;
			}
			log("ship bounds are " + end.X + ":" + start.X + ", " + end.Y + ":" + start.Y + ", " + end.Z + ":" + start.Z);
			//log("remote faces "+myRC.Orientation.Forward);
			//centreX = (int)Math.Round((start.X - end.X) / myGrid.GridSize);
			//centreY = (int)Math.Round((start.Y - end.Y) / myGrid.GridSize);
			//centreZ = (int)Math.Round((start.Z - end.Z) / myGrid.GridSize);

			RCmetresGrid = myRC.Position * myGrid.GridSize;
			radius = 0;

			// set radius to highest distance to edge from RC
			calcDistToEdge(Base6Directions.GetFlippedDirection(myRC.Orientation.Left));
			calcDistToEdge(myRC.Orientation.Left);
			calcDistToEdge(Base6Directions.GetFlippedDirection(myRC.Orientation.Up));
			calcDistToEdge(myRC.Orientation.Up);
			log("RC is at "+RCmetresGrid+", radius is now "+radius);
		}

		/// <summary>
		/// how far is the edge of the ship in the given direction
		/// </summary>
		/// <param name="direction"></param>
		/// <returns></returns>
		private float getLimit(Base6Directions.Direction direction)
		{
			Vector3 unit = Base6Directions.GetVector(direction);
			float minC = start.Dot(unit);
			float maxC = end.Dot(unit);

			if (minC > maxC)
				return minC;
			else
				return maxC;
		}

		Vector3 RCmetresGrid;
		private float radius;
		private void calcDistToEdge(Base6Directions.Direction direction)
		{
			float coordinate = RCmetresGrid.Dot(Base6Directions.GetVector(direction));
			float limit = getLimit(direction);

			float newRadius = limit - coordinate;
			if (newRadius < 0)
				log("Error newRadius=" + newRadius + "(" + limit + " - " + coordinate + ") < 0", "calcDistToEdge("+direction+")", Logger.severity.ERROR);

			//log("distance to edge "+direction+" is "+newRadius);
			radius = Math.Max(radius, newRadius);
		}

		private static string getEntityName(IMyEntity entity)
		{
			string name = entity.DisplayName;
			if (name == null || name == "")
			{
				name = entity.Name;
				if (name == null || name == "")
				{
					name = entity.GetFriendlyName();
					if (name == null || name == "")
					{
						name = "unknown";
					}
				}
			}
			MyObjectBuilder_EntityBase builder = entity.GetObjectBuilder();
			if (builder != null)
				name += "." + builder.TypeId;
			else
				name += "." + entity.EntityId;
			return name;
		}

		private Logger myLogger = null;// = new Logger(myGrid.DisplayName, "Collision");
		private void log(string toLog, string method=null, Logger.severity level = Logger.severity.DEBUG)
		{
			if (myLogger == null)
				myLogger = new Logger(myGrid.DisplayName, "Collision");
			if (myLogger.canLog(level))
				myLogger.log(level, method, toLog);
		}

		private NavSettings CNS;
		private uint nextUpdate = 0;
		private CollisionAvoidance myCA;

		//private DateTime lastUpdate = DateTime.UtcNow;

		public collisionAvoidResult avoidCollisions(ref NavSettings CNS, int stopFromDestGrid, uint updateCount, byte tryCount = 10)
		{
			//log("entered avoidCollisions update: "+updateCount);
			if (updateCount < nextUpdate)
				return collisionAvoidResult.NO_OBSTRUCTION;
			//DateTime startOfMethod = DateTime.UtcNow;
			//log("between updates: " + (DateTime.UtcNow - lastUpdate));
			//lastUpdate = DateTime.UtcNow;
			if (myCA == null || nextUpdate != updateCount)
			{
				//log("update should be " + (lastUpdate + 1) + " is " + updateCount);
				this.CNS = CNS;
				myCA = new CollisionAvoidance(ref CNS, stopFromDestGrid, myRC, radius);
			}
			collisionAvoidResult result;
			if (!myCA.next(out result))
			{
				// will end up here after NO_COLLISION
				if (tryCount <= 0)
				{
					log("Error: too many tries", "avoidCollisions(CNS, "+stopFromDestGrid+", "+updateCount+", "+tryCount+")", Logger.severity.ERROR);
					nextUpdate = updateCount + 1;
					return collisionAvoidResult.NO_WAY_FORWARD;
				}
				myCA = null;
				return avoidCollisions(ref CNS, stopFromDestGrid, updateCount, (byte)(tryCount - 1));
			}
			if (result == collisionAvoidResult.NOT_FINISHED)
				nextUpdate = updateCount + 1;
			else
				nextUpdate = updateCount + 10;
			//log("time to avoidCollisions: " + (DateTime.UtcNow - startOfMethod).TotalMilliseconds+" spheres checked: "+spheresChecked);
			return result;
		}

		public enum collisionAvoidResult : byte { NO_OBSTRUCTION, OBSTRUCTION, ALTERNATE_PATH, NO_WAY_FORWARD, NOT_FINISHED }

		/// <summary>
		/// reset on collisionAvoidance.next(), so only applies to current CollisionAvoidance
		/// </summary>
		private static int spheresChecked = 0;
		private static int maxSpheres = 100;
		
		private class CollisionAvoidance
		{
			/// <summary>
			/// for straight path, muliply radius by
			/// </summary>
			private static float straightRadiusMulti = 2f;
			/// <summary>
			/// for straight path, increase radius by (after multi)
			/// </summary>
			private static float straightRadiusIncrease = 25;
			/// <summary>
			/// for alternate path, multiply radius by
			/// </summary>
			private static float alternateRadiusMulti = 4f; // fixed!!! :D
			/// <summary>
			/// for alternate path, increase radius by (after multi)
			/// </summary>
			private static float alternateRadiusIncrease = 50;
			/// <summary>
			/// for alternate path, how far to look ahead, in metres
			/// </summary>
			private static int alternateProjection = 1000;

			private float straightRadius;
			private float alternateRadius;

			int stopFromDestGrid;
			/// <summary>
			/// only use this to push new waypoint, use inital values otherwise
			/// </summary>
			private NavSettings CNS;
			private Vector3D wayDest;
			private Sandbox.ModAPI.IMyCubeGrid gridDestination;
			private Sandbox.ModAPI.IMyCubeBlock remoteControl;
			//private float radius;

			/// <summary>
			/// be sure to get a new one after a reset, CNS changes will not be respected
			/// </summary>
			/// <param name="stopFromDestGrid">how close to destination grid to stop, if destination is a grid</param>
			/// <returns></returns>
			public CollisionAvoidance(ref NavSettings CNS, int stopFromDestGrid, Sandbox.ModAPI.IMyCubeBlock remoteControl, float radius)
			{
				this.stopFromDestGrid = stopFromDestGrid;
				this.CNS = CNS;
				this.wayDest = (Vector3D)CNS.getWayDest();
				this.gridDestination = CNS.gridDestination;
				this.remoteControl = remoteControl;
				//this.radius = radius;

				straightRadius = radius * straightRadiusMulti + straightRadiusIncrease;
				alternateRadius = radius * alternateRadiusMulti + alternateRadiusIncrease;

				currentStage = stage.S0_start;
			}

			private enum stage : byte { S0_start, S1_straight, S2_setupAlter, S30_checkAlt0, S31_checkAlt1, S32_checkAlt2, S33_checkAlt3, S100_done }
			private stage currentStage;
			private bool setupAltRoute;
			private CanFlyTo currentCFT;
			private Vector3D collisionSphere;
			private Vector3D routeVector;
			private Vector3D[] altRoute;
			private int multiplier;
			private Vector3D waypoint;

			private void advanceStage()
			{
				if (currentStage == stage.S33_checkAlt3)
					currentStage = stage.S30_checkAlt0;
				else
					currentStage++;
			}

			public bool next(out collisionAvoidResult result)
			{
				if (currentStage == stage.S100_done)
				{
					result = collisionAvoidResult.NO_WAY_FORWARD;
					//log("cannot proceed, stage == done");
					return false;
				}
				spheresChecked = 0;
				//log("started next(result) stage: "+currentStage);

				if (currentStage == stage.S0_start)
				{
					//log("building new CanFlyTo("+wayDest+", "+gridDestination+", "+remoteControl+", "+radius+", "+stopFromDestGrid+")");
					currentCFT = new CanFlyTo(wayDest, gridDestination, remoteControl, straightRadius, stopFromDestGrid, 0);
					advanceStage();
				}

				if (currentStage == stage.S1_straight)
					if (currentCFT.next(out result))
					{
						switch (result)
						{
							case collisionAvoidResult.OBSTRUCTION:
								// find new path
								collisionSphere = currentCFT.relevantSphere.Center;
								advanceStage();
								break;
							case collisionAvoidResult.NOT_FINISHED:
								return true;
							//case collisionAvoidResult.AT_DEST_GRID:
							case collisionAvoidResult.NO_OBSTRUCTION:
								currentStage = stage.S100_done;
								return true;
							default:
								log("Error: unsuitable case from canFlyTo.next(): " + result, "next(result)", Logger.severity.ERROR);
								result = collisionAvoidResult.NO_WAY_FORWARD;
								return false;
						}
					}
					else
					{
						log("Error at Collision.Avoidance.next()." + currentStage + ": CanFlyTo.next() is invalid", "next(result)", Logger.severity.ERROR);
						currentStage = stage.S100_done;
						return false;
					}

				//log("searching for alternate route, spheres so far: "+spheresChecked);

				if (currentStage == stage.S2_setupAlter)
				{
					routeVector = wayDest - remoteControl.GetPosition();
					altRoute = new Vector3D[4];
					altRoute[0] = Vector3D.CalculatePerpendicularVector(routeVector);
					altRoute[1] = routeVector.Cross(altRoute[0]);
					altRoute[2] = Vector3D.Negate(altRoute[0]);
					altRoute[3] = Vector3D.Negate(altRoute[1]);
					setupAltRoute = true;
					multiplier = 10;
					advanceStage();
				}

				while (multiplier < 2000)
				{
					if (setupAltRoute)
					{
						//log("setupAtRoute: "+currentStage+", spheres so far: "+spheresChecked);
						Vector3D direction;
						switch (currentStage)
						{
							case stage.S30_checkAlt0:
								direction = altRoute[0];
								break;
							case stage.S31_checkAlt1:
								direction = altRoute[1];
								break;
							case stage.S32_checkAlt2:
								direction = altRoute[2];
								break;
							case stage.S33_checkAlt3:
								direction = altRoute[3];
								break;
							default:
								direction = new Vector3D();
								break;
						}

						waypoint = collisionSphere + multiplier * Vector3D.Normalize(direction);
						currentCFT = new CanFlyTo(waypoint, gridDestination, remoteControl, alternateRadius, stopFromDestGrid, alternateProjection);
						setupAltRoute = false;
					}

					if (!currentCFT.next(out result))
					{
						log("Error at next()." + currentStage + ": CanFlyTo.next() is invalid", "next(result)", Logger.severity.ERROR);
						currentStage = stage.S100_done;
						return false;
					}

					//log("checking result from canFlyTo: "+result);
					switch (result)
					{
						case collisionAvoidResult.OBSTRUCTION:
							if (currentStage == stage.S33_checkAlt3)
								multiplier *= 2;
							setupAltRoute = true;
							//string toLog = "at obstruction, stage "+currentStage;
							advanceStage();
							//log(toLog + " => " + currentStage);
							break;
						case collisionAvoidResult.NOT_FINISHED:
							//log("not finished stage: " + currentStage + ", spheres: " + spheresChecked);
							return true;
						case collisionAvoidResult.NO_OBSTRUCTION:
							if (CNS.addWaypoint(waypoint))
							{
								log("added new waypoint " + waypoint);
								result = collisionAvoidResult.ALTERNATE_PATH;
								currentStage = stage.S100_done;
								return true;
							}
							else
								goto case collisionAvoidResult.OBSTRUCTION;
						default:
							log("Error: unsuitable case from canFlyTo.next(): " + result, "next(result)", Logger.severity.ERROR);
							result = collisionAvoidResult.NO_WAY_FORWARD;
							return false;
						//case collisionAvoidResult.AT_DEST_GRID:
							//currentStage = stage.S100_done;
							//return true;
					}
				}

				//log("Warning: no way forward");// + ", checked " + spheresChecked + " spheres");
				result = collisionAvoidResult.NO_WAY_FORWARD;
				return true;
			}

			private Logger myLogger = null;// = new Logger(myGrid.DisplayName, "Collision");
			private void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
			{
				if (myLogger == null)
					myLogger = new Logger(remoteControl.CubeGrid.DisplayName, "CollisionAvoidance");
				if (myLogger.canLog(level))
					myLogger.log(level, method, toLog);
			}
		}

		private class CanFlyTo
		{
			/// <summary>
			/// only set when collisionAvoidResult == OBSTRUCTION
			/// </summary>
			public BoundingSphereD relevantSphere { get; private set; }

			private Spheres collisionSpheres;
			private Vector3D destination;
			private Sandbox.ModAPI.IMyCubeGrid gridDest;
			private Sandbox.ModAPI.IMyCubeBlock remoteControl;
			int stopFromDestGrid;
			private bool isValid = true;

			public CanFlyTo(Vector3D destination, Sandbox.ModAPI.IMyCubeGrid gridDest, Sandbox.ModAPI.IMyCubeBlock remoteControl, float radius, int stopFromDestination, int projection)
			{
				this.remoteControl = remoteControl;
				this.stopFromDestGrid = stopFromDestination;
				this.destination = destination;
				this.gridDest = gridDest;
				//log("CanFlyTo("+destination+", "+gridDest+", "+remoteControl+", "+radius+", "+stopFromDestGrid+")");
				//log("building Spheres("+radius+")");
				collisionSpheres = new Spheres(destination, remoteControl, radius, projection);
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="result"></param>
			/// <returns>false iff could not get a result</returns>
			public bool next(out collisionAvoidResult result)
			{
				if (!isValid)
				{
					result = collisionAvoidResult.NO_WAY_FORWARD;
					log("cannot proceed, not valid", "next()", Logger.severity.ERROR);
					return false;
				}
				isValid = false;

				BoundingSphereD currentSphere;
				while (collisionSpheres.next(out currentSphere))
				{
					//log("got sphere: "+currentSphere);
					// if count > maxSpheres, pause
					if (spheresChecked >= maxSpheres)
					{
						isValid = true;
						result = collisionAvoidResult.NOT_FINISHED;
						return true;
					}
					spheresChecked++;
					relevantSphere = currentSphere;

					List<IMyEntity> entitiesInSphere = MyAPIGateway.Entities.GetEntitiesInSphere(ref currentSphere);
					// trying new method
					//List<IMyEntity> entitiesInSphere = MyAPIGateway.Entities.GetIntersectionWithSphere(ref currentSphere, null, null, false, false);
					if (entitiesInSphere.Count > 0)
						//List<IMyEntity> newEntities = new List<IMyEntity>(entitiesInSphere);
						//foreach (IMyEntity entity in entitiesInSphere)
						//if (ignoreCollision(entity, currentSphere))
						//newEntities.Remove(entity);
						//entitiesInSphere = newEntities;
						//if (entitiesInSphere.Count > 0) // encountered a non-ignorable entity
						if (gridDest != null && entitiesInSphere.Contains(gridDest as IMyEntity))
						{
							//if ((destination - remoteControl.GetPosition()).Length() < stopFromDestGrid)
							//result = collisionAvoidResult.AT_DEST_GRID;
							//else
							result = collisionAvoidResult.NO_OBSTRUCTION;
							return true;
						}
						else // does not contain gridDest
							foreach (IMyEntity entity in entitiesInSphere)
								if (!ignoreCollision(entity, currentSphere))
								{
									log("obstruction: " + getEntityName(entity));
									result = collisionAvoidResult.OBSTRUCTION;
									return true;
								}
								else if (intersectionTest)
								{ // intersection test is expensive, delay
									log("performed intersection test, delaying next sphere");
									isValid = true;
									result = collisionAvoidResult.NOT_FINISHED;
									return true;
								}
				}
				// completed successfully with no obstacles
				result = collisionAvoidResult.NO_OBSTRUCTION;
				return true;
			}

			private bool intersectionTest;

			private bool ignoreCollision(IMyEntity entity, BoundingSphereD collision)
			{
				intersectionTest = false;
				MyObjectBuilder_EntityBase builder = entity.GetObjectBuilder();
				if (builder == null)
				{
					log("ignoring object: invisible: "+getEntityName(entity));
					return true; // do not know what this is but it is not stopping me
				}
				if (builder is MyObjectBuilder_Character)
				{
					log("ignoring object: squish the little shits: " + getEntityName(entity));
					return true; // squish the little shits
				}
				if (entity == remoteControl.CubeGrid as IMyEntity)
				{
					log("ignoring object: that's me: " + getEntityName(entity));
					return true; // cannot run self over
				}
				//if (!entity.GetIntersectionWithSphere(ref collision))
				if (!entityIntersectsWithSphere(entity, collision))
				{
					log("ignoring object: no intersection " + getEntityName( entity) + " " + collision);
					return true;
				}
				return false;
			}

			private bool entityIntersectsWithSphere(IMyEntity entity, BoundingSphereD sphere)
			{
				List<IMySlimBlock> blocksInGrid = new List<IMySlimBlock>();
				IMyCubeGrid grid = entity as IMyCubeGrid;
				if (grid == null)
				{
					log("not a grid using old test: "+getEntityName(entity), "entityIntersectsWithSphere()", Logger.severity.DEBUG);
					return entity.GetIntersectionWithSphere(ref sphere); // too expensive for CubeGrid, fine for VoxelMap
				}
				intersectionTest = true;
				log("using grid test", "entityIntersectsWithSphere()", Logger.severity.DEBUG);
				BoundingSphere sphereF = sphere;
				grid.GetBlocks(blocksInGrid);
				foreach (IMySlimBlock block in blocksInGrid)
				{
					Vector3 worldPos = grid.GridIntegerToWorld(block.Position);
					float distanceSq = (sphereF.Center - worldPos).LengthSquared();
					if (distanceSq < Math.Pow(sphereF.Radius, 2f))
						return true;
				}
				return false;
			}

			private Logger myLogger = null;// = new Logger(myGrid.DisplayName, "Collision");
			private void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
			{
				if (myLogger == null)
					myLogger = new Logger(remoteControl.CubeGrid.DisplayName, "CanFlyTo");
				if (myLogger.canLog(level))
					myLogger.log(level, method, toLog);
			}
		}

		/// <summary>
		/// iterates over a series of BoundingSphereD between two points
		/// </summary>
		private class Spheres
		{
			private Vector3D start;
			private Vector3D end;
			/// <summary>
			/// vector in the direction start to end, with magnitude of diameter
			/// </summary>
			private Vector3D startToEnd;
			private float radius;

			private int maxSphereNum;
			private int sphereNum;

			private string myGridName;

			/// <summary>
			/// 
			/// </summary>
			/// <param name="end">where spheres stop if projection == 0</param>
			/// <param name="remoteControl">position to start from</param>
			/// <param name="radius">radius of spheres</param>
			/// <param name="projection">how far to go past destination</param>
			public Spheres(Vector3D end, Sandbox.ModAPI.IMyCubeBlock remoteControl, float radius, int projection)
			{
				this.end = end;
				this.start = GridWorld.RCtoWorld(remoteControl, new Vector3(0, 0, 0));
				this.radius = radius;
				myGridName = remoteControl.CubeGrid.DisplayName;
				sphereNum = 2; // lets try skipping first couple and see how it goes

				// spheres need to overlap, obstructions can fit between spheres
				startToEnd = end - start; // set direction to start -> end
				maxSphereNum = (int)Math.Floor((startToEnd.Length() + projection) / (radius));
				startToEnd.Normalize();
				startToEnd *= radius;

				log("maxSphereNum: " + maxSphereNum, "constructor", Logger.severity.TRACE);
				//log("V3I " + new Vector3I(0, 0, -speed));
				//log("grid "+remoteControl.CubeGrid.GetPosition());
				//log("gw "+GridWorld.RCtoWorld(remoteControl, new Vector3(0,0,-speed)));
				//log("world " + remoteControl.CubeGrid.GridIntegerToWorld(new Vector3I(0, 0, -speed)));
				//log("end is " + end + ", speed is " + speed + ", dist from RC is " + (remoteControl.GetPosition() - end).Length());
			}

			/// <summary>
			/// get the next BoundingSphereD in the set
			/// </summary>
			/// <param name="result"></param>
			/// <returns></returns>
			public bool next(out BoundingSphereD result)
			{
				if (sphereNum > maxSphereNum)
				{
					result = new BoundingSphereD();
					return false;
				}
				Vector3D centre = start + startToEnd * sphereNum;
				sphereNum++;
				result = new BoundingSphereD(centre, radius);
				log("sereved sphere: "+result, "next(result)", Logger.severity.TRACE);
				return true;
			}

			private Logger myLogger = null;// = new Logger(myGrid.DisplayName, "Collision");
			private void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
			{
				if (myLogger == null)
					myLogger = new Logger(myGridName, "Spheres");
				if (myLogger.canLog(level))
					myLogger.log(level, method, toLog);
			}
		}
	}
}
