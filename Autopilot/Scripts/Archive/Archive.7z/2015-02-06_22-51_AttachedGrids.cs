﻿#define LOG_ENABLED // remove on build

using System;
using System.Collections.Generic;
//using System.Linq;
//using System.Text;

using Sandbox.Common.ObjectBuilders;
using Sandbox.ModAPI;
using ingame = Sandbox.ModAPI.Ingame;
using VRageMath;

namespace Rynchodon.Autopilot.Pathfinder
{
	public class AttachedGrids
	{
		public HashSet<IMyCubeGrid> attachedGrids = new HashSet<IMyCubeGrid>();

		private static Dictionary<IMyCubeGrid, AttachedGrids> registry = new Dictionary<IMyCubeGrid, AttachedGrids>();

		private HashSet<IMySlimBlock> allPistonBases = new HashSet<IMySlimBlock>(); // for objectbuilder.TopBlockId
		private HashSet<IMySlimBlock> allPistonTops = new HashSet<IMySlimBlock>(); // for objectbuilder.PistonBlockId (might be unnecissary)
		private HashSet<IMySlimBlock> allMotorBases = new HashSet<IMySlimBlock>(); // for objectbuilder.RotorEntityId (might be insufficient)
		private HashSet<IMySlimBlock> allConnectors = new HashSet<IMySlimBlock>(); // for objectbuilder.ConnectedEntityId
		//private HashSet<IMySlimBlock> allLandingGears = new HashSet<IMySlimBlock>(); // horribly complicated

		private IMyCubeGrid myGrid;

		private Logger myLogger;
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{ alwaysLog(toLog, method, level); }
		private void alwaysLog(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			if (myLogger == null) myLogger = new Logger(myGrid.DisplayName, "AttachedGrids");
			myLogger.log(level, method, toLog);
		}

		private AttachedGrids() { }

		public static AttachedGrids getFor(IMyCubeGrid myGrid)
		{
			AttachedGrids instance;
			if (registry.TryGetValue(myGrid, out instance))
				return instance;
			instance = new AttachedGrids();
			instance.myGrid = myGrid;

			List<IMySlimBlock> allBlocks = new List<IMySlimBlock>();
			myGrid.GetBlocks(allBlocks);
			foreach (IMySlimBlock block in allBlocks)
				instance.myGrid_OnBlockAdded(block);

			myGrid.OnBlockAdded += instance.myGrid_OnBlockAdded;
			myGrid.OnBlockRemoved += instance.myGrid_OnBlockRemoved;
			registry.Add(myGrid, instance);
			instance.log("created for: " + myGrid.DisplayName, "getFor()");
			return instance;
		}

		private void myGrid_OnBlockAdded(IMySlimBlock added)
		{ addRemove(added, true); }

		private void myGrid_OnBlockRemoved(IMySlimBlock removed)
		{ addRemove(removed, false); }

		private MyObjectBuilderType type_pistonTop = (new MyObjectBuilder_PistonTop()).TypeId;

		private void addRemove(IMySlimBlock block, bool add)
		{
			IMyCubeBlock fatblock = block.FatBlock;
			if (fatblock == null)
				return;

			if (fatblock is IMyPistonBase)
				addRemove(allPistonBases, block, add);
			else if (fatblock.BlockDefinition.TypeId == type_pistonTop)
				addRemove(allPistonTops, block, add);
			else if (fatblock is ingame.IMyMotorBase)
				addRemove(allMotorBases, block, add);
			else if (fatblock is ingame.IMyShipConnector)
				addRemove(allConnectors, block, add);
		}

		private void addRemove(HashSet<IMySlimBlock> blockSet, IMySlimBlock block, bool add)
		{
			if (add)
				blockSet.Add(block);
			else
				blockSet.Remove(block);
		}

		public void buildAttached()
		{ buildAttached(true); }

		private void buildAttached(bool first)
		{
			// get all the potentially attached grids
			BoundingBoxD searchBox = myGrid.WorldAABB.GetInflated(10);
			log("inflated " + myGrid.WorldAABB, "buildAttached()", Logger.severity.TRACE);
			log("to " + myGrid.WorldAABB, "buildAttached()", Logger.severity.TRACE);
			foreach (IMyEntity entity in MyAPIGateway.Entities.GetEntitiesInAABB(ref searchBox))
			{
				IMyCubeGrid grid = entity as IMyCubeGrid;
				if (grid == null)
					continue;
				AttachedGrids partner = getFor(grid);
				if (isAttached_piston(partner))
					continue;
			}

			if (!first)
				return;
		}

		private bool tryAddAttached(IMyCubeGrid toAttach)
		{
			if (attachedGrids.Contains(toAttach))
				return false;
			attachedGrids.Add(toAttach);
			// register for something to know when unattached
			return true;
		}

		private bool isAttached_piston(AttachedGrids partner)
		{
			foreach (IMySlimBlock pistonBase in allPistonBases)
			{
				log("checking " + pistonBase.FatBlock.DefinitionDisplayNameText, "isAttached_piston()", Logger.severity.TRACE);
				MyObjectBuilder_PistonBase builder_base = pistonBase.GetObjectBuilder() as MyObjectBuilder_PistonBase;
				long topBlockId = builder_base.TopBlockId;
				//if (topBlockId == partner.myGrid.EntityId) // try match to grid
				//{
				//	log("matched " + pistonBase.FatBlock.DefinitionDisplayNameText + " to grid " + partner.myGrid.DisplayName, "isAttached_piston()");
				//	success = true;
				//}
				foreach (IMySlimBlock pistonTop in partner.allPistonTops)
				{
					if (topBlockId == pistonTop.FatBlock.EntityId)
					{
						log("matched " + pistonBase.FatBlock.DefinitionDisplayNameText + " to block " + pistonTop.FatBlock.DefinitionDisplayNameText, "isAttached_piston()", Logger.severity.TRACE);
						tryAddAttached(partner.myGrid);
						return true;
					}
					//MyObjectBuilder_PistonTop builder_top = pistonTop.GetObjectBuilder() as MyObjectBuilder_PistonTop;
					//if (topBlockId == builder_top.PistonBlockId)
					//{
					//	log("matched " + pistonBase.FatBlock.DefinitionDisplayNameText + " to block builder " + pistonTop.FatBlock.DefinitionDisplayNameText, "isAttached_piston()");
					//	success = true;
					//}
				}
			}
			return false;
		}
	}
}
