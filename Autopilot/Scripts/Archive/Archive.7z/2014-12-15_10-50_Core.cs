﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Sandbox.Common;
using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.Definitions;
using Sandbox.Engine;
using Sandbox.Game;
using Sandbox.ModAPI;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using AutoPilot;
using System.Diagnostics;

namespace Autopilot
{
	[Sandbox.Common.MySessionComponentDescriptor(Sandbox.Common.MyUpdateOrder.BeforeSimulation)]
	public class Core : Sandbox.Common.MySessionComponentBase
	{
		private static MyLogger Logger;
		bool initialized;

		private int count;

		private Dictionary<Sandbox.ModAPI.IMyCubeGrid, GridHandler> allGridHandlers; // for tracking which grids already have handlers and for iterating through handlers

		public override void UpdateBeforeSimulation()
		{
			if (!initialized)
			{
				init();
				return;
			}
			if (count % 10 == 0)
			{
				foreach (KeyValuePair<Sandbox.ModAPI.IMyCubeGrid, GridHandler> entry in allGridHandlers)
				{
					try
					{
						entry.Value.update();
					}
					catch (Exception e)
					{
						Logger.WriteLine("Exception caught. "+e);
					}
				}
			}

			count++;
		}

		private void init()
		{
			if (Logger == null)
			{
				Logger = new MyLogger("Autopilot.log");
			}
			Logger.WriteLine("Initialized");

			allGridHandlers = new Dictionary<Sandbox.ModAPI.IMyCubeGrid, GridHandler>();
			build();
			initialized = true;

			// Display the timer frequency and resolution. 
			if (Stopwatch.IsHighResolution)
			{
				Logger.WriteLine("Operations timed using the system's high-resolution performance counter.");
			}
			else
			{
				Logger.WriteLine("Operations timed using the DateTime class.");
			}

			long frequency = Stopwatch.Frequency;
			Logger.WriteLine("  Timer frequency in ticks per second = "+
					frequency);
			long nanosecPerTick = (1000L * 1000L * 1000L) / frequency;
			Logger.WriteLine("  Timer is accurate within "+nanosecPerTick+" nanoseconds"
					);
		}

		// TODO: call from time to time to find additional entities
		private void build()
		{
			HashSet<IMyEntity> entities = new HashSet<IMyEntity>();
			MyAPIGateway.Entities.GetEntities(entities, e => e is Sandbox.ModAPI.IMyCubeGrid);
			foreach (IMyEntity entity in entities)
			{
				Sandbox.ModAPI.IMyCubeGrid grid = entity as Sandbox.ModAPI.IMyCubeGrid;
				if (grid == null)
					continue;
				if (!allGridHandlers.ContainsKey(grid))
				{
					Logger.WriteLine("new grid added "+grid.DisplayName);
					GridHandler cGridHandler = new GridHandler(grid, Logger);
					allGridHandlers.Add(grid, cGridHandler);
				}
			}
		}

		protected override void UnloadData()
		{
			base.UnloadData();
			Logger.Close();
			Logger = null;
		}
	}
}
