﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Sandbox.Common;
using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.Definitions;
using Sandbox.Engine;
using Sandbox.Game;
using Sandbox.ModAPI;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using VRageMath;

namespace AutoPilot
{
	class GridHandler
	{
		private Scripts.KSWH.MyLogger Logger;
		private Sandbox.ModAPI.IMyCubeGrid myGrid;
		private bool needToUpdateRemoteControls;

		private List<Sandbox.ModAPI.IMySlimBlock> remoteControlBlocks;

		private navState myNavState;
		private enum navState
		{
			STOPPING,
			ROTATING,
			DEROTATE, // decelerate rotation
			MOVING,
			DESTINATION
		}

		public GridHandler(Scripts.KSWH.MyLogger logger, Sandbox.ModAPI.IMyCubeGrid grid)
		{
			Logger = logger;

			myGrid = grid;
//			needToUpdateRemoteControls = true;

			log("handler updating...");
			updateRemoteControls();

			myNavState = navState.STOPPING;

			// register for events
		}

		public void update()
		{
			if (needToUpdateRemoteControls)
				updateRemoteControls();
			else
				navigate();
		}

		private void updateRemoteControls()
		{
			needToUpdateRemoteControls = false;

//			if (!needToUpdate)
//				return;

			//	find remote control blocks
			remoteControlBlocks = new List<Sandbox.ModAPI.IMySlimBlock>();
			MyObjectBuilderType remoteControlType = (new MyObjectBuilder_RemoteControl() as MyObjectBuilder_Base).TypeId;
//			Logger.WriteLine("rCT is "+remoteControlType);
			myGrid.GetBlocks(remoteControlBlocks, block => block.FatBlock != null && block.FatBlock.BlockDefinition.TypeId == remoteControlType);
			log("# of RC blocks is " + remoteControlBlocks.Count);

//			if (remoteControlBlocks.Count > 0)
//				navigate();
		}

		private double needToRotateX;
		private double needToRotateY;
		private double previousX;
		private double previousY;

//		private static float speedAdjustment = 10f;
//		private static float speedThreshold = 0.2f; // if adjustment is smaller than this, do not apply speed
//		private float decelerateAtHighSpeed = 2f / 3f; // how much of rotation should be deceleration, at high speed
//		private float decelerateAtLowSpeed = 1f / 3f; // as above, for low speed
		private float decelerate = 1f / 2f; // how much of rotation should be deceleration
		private static float decelerateAdjustment = 0.9f; // adjust decelerate by this much when overshoot/undershoot, must be > 0 and < 1

		//	modified from EnemyShip.Update(int count) in Mission 01 by KSWH, id=315628704 on steam
		private void navigate()
		{
			Vector3D origin = Vector3D.Zero; //new Vector3D(0,0,0);
			IMyControllableEntity rcBlock = remoteControlBlocks[0].FatBlock as IMyControllableEntity;

			var dir = origin - myGrid.GetPosition();
//			if (dir.Length() < 10) // very close to destination
//				return;

			var dirNorm = Vector3D.Normalize(dir); // unit vector
			var x = -(rcBlock as IMyEntity).WorldMatrix.Up.Dot(dirNorm); // dot product to get x
			var y = -(rcBlock as IMyEntity).WorldMatrix.Left.Dot(dirNorm); // dot product to get y
//			var forw = (rcBlock as IMyEntity).WorldMatrix.Forward.Dot(dirNorm); // dot product to get z

//			log("rot vector: "+x+", "+y);

//			if (forw < 0)
//				y = 0.2f;

			if (Math.Abs(x) < 0.01f)
				x = 0;
			if (Math.Abs(y) < 0.01f)
				y = 0;
//			else

/*			bool atLowSpeed = false;

			if (Math.Abs(x) > speedThreshold)
			{
				x *= speedAdjustment;
				atLowSpeed = true;
			}
			if (Math.Abs(y) > speedThreshold)
			{
				y *= speedAdjustment;
				atLowSpeed = true;
			}

			float decelerate;
			if (atLowSpeed)
				decelerate = decelerateAtLowSpeed;
			else
				decelerate = decelerateAtHighSpeed;*/

			var rot = new Vector2((float)x, (float)y);

			if (rot.LengthSquared() > 0) // need to rotate
			{
				switch (myNavState)
				{
					case navState.MOVING:
						//	TODO: make minor ajustments in-flight
						if (rot.LengthSquared() > 0.1)
						{
							log("stopping to rotate");
							rcBlock.MoveAndRotateStopped();
							myNavState = navState.STOPPING;
						}
						break;
					case navState.DEROTATE:
					case navState.STOPPING:
						if (Math.Abs(previousX - x) < 0.01f && Math.Abs(previousY - y) < 0.01f) // actually stopped
						{
							if (myNavState == navState.DEROTATE)
							{
								int overUnder = 0;
								//	check for overshoot/undershoot
								if (x!= 0)
									// assume (needToRotateX != 0)
									if ( (x > 0 && needToRotateX > 0) || (x < 0 && needToRotateX < 0) )
									{
										log("x undershot");
										overUnder--;
									}
									else
									{
										log("x overshot");
										overUnder++;
									}

								if (y!= 0)
									// assume (needToRotateY != 0)
									if ( (y > 0 && needToRotateY > 0) || (y < 0 && needToRotateY < 0) )
									{
										log("y undershot");
										overUnder--;
									}
									else
									{
										log("y overshot");
										overUnder++;
									}

								if (overUnder != 0)
								{
									if (overUnder > 0)
										decelerate /= decelerateAdjustment;
									else
										decelerate *= decelerateAdjustment;
/*									if (atLowSpeed)
									{
										decelerateAtLowSpeed = decelerate;
										log("adjusted decelerate(low), new value is " + decelerate);
									}
									else
									{
										decelerateAtHighSpeed = decelerate;
										log("adjusted decelerate(high), new value is " + decelerate);
									}*/
									log("adjusted decelerate, new value is " + decelerate);
								}
							}
							log("starting rotation: " + x + ", " + y);
							needToRotateX = x;
							needToRotateY = y;
							rcBlock.MoveAndRotate(Vector3D.Zero, rot, 0); // rotate towards target
							myNavState = navState.ROTATING;
						}
						break;
					case navState.ROTATING:
						// check for need to decelerate
						if  ((needToRotateX > 0 && x < needToRotateX * decelerate)
							|| (needToRotateX < 0 && x > needToRotateX * decelerate) 
							|| (needToRotateY > 0 && y < needToRotateY * decelerate) 
							|| (needToRotateY < 0 && y > needToRotateY * decelerate))
						{
							log("decelerate rotation ("+x+", "+y+", "+needToRotateX+", "+needToRotateY+")");
							rcBlock.MoveAndRotateStopped();
//							var revRot = new Vector2((float)-needToRotateX, (float)-needToRotateY);
//							rcBlock.MoveAndRotate(Vector3D.Zero, revRot, 0); // stop rotating
							myNavState = navState.DEROTATE;
						}
						break;
					default:
//						log("ERROR: invalid state " + myNavState);
						break;
				}
			}
			else // no need to rotate
			{
				if (myNavState == navState.DEROTATE || myNavState == navState.ROTATING)
				{
					log("stopping rotation");
					rcBlock.MoveAndRotateStopped(); // stop rotating
					myNavState = navState.STOPPING;
				}
				if (dir.Length() < 10) // at destination
				{
					switch (myNavState)
					{
						case navState.MOVING:
							log("stopping at destination");
							rcBlock.MoveAndRotateStopped();
							myNavState = navState.STOPPING;
							break;
						case navState.STOPPING:
							log("reached destination");
							myNavState = navState.DESTINATION;
							break;
						default:
							break;
					}
				}
				else // not at destination
				{
					if (myNavState == navState.STOPPING)
					{
//						dir = Vector3D.TransformNormal(dir, (rcBlock as IMyEntity).WorldMatrixNormalizedInv);
						rcBlock.MoveAndRotate(dir, Vector2.Zero, 0); // move
						log("moving "+dir);
						myNavState = navState.MOVING;
					}

					//					dir = Vector3D.Zero;
					//				else
					//					dir = Vector3D.TransformNormal(dir, (rcBlock as IMyEntity).WorldMatrixNormalizedInv);
				}
			}

			previousX = x;
			previousY = y;

/*			if (dir.LengthSquared() > 0 || rot.LengthSquared() > 0)
			{
//				rcBlock.MoveAndRotateStopped();
				rcBlock.MoveAndRotate(dir, rot, 0); // rotate towards target
			}
			else
				rcBlock.MoveAndRotateStopped();

//			Logger.WriteLine("success!, I hope...");*/
		}

		private void OnBlockOwnershipChanged(Sandbox.ModAPI.IMyCubeGrid changedBlock)
		{
			needToUpdateRemoteControls = true;
		}

		private void OnBlockAdded(Sandbox.ModAPI.IMySlimBlock addedBlock)
		{
			needToUpdateRemoteControls = true;
		}

		private void OnBlockRemoved(Sandbox.ModAPI.IMySlimBlock removedBlock)
		{
			needToUpdateRemoteControls = true;
		}

		private void log(string toLog)
		{
			Logger.WriteLine("GH: "+toLog);
		}
	}
}
