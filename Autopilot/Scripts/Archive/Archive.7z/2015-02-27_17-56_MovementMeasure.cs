﻿#define LOG_ENABLED //remove on build

using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

using VRageMath;

namespace Rynchodon.Autopilot
{
	/// <summary>
	/// caches and lazy initializes
	/// </summary>
	internal class MovementMeasure
	{
		private Navigator owner;
		private Vector3D? targetDirection;
		public MovementMeasure(Navigator owner, Vector3D? targetDirection = null)
		{
			this.owner = owner;
			this.targetDirection = targetDirection;

			lazy_rotationLengthSquared = new Lazy<double>(() => { return pitch * pitch + yaw * yaw; });
			lazy_currentWaypoint = new Lazy<Vector3D>(() => { return (Vector3D)owner.CNS.getWayDest(); });
			lazy_movementSpeed = new Lazy<float>(() => { return owner.myGrid.Physics.LinearVelocity.Length(); });

			lazy_navBlockPosition = new Lazy<Vector3D>(() => { return owner.getNavigationBlock().GetPosition(); });
			lazy_displacementToPoint = new Lazy<RelativeVector3F>(() => { return RelativeVector3F.createFromWorld(navBlockPos - currentWaypoint, owner.myGrid); });
			//lazy_gridDistToWayDest = new Lazy<double>(() => { return owner.myGrid.WorldAABB.Distance(currentWaypoint); }); // test each corner of either grid with Distance
			lazy_distToWayDest = new Lazy<double>(() =>
			{
				switch (owner.CNS.getTypeOfWayDest())
				{
					case NavSettings.TypeOfWayDest.BLOCK:
					case NavSettings.TypeOfWayDest.GRID:
						return distToDestGrid;
					default:
						return displacement.getWorld().Length();
				}
			});

			lazy_distToDestGrid = new Lazy<double>(shortestDistanceToDestGrid);
			lazy_interceptionPoint = new Lazy<Vector3D>(calculateInterceptionPoint);
		}

		// these are all built together so we will not be using lazy
		private double value__pitch, value__yaw, value__pitchPower, value__yawPower;
		private bool isValid__pitchYaw = false;

		/// <summary>
		/// radians to pitch to reach target
		/// </summary>
		public double pitch
		{
			get
			{
				if (!isValid__pitchYaw)
					buildPitchYaw();
				return value__pitch;
			}
		}
		/// <summary>
		/// radians to yaw to reach target
		/// </summary>
		public double yaw
		{
			get
			{
				if (!isValid__pitchYaw)
					buildPitchYaw();
				return value__yaw;
			}
		}
		/// <summary>
		/// power to apply in pitch
		/// </summary>
		public double pitchPower
		{
			get
			{
				if (!isValid__pitchYaw)
					buildPitchYaw();
				return value__pitchPower;
			}
		}
		/// <summary>
		/// power to apply in yaw
		/// </summary>
		public double yawPower
		{
			get
			{
				if (!isValid__pitchYaw)
					buildPitchYaw();
				return value__yawPower;
			}
		}

		// might want a lookup table
		private void buildPitchYaw()
		{
			//if (owner.getNavigationBlock() != owner.currentRCblock)
			isValid__pitchYaw = true;

			//value__pitch = 0;
			//value__yaw = 0;
			//value__pitchPower = 0;
			//value__yawPower = 0;

			//if (owner.CNS.moveState == NavSettings.Moving.SIDELING)
			//	return;

			//switch (owner.CNS.landingState)
			//{
			//	case NavSettings.LANDING.OFF:
			//	case NavSettings.LANDING.ORIENT:
			//		break;
			//	default:
			//		return;
			//}

			Vector3D dirNorm;
			if (targetDirection == null)
			{
				Vector3D displacement = currentWaypoint - owner.myGridDim.getRCworld();
				dirNorm = Vector3D.Normalize(displacement);
			}
			else
				dirNorm = (Vector3D)targetDirection;
			//log("facing = " + owner.currentRCblock.WorldMatrix.Forward, "buildPitchYaw()", Logger.severity.TRACE);
			//log("dirNorm = " + dirNorm, "buildPitchYaw()", Logger.severity.TRACE);
			double right = owner.currentRCblock.WorldMatrix.Right.Dot(dirNorm);
			double down = owner.currentRCblock.WorldMatrix.Down.Dot(dirNorm);
			double forward = owner.currentRCblock.WorldMatrix.Forward.Dot(dirNorm);
			//log("dir vects = " + right + ", " + down + ", " + forward, "buildPitchYaw()", Logger.severity.TRACE);
			value__pitch = Math.Atan2(down, forward);
			value__yaw = Math.Atan2(right, forward);
			//if (forward < 0)
			//{
			//	double new_yaw;
			//	if (value__yaw < 0)
			//		new_yaw = -2 * Math.PI - value__yaw;
			//	else // value_yaw > 0
			//		new_yaw = 2 * Math.PI - value__yaw;
			//	log("yaw adjusted from " + value__yaw + " to " + new_yaw, "buildPitchYaw()", Logger.severity.DEBUG);
			//}
			//log("pitch = " + value__pitch + ", yaw = " + value__yaw, "buildPitchYaw()", Logger.severity.TRACE);
			switch (owner.CNS.moveState)
			{
				case NavSettings.Moving.MOVING:
				case NavSettings.Moving.HYBRID:
					value__pitchPower = value__pitch * owner.inflightRotatingPower;
					value__yawPower = value__yaw * owner.inflightRotatingPower;
					//log("power multiplier = " + owner.inflightRotatingPower, "buildPitchYaw()", Logger.severity.TRACE);
					break;
				default:
					value__pitchPower = value__pitch * owner.rotationPower;
					value__yawPower = value__yaw * owner.rotationPower;
					//log("power multiplier = " + owner.rotationPower, "buildPitchYaw()", Logger.severity.TRACE);
					break;
			}
			//log("pitch power = " + value__pitchPower + ", yaw power = " + value__yawPower, "buildPitchYaw()", Logger.severity.TRACE);
		}

		private Lazy<double> lazy_rotationLengthSquared;
		/// <summary>
		/// rotation length squared
		/// </summary>
		public double rotLenSq { get { return lazy_rotationLengthSquared.Value; } }

		private Lazy<Vector3D> lazy_currentWaypoint;
		public Vector3D currentWaypoint { get { return lazy_currentWaypoint.Value; } }

		private Lazy<float> lazy_movementSpeed;
		public float movementSpeed { get { return lazy_movementSpeed.Value; } }


		private Lazy<Vector3D> lazy_navBlockPosition;
		public Vector3D navBlockPos { get { return lazy_navBlockPosition.Value; } }

		private Lazy<RelativeVector3F> lazy_displacementToPoint;
		/// <summary>
		/// from nav block to way/dest point
		/// </summary>
		public RelativeVector3F displacement { get { return lazy_displacementToPoint.Value; } }

		private Lazy<double> lazy_distToWayDest;
		/// <summary>
		/// from nav block to way/dest or, if destination is a block or a grid, distToDestGrid
		/// </summary>
		public double distToWayDest { get { return lazy_distToWayDest.Value; } }

		//private Lazy<double> lazy_gridDistToWayDest;
		///// <summary>
		///// from myGrid.WorldAABB to way/dest
		///// </summary>
		//public double gridDistToWayDest { get { return lazy_gridDistToWayDest.Value; } }

		private Lazy<double> lazy_distToDestGrid;
		/// <summary>
		/// shortest distance between any corner and opposite BoundingBoxD
		/// </summary>
		private double distToDestGrid { get { return lazy_distToDestGrid.Value; } }

		private double shortestDistanceToDestGrid()
		{
			BoundingBoxD grid1 = owner.myGrid.WorldAABB, grid2 = owner.CNS.CurrentGridDest.Grid.WorldAABB;
			double shortestDistance = double.MaxValue;
			foreach (Vector3D corner in grid1.GetCorners())
				shortestDistance = Math.Min(shortestDistance, grid2.Distance(corner));
			foreach (Vector3D corner in grid2.GetCorners())
				shortestDistance = Math.Min(shortestDistance, grid1.Distance(corner));
			return shortestDistance;
		}

		private Lazy<Vector3D> lazy_interceptionPoint;
		public Vector3D interceptionPoint { get { return lazy_interceptionPoint.Value; } }

		private Vector3D calculateInterceptionPoint()
		{
			Vector3D targetPosition, targetVelocity, targetAcceleration;
			if (owner.CNS.CurrentGridDest.seenRecently())
			{
				targetPosition = owner.CNS.CurrentGridDest.Grid.WorldAABB.Center; // Centre of grid, TODO: block
				targetVelocity = owner.CNS.CurrentGridDest.Grid.Physics.LinearVelocity;
				//targetAcceleration = owner.CNS.CurrentGridDest.Grid.Physics.GetLinearAcceleration();
			}
			else
			{
				targetPosition = owner.CNS.CurrentGridDest.gridLastSeen.predictPosition();
				targetVelocity = owner.CNS.CurrentGridDest.gridLastSeen.LastKnownVelocity;
				//targetAcceleration = Vector3.Zero;
			}
			if (targetVelocity == Vector3D.Zero)
			{
				log("shorting: target velocity is zero", "calculateInterceptionPoint()", Logger.severity.TRACE);
				return targetPosition;
			}

			//var myPhysics = owner.myGrid.Physics;
			//if (myPhysics.CanUpdateAccelerations && myPhysics.LinearAcceleration == Vector3.Zero)
			//{
			//	myPhysics.UpdateAccelerations();
			//	log("updating my acceleration", "calculateInterceptionPoint()", Logger.severity.TRACE);
			//}
			//Vector3D myVelocity = myPhysics.LinearVelocity + myPhysics.LinearAcceleration;

			Vector3D relativePosition = targetPosition - owner.getNavigationBlock().GetPosition();
			//double acceleration = owner.myGrid.Physics.GetLinearAcceleration().Length();
			//double mySpeed = owner.myGrid.Physics.LinearVelocity.Length();
			//double speedRatio = owner.myGrid.Physics.LinearVelocity.Length() / targetVelocity.Length();
			double relativeSpeed = (owner.myGrid.Physics.LinearVelocity - targetVelocity).Length();
			if (relativeSpeed < 1)
			{
				log("setting relative speed to 1, was " + relativeSpeed, "calculateInterceptionPoint()", Logger.severity.TRACE);
				relativeSpeed = 1;
			}
			//double secondsToTarget = distToDestGrid / relativeSpeed;
			//relativeSpeed += acceleration;
			//double relativeAcceleration = (owner.myGrid.Physics.GetLinearAcceleration() - targetAcceleration).Length();
			//if (relativeAcceleration < 1)
			//{
			//	log("setting relative acceleration to 1, was " + relativeAcceleration, "calculateInterceptionPoint()", Logger.severity.TRACE);
			//	relativeAcceleration = 1;
			//}
			//double secondsToTarget = (relativeSpeed + Math.Pow(-2 * relativeAcceleration * relativePosition + relativeSpeed * relativeSpeed, 1/2)) / relativeAcceleration;

			//log("secondsToTarget = " + secondsToTarget + ", relativePosition = " + relativePosition + ", relativeSpeed = " + relativeSpeed + ", relativeAcceleration = " + relativeAcceleration, "calculateInterceptionPoint()", Logger.severity.DEBUG);
			double secondsToTarget = relativePosition.Length() / relativeSpeed * 10;
			//double secondsToTarget = relativePosition.Length() / relativeSpeed;
			Vector3D result = targetPosition + targetVelocity * secondsToTarget;
			//log("result = " + result + ", targetPosition = " + targetPosition + ", targetVelocity = " + targetVelocity, "calculateInterceptionPoint()", Logger.severity.DEBUG);
			return result;
		}


		private Logger myLogger;
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{ alwaysLog(toLog, method, level); }
		private void alwaysLog(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			if (myLogger == null) myLogger = new Logger(owner.myGrid.DisplayName, "MovementMeasure");
			myLogger.log(level, method, toLog);
		}
	}
}
