﻿#define LOG_ENABLED //remove on build

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//using Sandbox.Common;
//using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.Common.ObjectBuilders.Definitions;
//using Sandbox.Definitions;
//using Sandbox.Engine;
//using Sandbox.Game;
using Sandbox.ModAPI;
//using Ingame = Sandbox.ModAPI.Ingame;
//using Sandbox.ModAPI.Interfaces;
using VRageMath;

namespace Rynchodon.Autopilot
{
	class ThrustProfiler
	{
		private Logger myLogger = null;
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			myLogger.log(level, method, toLog);
		}

		private IMyCubeGrid myGrid;
		/// <summary>
		/// direction shall be direction of force on ship (opposite of thruster direction)
		/// </summary>
		private Dictionary<Base6Directions.Direction, float> thrustProfile;

		private static MyObjectBuilderType thrusterID = (new MyObjectBuilder_Thrust()).TypeId;

		public ThrustProfiler(IMyCubeGrid grid)
		{
			if (grid == null)
			{ (new Logger("", "ThrustProfiler")).log(Logger.severity.FATAL, "..ctor", "null parameter"); }
			myLogger = new Logger(grid.DisplayName, "ThrustProfile");
			myGrid = grid;

			thrustProfile = new Dictionary<Base6Directions.Direction, float>();
			foreach (Base6Directions.Direction direction in Enum.GetValues(typeof(Base6Directions.Direction)))
				thrustProfile.Add(direction, small_small);

			List<IMySlimBlock> thrusters = new List<IMySlimBlock>();
			grid.GetBlocks(thrusters, block => block.FatBlock != null && block.FatBlock.BlockDefinition.TypeId == thrusterID);
			foreach (IMySlimBlock thrust in thrusters)
				addRemoveThruster(thrust.FatBlock, true);

			grid.OnBlockAdded += grid_OnBlockAdded;
			grid.OnBlockRemoved += grid_OnBlockRemoved;
		}

		/// <summary>
		/// force value of dampeners
		/// </summary>
		private static float small_small = 120000, small_large = 1440000, large_small = 1000000, large_large = 12000000;

		private void addRemoveThruster(IMyCubeBlock thruster, bool add)
		{
			if (thruster == null)
			{
				log("null parameter", "addRemoveThruster()", Logger.severity.TRACE);
				return;
			}

			if (thruster.BlockDefinition.TypeId != thrusterID)
			{
				log("not a thruster: " + thruster.DefinitionDisplayNameText, "addRemoveThruster()", Logger.severity.TRACE);
				return;
			}

			float change;
			switch (thruster.BlockDefinition.SubtypeId)
			{
				case "SmallBlockSmallThrust":
					change = small_small;
					break;
				case "SmallBlockLargeThrust":
					change = small_large;
					break;
				case "LargeBlockSmallThrust":
					change = large_small;
					break;
				case "LargeBlockLargeThrust":
					change = large_large;
					break;
				default:
					if (add)
					{
						log("unknown thruster(" + thruster.DefinitionDisplayNameText + "), using small_small value", "addRemoveThruster()", Logger.severity.TRACE);
						change = small_small;
						break;
					}
					else // removed
					{
						log("unknown thruster(" + thruster.DefinitionDisplayNameText + "), using large_large value", "addRemoveThruster()", Logger.severity.TRACE);
						change = large_large;
						break;
					}
			}

			if (!add)
				change = -change;

			Base6Directions.Direction direction = Base6Directions.GetFlippedDirection(thruster.Orientation.Forward);

			log("thrust power change " + change + ":" + direction, "addRemoveThruster()", Logger.severity.INFO);
			thrustProfile[direction] += change;
			if (thrustProfile[direction] < small_small)
			{
				thrustProfile[direction] = small_small;
				log("thrustProfile["+direction+"] is too low, setting to small_small", "addRemoveThruster()", Logger.severity.TRACE);
			}
		}

		private void grid_OnBlockAdded(IMySlimBlock added) { addRemoveThruster(added.FatBlock, true); }

		private void grid_OnBlockRemoved(IMySlimBlock removed) { addRemoveThruster(removed.FatBlock, false); }

		internal void assessPower(bool damping = true)
		{
			log("entered assessPower("+damping+")", "assessPower()", Logger.severity.TRACE);

			Vector3 acceleration = myGrid.Physics.LinearAcceleration;
			if (acceleration == Vector3.Zero)
			{
				if (myGrid.Physics.CanUpdateAccelerations)
				{
					myGrid.Physics.UpdateAccelerations();
					acceleration = myGrid.Physics.LinearAcceleration;
				}
				else {
					log("cannot update accelerations", "assessPower()", Logger.severity.WARNING);
					return;
				}
			}

			Vector3 accelerationGridRelative = acceleration.Dot(myGrid.WorldMatrix.Right) * Base6Directions.GetVector(Base6Directions.Direction.Right);
			accelerationGridRelative += acceleration.Dot(myGrid.WorldMatrix.Up) * Base6Directions.GetVector(Base6Directions.Direction.Up);
			accelerationGridRelative += acceleration.Dot(myGrid.WorldMatrix.Backward) * Base6Directions.GetVector(Base6Directions.Direction.Backward);

			if (!damping)
				accelerationGridRelative *= 10;

			log("accelerations: "+acceleration+", "+accelerationGridRelative, "assessPower()", Logger.severity.TRACE);

			// for each direction, if there is acceleration in that direction, compare it to current value
			foreach (Base6Directions.Direction direction in Enum.GetValues(typeof(Base6Directions.Direction)))
			{
				float accelerationInDirection = accelerationGridRelative.Dot(Base6Directions.GetVector(direction));
				if (accelerationInDirection > 0)
				{
					float currentForceInDirecion = accelerationInDirection / myGrid.Physics.Mass;
					if (currentForceInDirecion > thrustProfile[direction])
					{
						thrustProfile[direction] = currentForceInDirecion;
						log("thrustProfile[" + direction + "] = " + thrustProfile[direction], "assessPower()", Logger.severity.TRACE);
					}
					else
						log("force is less: " + currentForceInDirecion + " <= " + thrustProfile[direction], "assessPower()", Logger.severity.TRACE);
				}
				else
					log("acceleration: "+accelerationGridRelative+" is not in direction: "+direction+", dot="+accelerationInDirection, "assessPower()", Logger.severity.TRACE);
			}
		}


	}
}
