﻿using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

namespace Rynchodon.Autopilot.Command
{
	public class Destination
	{
		public enum type { BLOCK, COORDINATES, GRID }

	}

	public static class Interpreter
	{
		public static Destination toCommand(string commandString)
		{
			commandString = commandString.ToLower();

			switch (commandString[0])
			{

				default:
					return null;
			}
		}
	}
}
