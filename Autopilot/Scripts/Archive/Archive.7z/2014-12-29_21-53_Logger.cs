﻿//	modified from script for Mission 01 by KSWH, id=315628704 on steam

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sandbox.ModAPI;
using Sandbox.Common;

namespace Autopilot
{
	public static class MyLogger
	{
		public static bool enabled = true;

		private static string logFile = "Autopilot.log";
		private static System.IO.TextWriter logWriter = MyAPIGateway.Utilities.WriteFileInLocalStorage(logFile, typeof(MyLogger));
		private static StringBuilder stringCache = new StringBuilder();

		private static int maxNumLines = 100000;
		private static int numLines = 0;

		private static string onlyLogForGrid = "Drone";
		//private static string onlyLogForGrid = "RedShip";
		//private static string onlyLogForGrid = null;

		public static void log(string grid, string className, string[] toLog)
		{
			numLines++;
			if (numLines > maxNumLines || toLog == null)
				return;
			if (onlyLogForGrid != null && grid != null && !Autopilot.Navigator.looseContains(grid, onlyLogForGrid))
				return;

			stringCache.Append(DateTime.Now.ToString("[HH:mm:ss.fff] "));
			if (grid != null)
			{
				if (grid.Length > 10)
					grid = grid.Substring(0, 10);
				stringCache.Append(grid);
				stringCache.Append(": ");
			}
			if (className != null)
			{
				stringCache.Append(className);
				stringCache.Append(": ");
			}
			foreach (string s in toLog)
				stringCache.Append(s);
			logWriter.WriteLine(stringCache);
			logWriter.Flush();
			stringCache.Clear();
		}

		public static void log(string grid, string className, string toLog)
		{
			string[] array = new string[1];
			array[0] = toLog;
			log(grid, className, array);
		}


		internal static void Close()
		{
			if (stringCache.Length > 0)
				logWriter.WriteLine(stringCache);
			logWriter.Flush();
			logWriter.Close();
		}
	}
}
