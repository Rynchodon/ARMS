﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Sandbox.Common;
using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.Definitions;
using Sandbox.Engine;
using Sandbox.Game;
using Sandbox.ModAPI;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;

namespace Autopilot
{
	[MyEntityComponentDescriptor(typeof(MyObjectBuilder_CubeGrid))]
	public class GridLogic : MyGameLogicComponent
	{
//		private const string SHIP_NAME_CONTAINS = "Autopilot";
//		private const string ID_READY = "Autopilot";

		private Scripts.KSWH.MyLogger LOGGER = new Scripts.KSWH.MyLogger("Autopilot.log");

		private MyObjectBuilder_EntityBase m_objectBuilder;

//		private Sandbox.ModAPI.IMyCubeGrid myGrid;
		private bool needToSearch = true;
//		private List<Sandbox.ModAPI.IMySlimBlock> remoteControlBlocks;

		public override void Init(MyObjectBuilder_EntityBase objectBuilder)
		{
			m_objectBuilder = objectBuilder;
//			myGrid = Entity as Sandbox.ModAPI.IMyCubeGrid;
			Entity.NeedsUpdate |= MyEntityUpdateEnum.EACH_100TH_FRAME;
		}/*
			myGrid.OnBlockAdded += myGrid_OnBlockAdded;
			myGrid.OnBlockOwnershipChanged += myGrid_OnBlockOwnershipChanged;
			myGrid.OnBlockRemoved += myGrid_OnBlockRemoved;
		}

		public override void Close()
		{
			myGrid.OnBlockAdded -= myGrid_OnBlockAdded;
			myGrid.OnBlockOwnershipChanged -= myGrid_OnBlockOwnershipChanged;
			myGrid.OnBlockRemoved -= myGrid_OnBlockRemoved;
		}

		private void myGrid_OnBlockAdded(Sandbox.ModAPI.IMySlimBlock blockAdded)
		{
			needToSearch = true;
		}

		private void myGrid_OnBlockOwnershipChanged(Sandbox.ModAPI.IMyCubeGrid blockChanged)
		{
			needToSearch = true;
		}

		private void myGrid_OnBlockRemoved(Sandbox.ModAPI.IMySlimBlock blockRemoved)
		{
			needToSearch = true;
		}*/

		public override void UpdateAfterSimulation100()
		{
			if (needToSearch)
			{
				needToSearch = false;

//				findRemoteControlBlocks();

				LOGGER.WriteLine("update");
			}
		}

/*		private void findRemoteControlBlocks()
		{
			remoteControlBlocks = new List<Sandbox.ModAPI.IMySlimBlock>();
			MyObjectBuilderType remoteControlType = (new MyObjectBuilder_RemoteControl() as MyObjectBuilder_Base).TypeId;
			myGrid.GetBlocks(remoteControlBlocks, block => block.FatBlock.BlockDefinition.TypeId == remoteControlType);

			LOGGER.WriteLine(myGrid.GetFriendlyName()+" has "+remoteControlBlocks.Count+" RC blocks");

			if (remoteControlBlocks.Count > 0)
			{
				foreach (Sandbox.ModAPI.IMySlimBlock block in remoteControlBlocks)
				{
					LOGGER.WriteLine(myGrid.GetFriendlyName()+" found an RC block");
					block.FatBlock.DisplayName = "RC found";
				}
			}
		}*/

		public override MyObjectBuilder_EntityBase GetObjectBuilder(bool copy = false)
		{
			return m_objectBuilder;
		}
	}
}

