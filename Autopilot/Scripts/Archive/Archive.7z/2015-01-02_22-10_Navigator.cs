﻿#define LOG_ENABLED

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//using Sandbox.Common;
//using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
//using Sandbox.Definitions;
//using Sandbox.Engine;
//using Sandbox.Game;
using Sandbox.ModAPI;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using VRageMath;

namespace Autopilot
{
	internal class Navigator : TerminalCommand
	{
		public Sandbox.ModAPI.IMyCubeGrid myGrid { get; private set; }

		private List<Sandbox.ModAPI.IMySlimBlock> remoteControlBlocks;

		private override NavSettings CNS;

		private Collision myCollisionObject;
		private IMyControllableEntity currentRemoteControl_Value;
		private IMyControllableEntity currentRCcontrol
		{
			get { return currentRemoteControl_Value; }
			set
			{
				log("setting new RC ", "currentRCcontrol.set", Logger.severity.TRACE);
				if (currentRemoteControl_Value == value)
				{
					log("currentRemoteControl_Value == value", "currentRCcontrol.set", Logger.severity.TRACE);
					return;
				}

				if (currentRemoteControl_Value != null)
				{
					// actions on old RC
					(currentRemoteControl_Value as IMyTerminalBlock).CustomNameChanged -= remoteControl_OnNameChanged;
					reportState(ReportableState.DISABLED);
				}

				// set new RC and collision
				currentRemoteControl_Value = value;
				if (currentRemoteControl_Value == null)
					myCollisionObject = null;
				else
					myCollisionObject = new Collision(currentRCblock);

				if (currentRemoteControl_Value != null)
				{
					// actions on new RC
					(currentRemoteControl_Value as IMyTerminalBlock).CustomNameChanged += remoteControl_OnNameChanged;
					reportState(ReportableState.OFF);
				}

				// some variables
				rotationPower = 3f;
				decelerateRotation = 1f / 2f;
			}
		}
		private Sandbox.ModAPI.IMyCubeBlock currentRCblock
		{
			get { return currentRemoteControl_Value as Sandbox.ModAPI.IMyCubeBlock; }
			set { currentRCcontrol = value as IMyControllableEntity; }
		}

		internal Navigator(Sandbox.ModAPI.IMyCubeGrid grid)
		{
			myGrid = grid;
		}

		private bool needToInit = true;

		private void init()
		{
			updateBlocks();

			// register for events
			myGrid.OnBlockAdded += OnBlockAdded;
			myGrid.OnBlockOwnershipChanged += OnBlockOwnershipChanged;
			myGrid.OnBlockRemoved += OnBlockRemoved;

			CNS = new NavSettings(this);
			needToInit = false;
		}

		private bool needToUpdateBlocks;
		private static MyObjectBuilderType remoteControlType = (new MyObjectBuilder_RemoteControl() as MyObjectBuilder_Base).TypeId;

		private void updateBlocks()
		{
			needToUpdateBlocks = false;

			//	find remote control blocks
			remoteControlBlocks = new List<Sandbox.ModAPI.IMySlimBlock>();
			myGrid.GetBlocks(remoteControlBlocks, block => block.FatBlock != null && block.FatBlock.BlockDefinition.TypeId == remoteControlType);
		}

		private void OnBlockOwnershipChanged(Sandbox.ModAPI.IMyCubeGrid changedBlock)
		{
			needToUpdateBlocks = true;
		}

		private void OnBlockAdded(Sandbox.ModAPI.IMySlimBlock addedBlock)
		{
			if (addedBlock.FatBlock != null && addedBlock.FatBlock.BlockDefinition.TypeId == remoteControlType)
				needToUpdateBlocks = true;
		}

		private void OnBlockRemoved(Sandbox.ModAPI.IMySlimBlock removedBlock)
		{
			if (removedBlock.FatBlock != null && removedBlock.FatBlock.BlockDefinition.TypeId == remoteControlType)
				needToUpdateBlocks = true;
		}

		private uint updateCount = 0;

		/// <summary>
		/// Causes the ship to fly around, following commands.
		/// Calling more often means more precise movements, calling too often (~ every update) will break functionality.
		/// </summary>
		public void update()
		{
			//DateTime startOfUpdate = DateTime.Now;
			updateCount++; // overflow is fine here

			if (!gridCanNavigate())
				return;
			if (needToInit)
				init();
			if (CNS.lockOnTarget != NavSettings.TARGET.OFF)
				tryLockOn();
			if (CNS.waitUntilNoCheck.CompareTo(DateTime.UtcNow) > 0)
				return;
			if (CNS.waitUntil.CompareTo(DateTime.UtcNow) > 0 || CNS.EXIT)
			{
				if (!remoteControlIsReady(currentRCcontrol as Sandbox.ModAPI.IMyCubeBlock)) // if something changes, stop waiting!
				{
					log("wait interrupted", "update()", Logger.severity.DEBUG);
					reset();
				}
				return;
			}

			if (CNS.getTypeOfWayDest() != NavSettings.TypeOfWayDest.NULL)
				navigate();
			else // no waypoints
			{
				//log("no waypoints or destination");
				if (CNS.instructions.Count > 0)
				{
					while (true)
					{
						addInstruction(CNS.instructions.Dequeue());
						if (CNS.instructions.Count == 0)
						{
							//reportState(ReportableState.NO_COMMANDS);
							CNS.waitUntilNoCheck = DateTime.UtcNow.AddSeconds(1);
							return;
						}
						switch (CNS.getTypeOfWayDest())
						{
							case NavSettings.TypeOfWayDest.BLOCK:
							case NavSettings.TypeOfWayDest.GRID:
								log("got a grid as a destination: " + CNS.getDestGridName());
								reportState(ReportableState.WORKING);
								return;
							case NavSettings.TypeOfWayDest.COORDINATES:
								log("got a new destination " + CNS.getWayDest());
								reportState(ReportableState.WORKING);
								return;
							// default keep going
						}
					}
				}
				else
				{
					// find a remote control with CNS.instructions
					reportState(ReportableState.NO_COMMANDS);
					log("searching for a ready remote control", "update()", Logger.severity.FINE);
					CNS.waitUntilNoCheck = DateTime.UtcNow.AddSeconds(1);
					foreach (Sandbox.ModAPI.IMySlimBlock remoteControlBlock in remoteControlBlocks)
					{
						Sandbox.ModAPI.IMyCubeBlock fatBlock = remoteControlBlock.FatBlock;
						if (remoteControlIsReady(fatBlock, true))
						{
							if (AIOverride)
							{
								if (currentRCcontrol == null)
									currentRCcontrol = (fatBlock as IMyControllableEntity);
							}
							else
							{
								log("found a ready remote control ", "update()", Logger.severity.TRACE);
								//	parse display name
								string displayName = fatBlock.DisplayNameText;
								//RCDisplayName = displayName;
								int start = displayName.IndexOf('[') + 1;
								int end = displayName.IndexOf(']');
								if (start > 0 && end > start) // has appropriate brackets
								{
									int length = end - start;
									string noSpaces = displayName.Substring(start, length).Replace(" ", ""); // remove all spaces
									string[] inst = noSpaces.Split(':'); // split into CNS.instructions
									CNS.instructions = new Queue<string>(inst);
									currentRCcontrol = (fatBlock as IMyControllableEntity);
								}
							}
						}
					}
				}
			}

			// will not always reach here
			/*TimeSpan toUpdate = DateTime.Now - startOfUpdate;
			//log("toUpdate took " + toUpdate, "update()", Logger.severity.TRACE);
			if (toUpdate.TotalMilliseconds > 100)
			{
				double delay = toUpdate.TotalMilliseconds * 10;
				CNS.waitUntilNoCheck = DateTime.UtcNow.AddSeconds(delay);
				log("Navigator is hogging resources, force delay of " + delay, "update()", Logger.severity.WARNING);
			}*/
			//log("\tTTU is "+toUpdate.Milliseconds);
		}

		private static DateTime tryLockOnLastGlobal;
		private DateTime tryLockOnLastLocal;
		private static DateTime sanityCheckMin = DateTime.Today.AddDays(-1);

		private void tryLockOn()
		{
			//log("entered tryLockOn");

			if (CNS.lockOnTarget == NavSettings.TARGET.OFF)
				return;

			DateTime now = DateTime.UtcNow;

			if (tryLockOnLastLocal > sanityCheckMin)
			{
				double secondsSinceLocalUpdate = (now - tryLockOnLastLocal).TotalSeconds;
				if (secondsSinceLocalUpdate < 1)
					return;
				double millisecondDelayGlobal = 9000 / secondsSinceLocalUpdate + 100;
				if (now < tryLockOnLastGlobal.AddMilliseconds(millisecondDelayGlobal))
					return;
			}
			else if (tryLockOnLastGlobal > sanityCheckMin && now < tryLockOnLastGlobal.AddMilliseconds(100))
				return;

			log("trying to lock on type="+CNS.lockOnTarget, "tryLockOn()", Logger.severity.TRACE);
			tryLockOnLastGlobal = now;
			tryLockOnLastLocal = now;

			Sandbox.ModAPI.IMyCubeBlock closestBlock;
			Sandbox.ModAPI.IMyCubeGrid closestEnemy = findCubeGrid(out closestBlock, false, null, CNS.lockOnBlock, CNS.lockOnRange);
			if (closestEnemy == null)
			{
				//TODO check current target for validity
				//log("no enemy found");
				return;
			}

			// found an enemy, setting as destination
			if (closestBlock != null)
				log("found an enemy: " + closestEnemy.DisplayName + ":" + closestBlock.DisplayNameText);
			else
				log("found an enemy: " + closestEnemy.DisplayName);
			CNS.setDestination(closestEnemy, closestBlock);
			if (CNS.lockOnTarget == NavSettings.TARGET.MISSILE)
				CNS.isAMissile = true;
			CNS.waitUntil = DateTime.UtcNow;
		}

		private static int maxLockOnRangeEnemy = 1100; // only lock-onto enemies closer than this

		private override Sandbox.ModAPI.IMyCubeGrid findCubeGrid(out Sandbox.ModAPI.IMyCubeBlock closestBlock, bool friend = true, string nameContains = null, string blockContains = null, double lockOnRangeEnemy = 0)
		{
			//log("entered findCubeGrid: " + friend + ", " + nameContains + ", " + blockContains + ", " + lockOnRangeEnemy);
			if (lockOnRangeEnemy < 1 || maxLockOnRangeEnemy < lockOnRangeEnemy)
				lockOnRangeEnemy = maxLockOnRangeEnemy;

			closestBlock = null;

			Dictionary<double, Sandbox.ModAPI.IMyCubeGrid> nearbyGrids = new Dictionary<double, Sandbox.ModAPI.IMyCubeGrid>();

			HashSet<IMyEntity> entities = new HashSet<IMyEntity>();
			MyAPIGateway.Entities.GetEntities(entities, e => e is Sandbox.ModAPI.IMyCubeGrid);
			foreach (IMyEntity entity in entities)
			{
				Sandbox.ModAPI.IMyCubeGrid grid = entity as Sandbox.ModAPI.IMyCubeGrid;
				if (Core.isHostile(myGrid, grid) == friend)
					continue;
				if (nameContains == null || looseContains(grid.DisplayName, nameContains))
				{
					double distance = grid.WorldAABB.Distance(getMyPosition());
					if (friend || distance < lockOnRangeEnemy)
					{
						bool added = false;
						while (!added)
						{
							try
							{
								nearbyGrids.Add(distance, grid);
								added = true;
							}
							catch (ArgumentException) { distance += 0.001; }
						}
					}
				}
			}
			if (nearbyGrids.Count > 0)
				foreach (KeyValuePair<double, Sandbox.ModAPI.IMyCubeGrid> pair in nearbyGrids.OrderBy(i => i.Key))
					if (blockContains == null || findClosestCubeBlockOnGrid(out closestBlock, pair.Value, blockContains, !friend))
						return pair.Value;

			closestBlock = null;
			return null;
		}

		/// <summary>
		/// finds the closest block on a grid that contains the specified string
		/// </summary>
		/// <param name="grid"></param>
		/// <param name="blockContains"></param>
		/// <param name="searchByDefinition"></param>
		/// <returns></returns>
		private bool findClosestCubeBlockOnGrid(out Sandbox.ModAPI.IMyCubeBlock closestBlock, Sandbox.ModAPI.IMyCubeGrid grid, string blockContains, bool searchByDefinition = false) //, bool getAny = false)
		{
			//log("entered findClosestCubeBlockOnGrid: " + grid.DisplayName + ", " + blockContains + ", " + searchByDefinition + ", " + getAny);
			List<Sandbox.ModAPI.IMySlimBlock> allBlocks = new List<Sandbox.ModAPI.IMySlimBlock>();
			closestBlock = null;
			double distanceToClosest = 0;
			grid.GetBlocks(allBlocks);
			foreach (Sandbox.ModAPI.IMySlimBlock blockInGrid in allBlocks)
			{
				if (blockInGrid.FatBlock == null)
					continue;
				Sandbox.ModAPI.IMyCubeBlock fatBlock = blockInGrid.FatBlock;
				string toSearch;
				if (searchByDefinition)
					toSearch = fatBlock.DefinitionDisplayNameText;
				else
					toSearch = fatBlock.DisplayNameText;
				toSearch = toSearch.ToLower();
				if (looseContains(toSearch, blockContains))
				{
					double distance = (fatBlock.GetPosition() - getMyPosition()).Length();
					if (closestBlock == null || distance < distanceToClosest)
					{
						closestBlock = fatBlock;
						distanceToClosest = distance;
					}
				}
			}
			return (closestBlock != null);
		}

		/// <summary>
		/// checks for is a station, is owned by current session's player, grid exists
		/// </summary>
		/// <returns>true iff it is possible for this grid to navigate</returns>
		public bool gridCanNavigate()
		{
			if (myGrid == null)
			{
				log("grid is gone...", "gridCanNavigate()", Logger.severity.INFO);
				return false;
			}
			if (myGrid.IsStatic)
				return false;

			if (myGrid.BigOwners.Count > 0)
				return Core.canControl(myGrid);

			return false;
		}

		private bool remoteControlIsNotReady = false;

		/// <summary>
		/// checks the functional and working flags, current player owns it, display name has not changed
		/// </summary>
		/// <param name="remoteControl">remote control to check</param>
		/// <returns>true iff the remote control is ready</returns>
		public bool remoteControlIsReady(Sandbox.ModAPI.IMyCubeBlock remoteControl, bool skipNameCheck = false)
		{
			if (remoteControlIsNotReady)
			{
				remoteControlIsNotReady = false;
				return false;
			}

			if (remoteControl == null)
			{
				log("no remote control", "remoteControlIsReady()", Logger.severity.FINE);
				return false;
			}

			if (!remoteControl.IsFunctional || !remoteControl.IsWorking)
			{
				log("not functional and working", "remoteControlIsReady()", Logger.severity.FINE);
				return false;
			}

			if (!Core.canControl(remoteControl))
			{
				log("cannot control", "remoteControlIsReady()", Logger.severity.FINE);
				return false;
			}

			if (!(remoteControl as IMyShipController).ControlThrusters)
			{
				log("no thruster control", "remoteControlIsReady()", Logger.severity.FINE);
				return false;
			}

			/*if (!(remoteControl.GetObjectBuilderCubeBlock() as MyObjectBuilder_RemoteControl).ControlThrusters)
				return false;

			if ((remoteControl.GetObjectBuilder() as MyObjectBuilder_CubeGrid).Handbrake)
				return false;*/

			//if (skipNameCheck || AIOverride)
				return true;
			//return (remoteControl.DisplayNameText.Equals(RCDisplayName));
		}

		public bool remoteControlIsReady(IMyControllableEntity remoteControl, bool skipNameCheck = false)
		{
			return remoteControlIsReady(remoteControl as Sandbox.ModAPI.IMyCubeBlock, skipNameCheck);
		}

		/// <summary>
		/// stop the ship, return navigation variables to their defaults, clears current remote control
		/// </summary>
		public override void reset()
		{
			log("resetting");
			if (currentRCcontrol != null)
			{
				try
				{
					fullStop();
				}
				catch (NullReferenceException) // when grid is destroyed
				{
					//currentRCcontrol.MoveAndRotateStopped();
				}
				//log("clearing current remote control");
				currentRCcontrol = null;
			}
			if (needToUpdateBlocks)
				updateBlocks();
			CNS = new NavSettings(this);
		}

		private double needToRotateX; // from start of rotation
		private double needToRotateY; // from start of rotation
		private double? previousX = null;
		private double? previousY = null;
		//private double moveDistance; // from start of leg to waypoint
		private double distanceToWaypoint; // from current position
		private double previousDistanceToWaypoint;
		private Vector3D? previousPosition = null;
		private DateTime? previousTime = null;
		double movementSpeed = 0;
		Vector3D currentPos;
		//private double? previousMovementSpeed = null;

		private float rotationPower = 3f;
		private float decelerateRotation = 1f / 2f; // how much of rotation should be deceleration
		//private float decelerateMovement = 1f / 2f; // how much of movement should be deceleration, only used when grid's deceleration is unknown
		private static float decelerateAdjustmentOver = 1.10f; // adjust decelerate by this much when overshoot
		private static float decelerateAdjustmentUnder = 0.95f; // adjust decelerate by this much when undershoot
		private static float rotationPowerAdjustmentOver = 0.90f;
		private static float rotationPowerAdjustmentUnder = 1.05f;

		private DateTime maxRotateTime;

		/// <summary>
		/// when true collision avoidance has failed to find a path, stop Navigator
		/// </summary>
		//private bool NO_WAY_FORWARD = false;
		//private DateTime lastCollisionCheck = DateTime.UtcNow;

		// TODO: strafe short distances/manually
		private void navigate()
		{
			Vector3D currentWaypoint = (Vector3D)CNS.getWayDest(); // update() checked for null
			//log("entered navigate(" + currentWaypoint + ")");
			if (!remoteControlIsReady(currentRCcontrol as Sandbox.ModAPI.IMyCubeBlock))
			{
				log("remote control is not ready");
				reset();
				return;
			}

			//log("cRC pos: "+(currentRemoteControl as IMyEntity).GetPosition());
			Vector3D displacement = currentWaypoint - getMyPosition();// (currentRemoteControl as IMyEntity).GetPosition();
			//log("displacement vector: "+displacement);

			Vector3D dirNorm = Vector3D.Normalize(displacement);
			double x = (currentRCcontrol as IMyEntity).WorldMatrix.Down.Dot(dirNorm);
			double y = (currentRCcontrol as IMyEntity).WorldMatrix.Right.Dot(dirNorm);
			double forw = (currentRCcontrol as IMyEntity).WorldMatrix.Forward.Dot(dirNorm);
			// x and y now represent how far the ship needs to turn to be facing in the correct direction (0,0) means facing the right way

			//log("movement: "+x+", "+y+", "+forw);

			if (forw < 0) // destination is behind myGrid
			{
				if (y > 0)
					y = 1;
				else
					y = -1;
			}

			x *= rotationPower;
			y *= rotationPower;

			distanceToWaypoint = displacement.Length();

			// calculate speed & acceleration
			currentPos = getMyPosition();
			DateTime currentTime = DateTime.UtcNow;
			//double movementSpeed = 0;

			if (previousPosition != null && previousTime != null)
			{
				double elapsedTime = ((TimeSpan)(currentTime - previousTime)).TotalSeconds;
				//log("calculating time " + elapsedTime + " = " + currentTime + " - " + previousTime);
				if (elapsedTime >= 0.1)
				{
					double distanceTraveled = (currentPos - (Vector3D)previousPosition).Length();
					if (distanceTraveled > 0.1)
						movementSpeed = distanceTraveled / elapsedTime;
					else
						movementSpeed = 0;
					//log("setting speed "+movementSpeed+" = "+distanceTraveled+" / "+elapsedTime);
					previousPosition = currentPos;
					previousTime = currentTime;
				}
			}
			else
			{
				previousPosition = currentPos;
				previousTime = currentTime;
			}

			if (CNS.moveState == NavSettings.Moving.NOT_MOVING && startOfDecelMeasureVec != null)
			{
				double distanceTraveled = (currentPos - (Vector3D)startOfDecelMeasureVec).Length();
				if (distanceTraveled > 1)
				{
					if (decelMeasureCoefficient < 0.1)
						decelMeasureCoefficient = distanceTraveled / startOfDecelMeasureSpeed;
					else
						decelMeasureCoefficient = 0.9 * decelMeasureCoefficient + 0.1 * distanceTraveled / startOfDecelMeasureSpeed;
					//log("got a measurement for deceleration: " + distanceTraveled + " / " + startOfDecelMeasureSpeed + ", " + CNS.decelMeasureCoefficient);
				}
				startOfDecelMeasureSpeed = 0;
				startOfDecelMeasureVec = null;
			}

			if (distanceToWaypoint < CNS.destinationRadius && !CNS.isAMissile) // at destination
			{
				if (CNS.getTypeOfWayDest() == NavSettings.TypeOfWayDest.WAYPOINT)
				{
					CNS.atWayDest();
					if (CNS.getTypeOfWayDest() == NavSettings.TypeOfWayDest.NULL)
					{
						log("Error no more destinations at Navigator.navigate() // at destination", "navigate()", Logger.severity.ERROR);
						fullStop();
					}
					else
					{
						log("reached waypoint, next type is " + CNS.getTypeOfWayDest() + ", coords: " + CNS.getWayDest(), "navigate()", Logger.severity.INFO);
						//fullStop();
					}
				}
				else if (CNS.moveState == NavSettings.Moving.NOT_MOVING)
				{
					log("reached destination", "navigate()", Logger.severity.INFO);
					fullStop();
					CNS.atWayDest();
					//CNS.curNavState = NavSettings.State.DESTINATION;
				}
				else if (CNS.moveState != NavSettings.Moving.STOPPING_M)
				{
					log("stopping at destination");
					fullStop();
					CNS.moveState = NavSettings.Moving.STOPPING_M;
				}
			}
			else // not at destination
			{
				if (!CNS.isAMissile)// && CNS.collAtDest == NavSettings.COL_DEST.NOT_AT)
				{
					//if (!CNS.isAMissile	&& (CNS.curNavState == NavSettings.State.MOVING || CNS.inflightAdjustment ))
					//&& (DateTime.UtcNow - lastCollisionCheck).TotalMilliseconds > 100)
					//{
					//log("CNS.destinationRadius=" + CNS.destinationRadius + ", movementSpeed=" + movementSpeed + ", stoppingDistance=" + getStoppingDistance(movementSpeed));
					Collision.collisionAvoidResult currentAvoidResult = myCollisionObject.avoidCollisions(ref CNS, (int)(CNS.destinationRadius + 3 * getStoppingDistance(movementSpeed)), updateCount);
					//collisionAvoidResult currentAvoidResult = collisionAvoidance(2*getStoppingDistance(movementSpeed));
					//log("got a currentAvoidResult "+currentAvoidResult, "navigate()", Logger.severity.TRACE);
					//lastCollisionCheck = DateTime.UtcNow;
					switch (currentAvoidResult)
					{
						case Collision.collisionAvoidResult.NOT_FINISHED:
							break;
						//case Collision.collisionAvoidResult.AT_DEST_GRID:
						//CNS.collAtDest = NavSettings.COL_DEST.AT_DEST;
						//log("collAtDest, setting speed limit");
						//break;
						case Collision.collisionAvoidResult.ALTERNATE_PATH:
							log("got a currentAvoidResult " + currentAvoidResult, "navigate()", Logger.severity.TRACE);
							//CNS.collisionUpdateSinceWaypointAdded++;
							//CNS.curNavState = NavSettings.State.DEMOVE;
							fullStop();
							break;
						case Collision.collisionAvoidResult.NO_WAY_FORWARD:
							log("got a currentAvoidResult " + currentAvoidResult, "navigate()", Logger.severity.INFO);
							//CNS.collisionUpdateSinceWaypointAdded++;
							//log("NO WAY FORWARD");
							CNS.noWayForward = true;
							reportState(ReportableState.NO_PATH);
							fullStop();
							break;
						case Collision.collisionAvoidResult.NO_OBSTRUCTION:
							//CNS.collisionUpdateSinceWaypointAdded++;
							simpleMoveOrRotate(x, y, movementSpeed);
							break;
						default:
							log("Error: unsuitable case from avoidCollisions(): " + currentAvoidResult, "navigate()", Logger.severity.ERROR);
							fullStop();
							break;
					}
				}
				else
					simpleMoveOrRotate(x, y, movementSpeed);
			}

			if (isStopped(x, y, movementSpeed))
			{
				if (CNS.moveState == NavSettings.Moving.STOPPING_M)
					//log("now stopped");
					CNS.moveState = NavSettings.Moving.NOT_MOVING;
				else if (CNS.moveState == NavSettings.Moving.MOVING)
					CNS.moveState = NavSettings.Moving.STOPPING_M;
			}

			previousX = x;
			previousY = y;
			previousDistanceToWaypoint = distanceToWaypoint;
			//			previousMovementSpeed = movementSpeed;
		}

		private bool changeRotationPower = false;
		/// <summary>
		/// start moving when less than
		/// </summary>
		private static float rotLenSq_startMove = 4f;
		/// <summary>
		/// inflight rotate when greater than
		/// </summary>
		private static float rotLenSq_inflight = 0.1f;
		/// <summary>
		/// stop and rotate when greater than
		/// </summary>
		private static float rotLenSq_stopAndRot = 10f;

		private void simpleMoveOrRotate(double x, double y, double? movementSpeed)
		{
			//log("entered simpleMoveOrRotate("+x+", "+y+", "+movementSpeed+", "+currentPos+")");

			if (CNS.noWayForward)
				return;
			//if (CNS.curNavState == NavSettings.State.STOPPING)
			//return;

			Vector2 rot = new Vector2((float)x, (float)y);
			double stoppingDistance = getStoppingDistance(movementSpeed);

			if (!CNS.isAMissile && (CNS.moveState == NavSettings.Moving.MOVING))
			{
				double varDistWay = distanceToWaypoint;
				switch (CNS.getTypeOfWayDest())
				{
					case NavSettings.TypeOfWayDest.BLOCK:
					case NavSettings.TypeOfWayDest.GRID:
						varDistWay = CNS.gridDestination.WorldAABB.Distance(currentRCblock.GetPosition());
						//log("box check, changing using distance of " + varDistWay + " instead of " + distanceToWaypoint);
						goto case NavSettings.TypeOfWayDest.COORDINATES;
					case NavSettings.TypeOfWayDest.COORDINATES:
						if (varDistWay < 5 * stoppingDistance)
						{
							//log("on aproach, setting speed limit=" + (int)(movementSpeed * 0.9));
							CNS.speedSlow_internal = (int)(movementSpeed * 0.9);
							CNS.speedCruise_internal = 1;
							//isCruising = false;
						}
						break;
				}
			}

			float rotLengthSq = Math.Abs(rot.LengthSquared());
			checkAndCruise(rotLengthSq);
			if (CNS.moveState == NavSettings.Moving.NOT_MOVING && CNS.rotateState == NavSettings.Rotating.NOT_ROTATING)
			{
				if (rotLengthSq < rotLenSq_startMove) // missiles were missing too much anyway
				{
					/*if (CNS.collisionUpdateSinceWaypointAdded < 2)
					{
						log("cannot move yet, waiting for collision update: " + CNS.collisionUpdateSinceWaypointAdded);
						return;
					}*/

					move(Vector3.Forward); // move forward
					log("moving " + distanceToWaypoint + " to " + CNS.getWayDest() + ", rotLengthSq=" + rotLengthSq + ", x=" + x + ", y=" + y);
					stoppedMovingAt = DateTime.UtcNow + stoppedAfter;
					CNS.moveState = NavSettings.Moving.MOVING;
					return;
				}
			}

			//log("need to rotate "+rot.Length());
			// need to rotate
			switch (CNS.rotateState)
			{
				case NavSettings.Rotating.NOT_ROTATING:
					switch (CNS.moveState)
					{
						case NavSettings.Moving.MOVING:
							{
								if (rotLengthSq < rotLenSq_inflight)
									return;
								if (rotLengthSq > rotLenSq_stopAndRot)
								{
									log("stopping to rotate");
									fullStop();
									return;
								}
								else
								{// make a small, inflight adjustment
									log("need to adjust: " + x + ", " + y);
									// cannot use inflight adjustment for rotation measurement, movement also affects x and y
									needToRotateX = x;
									needToRotateY = y;
									changeRotationPower = false;
									rotate(rot); // rotate towards target
									CNS.rotateState = NavSettings.Rotating.ROTATING;
									maxRotateTime = DateTime.UtcNow.AddSeconds(3);
									return;
								}
							}
						case NavSettings.Moving.NOT_MOVING:
							{
								//log("starting rotation: " + x + ", " + y);
								needToRotateX = x;
								needToRotateY = y;
								changeRotationPower = true;
								rotate(rot); // rotate towards target
								CNS.rotateState = NavSettings.Rotating.ROTATING;
								maxRotateTime = DateTime.UtcNow.AddSeconds(10);
								return;
							}
					}
					return;
				case NavSettings.Rotating.STOPPING_R:
					{
						if (isNotRotating())
						{
							int overUnder = 0;
							log("checking for over/under shoot on rotation: x="+x+", needX="+needToRotateX+", y="+y+", needY="+needToRotateY);
							//	check for overshoot/undershoot
							if (Math.Abs(x) > 0.1 && Math.Abs(needToRotateX) > 0.1)
								if ((x > 0 && needToRotateX > 0) || (x < 0 && needToRotateX < 0))
									overUnder--;
								else
									overUnder++;
							if (Math.Abs(y) > 0.1 && Math.Abs(needToRotateY) > 0.1)
								// assume (needToRotateY != 0)
								if ((y > 0 && needToRotateY > 0) || (y < 0 && needToRotateY < 0))
									overUnder--;
								else
									overUnder++;

							if (overUnder != 0)
							{
								if (changeRotationPower)
								{
									if (overUnder > 0) // over rotated
										rotationPower *= rotationPowerAdjustmentOver;
									else // under rotated
										rotationPower *= rotationPowerAdjustmentUnder;
									log("adjusted rotPower, new value is " + rotationPower + " under/over is " + overUnder + " x=" + x + "/" + needToRotateX + ", y=" + y + "/" + needToRotateY);
									if (rotationPower < 0.1)
									{
										log("rotation power(" + rotationPower + ") is below min. under/over is " + overUnder + " x=" + x + "/" + needToRotateX + ", y=" + y + "/" + needToRotateY, "simpleMoveOrRotate()", Logger.severity.WARNING);
										rotationPower = 0.1f;
									}
									else if (rotationPower > 100)
									{
										log("rotation power(" + rotationPower + ") is above max. under/over is " + overUnder + " x=" + x + "/" + needToRotateX + ", y=" + y + "/" + needToRotateY, "simpleMoveOrRotate()", Logger.severity.WARNING);
										rotationPower = 100;
									}
								}
								else
								{
									if (overUnder > 0) // over rotated
										decelerateRotation *= decelerateAdjustmentOver;
									else // under rotated
										decelerateRotation *= decelerateAdjustmentUnder;
									log("adjusted derotate, new value is " + decelerateRotation + " under/over is " + overUnder + " x=" + x + "/" + needToRotateX + ", y=" + y + "/" + needToRotateY);
									if (decelerateRotation < 0.1)
									{
										log("decelerateRotation(" + rotationPower + ") is below min. under/over is " + overUnder + " x=" + x + "/" + needToRotateX + ", y=" + y + "/" + needToRotateY, "simpleMoveOrRotate()", Logger.severity.WARNING);
										decelerateRotation = 0.1f;
									}
									else if (decelerateRotation > 0.9)
									{
										log("decelerateRotation(" + rotationPower + ") is above max. under/over is " + overUnder + " x=" + x + "/" + needToRotateX + ", y=" + y + "/" + needToRotateY, "simpleMoveOrRotate()", Logger.severity.WARNING);
										decelerateRotation = 0.9f;
									}
								}
							}
							needToRotateX = 0;
							needToRotateY = 0;
							CNS.rotateState = NavSettings.Rotating.NOT_ROTATING;
						}
						return;
					}
				case NavSettings.Rotating.ROTATING:
					{
						// check for need to derotate
						//						log("checking rotation (" + x + ", " + y + ", " + needToRotateX + ", " + needToRotateY + ")");
						if ((needToRotateX > 0.1 && x < needToRotateX * decelerateRotation)
							|| (needToRotateX < -0.1 && x > needToRotateX * decelerateRotation)
							|| (needToRotateY > 0.1 && y < needToRotateY * decelerateRotation)
							|| (needToRotateY < -0.1 && y > needToRotateY * decelerateRotation)
							|| DateTime.UtcNow >= maxRotateTime)
						{
							log("decelerate rotation (" + x + ", " + y + ", " + needToRotateX + ", " + needToRotateY + ")");
							rotate(Vector2.Zero); // stop rotating
							CNS.rotateState = NavSettings.Rotating.STOPPING_R;
						}
						return;
					}
			}
		}

		private static TimeSpan stoppedAfter = new TimeSpan(0,0,0,1);
		private DateTime stoppedMovingAt;

		private bool isStopped(double? x, double? y, double? speed)
		{
			if (speed == null || previousX == null || previousY == null
				|| Math.Abs((double)(previousX - x)) > 0.01f || Math.Abs((double)(previousY - y)) > 0.01f || speed > 0.1f)
			{
				stoppedMovingAt = DateTime.UtcNow + stoppedAfter;
				return false;
			}
			else
				return DateTime.UtcNow > stoppedMovingAt;
		}

		private DateTime stoppedRotatingAt;
		/// <summary>
		/// this is based on ship forward
		/// </summary>
		private Vector3D? facing = null;

		private bool isNotRotating()
		{
			Vector3D origin = myGrid.GetPosition();
			Vector3D forward = myGrid.GridIntegerToWorld(Vector3I.Forward);
			Vector3D currentFace = forward - origin;

			bool currentlyRotating;
			if (facing == null)
				currentlyRotating = true;
			else
			{
				Vector3D prevFace = (Vector3D)facing;
				if (Math.Abs(currentFace.X - prevFace.X) > 0.1 || Math.Abs(currentFace.Y - prevFace.Y) > 0.1 || Math.Abs(currentFace.Z - prevFace.Z) > 0.1)
				{
					currentlyRotating = true;
					//log("rotating, x=" + Math.Abs(currentFace.X - prevFace.X) + ", y=" + Math.Abs(currentFace.Y - prevFace.Y) + ", z=" + Math.Abs(currentFace.Z - prevFace.Z) + ", S.A.=" + stoppedRotatingAt);
				}
				else
				{
					currentlyRotating = false;
					//log("not rotating, x=" + Math.Abs(currentFace.X - prevFace.X) + ", y=" + Math.Abs(currentFace.Y - prevFace.Y) + ", z=" + Math.Abs(currentFace.Z - prevFace.Z) + ", S.A.=" + stoppedRotatingAt);
				}
			}
			facing = currentFace;

			if (currentlyRotating)
			{
				//log("rotating");
				stoppedRotatingAt = DateTime.UtcNow + stoppedAfter;
				return false;
			}
			else
				return DateTime.UtcNow > stoppedRotatingAt;
		}

		private double startOfDecelMeasureSpeed = 0;
		private Vector3D? startOfDecelMeasureVec = null;

		/// <summary>
		/// for other kinds of stop use move(Vector3.Zero) or similar
		/// </summary>
		private void fullStop()
		{
			log("full stop");
			currentMove = Vector3.Zero;
			currentRotate = Vector2.Zero;
			currentRoll = 0;
			CNS.speedCruise_internal = int.MaxValue;
			CNS.speedSlow_internal = int.MaxValue;

			setDampeners();
			currentRCcontrol.MoveAndRotateStopped();

			if (movementSpeed > 1 && CNS.moveState == NavSettings.Moving.MOVING)
			{
				//CNS.moveState = NavSettings.Moving.STOPING_M;
				startOfDecelMeasureSpeed = (double)movementSpeed;
				startOfDecelMeasureVec = currentPos;
			}
			CNS.moveState = NavSettings.Moving.STOPPING_M;
			CNS.rotateState = NavSettings.Rotating.STOPPING_R;
			needToRotateX = 0;
			needToRotateY = 0;
		}

		private Vector3 currentMove = Vector3.Zero;
		private Vector2 currentRotate = Vector2.Zero;
		private float currentRoll = 0;

		private void move(Vector3 move)
		{
			//log("entered move("+move+")");
			if (currentMove == move)
				return;
			currentMove = move;
			moveAndRotate();
		}

		private void rotate(Vector2 rotate)
		{
			//log("entered rotate("+rotate+")");
			if (currentRotate == rotate)
				return;
			currentRotate = rotate;
			moveAndRotate();
		}

		private void roll(float roll)
		{
			//log("entered roll("+roll+")");
			if (currentRoll == roll)
				return;
			currentRoll = roll;
			moveAndRotate();
		}

		private void moveAndRotate()
		{
			//isCruising = false;
			if (currentMove == Vector3.Zero && currentRotate == Vector2.Zero && currentRoll == 0)
			{
				log("MAR is actually stop");
				currentRCcontrol.MoveAndRotateStopped();
			}
			else
			{
				log("doing MAR(" + currentMove + ", " + currentRotate + ", " + currentRoll + ")");
				currentRCcontrol.MoveAndRotate(currentMove, currentRotate, currentRoll);
			}
		}

		/*private bool areDampenersOn()
		{
			return (myGrid.GetObjectBuilder() as MyObjectBuilder_CubeGrid).DampenersEnabled;
		}*/

		private void setDampeners(bool dampenersOn = true)
		{
			if ((myGrid.GetObjectBuilder() as MyObjectBuilder_CubeGrid).DampenersEnabled != dampenersOn)
			{
				currentRCcontrol.SwitchDamping();
				if (!dampenersOn)
					log("speed control: disabling dampeners. speed=" + movementSpeed + ", cruise=" + CNS.getSpeedCruise() + ", slow=" + CNS.getSpeedSlow());
				else
					log("speed control: enabling dampeners. speed=" + movementSpeed + ", cruise=" + CNS.getSpeedCruise() + ", slow=" + CNS.getSpeedSlow());
			}
		}

		private static Vector3 cruiseForward = new Vector3(0, 0, -0.001); // hopefully this minimum is consistent
		/// <summary>
		/// call every run, needed to enable dampeners
		/// two options for cruise: use cruiseForward, or disable dampeners
		/// </summary>
		private void checkAndCruise(float rotLengthSq)
		{
			if (CNS.moveState != NavSettings.Moving.MOVING)
			{
				setDampeners();
				return;
			}

			if (movementSpeed > CNS.getSpeedSlow())
			{
				setDampeners();
				move(Vector3.Zero);
				return;
			}
			if (movementSpeed < CNS.getSpeedCruise())
			{
				setDampeners();
				move(Vector3.Forward);
				return;
			}
			if (CNS.rotateState == NavSettings.Rotating.NOT_ROTATING) // as long as state change comes after checkAndCruise, this will work
			{
				// disable dampeners
				setDampeners(false);
				move(Vector3D.Zero);
				return;
			}
			else
			{
				// use cruise vector
				move(cruiseForward);
				setDampeners();
				return;
			}
		}

		private static double decelMeasureCoefficient = 1f;

		private double getStoppingDistance(double? speed)
		{
			//if (CNS.decelMeasureCoefficient >= 0.1)
			return decelMeasureCoefficient * (double)speed;
			//else
			//return moveDistance * decelerateMovement;
		}

		private Logger myLogger = null;// = new Logger(myGrid.DisplayName, "Collision");
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			if (myLogger == null)
				myLogger = new Logger(myGrid.DisplayName, "Navigator");
			if (myLogger.canLog(level))
				myLogger.log(level, method, toLog, CNS.moveState.ToString(), CNS.rotateState.ToString());
		}

		public override string ToString()
		{
			return "Nav:" + myGrid.DisplayName;
		}

		public Vector3D getMyPosition()
		{
			if (currentRCcontrol == null)
				return myGrid.GetPosition();
			else
				return (currentRCcontrol as Sandbox.ModAPI.IMyCubeBlock).GetPosition();
		}

		private enum ReportableState : byte {OFF, WORKING, NO_PATH, NO_COMMANDS, DISABLED};
		private ReportableState currentReportable = ReportableState.DISABLED;

		/// <summary>
		/// may ignore the given state, if Nav is actually in another state
		/// </summary>
		/// <param name="newState"></param>
		private void reportState(ReportableState newState)
		{
			log("entered reportState()", "reportState()", Logger.severity.TRACE);
			if (currentRemoteControl_Value == null)
			{
				log("cannot report without RC", "reportState()", Logger.severity.TRACE);
				return;
			}

			string displayName = (currentRemoteControl_Value as Sandbox.ModAPI.IMyCubeBlock).DisplayNameText;
			if (displayName == null)
			{
				log("cannot report without display name", "reportState()", Logger.severity.WARNING);
				return;
			}

			if (CNS.noWayForward)
			{
				log("changing report to NO_PATH(noWayForward)", "reportState()", Logger.severity.FINE);
				newState = ReportableState.NO_PATH;
			}
			if (CNS.EXIT)
			{
				newState = ReportableState.OFF;
			}

			// did state actually change?
			if (newState == currentReportable)
				return;

			// cut old state, if any
			int endOfState = displayName.IndexOf('>');
			if (endOfState != -1)
				displayName = displayName.Substring(endOfState+1);

			// add new state
			StringBuilder newName = new StringBuilder();
			newName.Append('<');
			newName.Append(newState);
			newName.Append('>');
			newName.Append(displayName);
			//RCDisplayName = newName.ToString();

			ignore_RemoteControl_nameChange = true;
			(currentRemoteControl_Value as IMyRemoteControl).SetCustomName(newName);
			ignore_RemoteControl_nameChange = false;
			log("added ReportableState to RC: "+newState, "reportState()", Logger.severity.TRACE);
		}
	
		private bool ignore_RemoteControl_nameChange = false;
		private void remoteControl_OnNameChanged(IMyTerminalBlock whichBlock)
		{
			if (!ignore_RemoteControl_nameChange)
			{
				log("name of whichBlock=" + whichBlock.CustomName, "remoteControl_OnNameChanged()", Logger.severity.DEBUG);
				remoteControlIsNotReady = true;
				fullStop();
				CNS.waitUntilNoCheck = DateTime.UtcNow.AddSeconds(1);
			}
		}
	}
}
