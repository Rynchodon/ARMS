﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Sandbox.Common;
using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.Definitions;
using Sandbox.Engine;
using Sandbox.Game;
using Sandbox.ModAPI;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using VRageMath;

namespace AutoPilot
{
	class GridHandler
	{
		private Scripts.KSWH.MyLogger Logger;
		private Sandbox.ModAPI.IMyCubeGrid myGrid;
		private bool needToUpdateRemoteControls;

		private List<Sandbox.ModAPI.IMySlimBlock> remoteControlBlocks;

		private navState myNavState;
		private enum navState
		{
			STOPPING,
			ROTATING,
			MOVING,
			DESTINATION
		}

		public GridHandler(Scripts.KSWH.MyLogger logger, Sandbox.ModAPI.IMyCubeGrid grid)
		{
			Logger = logger;

			myGrid = grid;
//			needToUpdateRemoteControls = true;

			log("handler updating...");
			updateRemoteControls();

			myNavState = navState.STOPPING;

			// register for events
		}

		public void update()
		{
			if (needToUpdateRemoteControls)
				updateRemoteControls();
			else
				navigate();
		}

		private void updateRemoteControls()
		{
			needToUpdateRemoteControls = false;

//			if (!needToUpdate)
//				return;

			//	find remote control blocks
			remoteControlBlocks = new List<Sandbox.ModAPI.IMySlimBlock>();
			MyObjectBuilderType remoteControlType = (new MyObjectBuilder_RemoteControl() as MyObjectBuilder_Base).TypeId;
//			Logger.WriteLine("rCT is "+remoteControlType);
			myGrid.GetBlocks(remoteControlBlocks, block => block.FatBlock != null && block.FatBlock.BlockDefinition.TypeId == remoteControlType);
			log("# of RC blocks is " + remoteControlBlocks.Count);

//			if (remoteControlBlocks.Count > 0)
//				navigate();
		}

		private double needToRotateX;
		private double needToRotateY;
		private double previousX;
		private double previousY;

		private static float speedAdjustment = 100f;
		private static float decelerateAfter = 1f / 2f;

		//	modified from EnemyShip.Update(int count) in Mission 01 by KSWH, id=315628704 on steam
		private void navigate() // TODO: optimize
		{
			Vector3D origin = Vector3D.Zero; //new Vector3D(0,0,0);
			IMyControllableEntity rcBlock = remoteControlBlocks[0].FatBlock as IMyControllableEntity;

			var dir = origin - myGrid.GetPosition();
			if (dir.Length() < 10)
				return;

			var dirNorm = Vector3D.Normalize(dir); // unit vector
			var x = -(rcBlock as IMyEntity).WorldMatrix.Up.Dot(dirNorm); // dot product to get x
			var y = -(rcBlock as IMyEntity).WorldMatrix.Left.Dot(dirNorm); // dot product to get y
//			var forw = (rcBlock as IMyEntity).WorldMatrix.Forward.Dot(dirNorm); // dot product to get z

//			log("rot vector: "+x+", "+y);

//			if (forw < 0)
//				y = 0.2f;

			if (Math.Abs(x) < 0.01f)
				x = 0;
			if (Math.Abs(y) < 0.01f)
				y = 0;

			x *= speedAdjustment;
			y *= speedAdjustment;

			var rot = new Vector2((float)x, (float)y);

			if (rot.LengthSquared() > 0) // need to rotate
			{
				switch (myNavState)
				{
					case navState.MOVING:
						//	TODO: make minor ajustments in-flight
						rcBlock.MoveAndRotateStopped();
						myNavState = navState.STOPPING;
						break;
					case navState.STOPPING:
						if (Math.Abs(previousX - x) < 0.01f && Math.Abs(previousY - y) < 0.01f) // actually stopped
						{
							log("starting rotation: " + x + ", " + y);
							needToRotateX = x;
							needToRotateY = y;
							rcBlock.MoveAndRotate(Vector3D.Zero, rot, 0); // rotate towards target
							myNavState = navState.ROTATING;
						}
						break;
					case navState.ROTATING:
						// check for need to decelerate
						if  ((needToRotateX > 0 && x < needToRotateX * decelerateAfter)
							|| (needToRotateX < 0 && x > needToRotateX * decelerateAfter) 
							|| (needToRotateY > 0 && y < needToRotateY * decelerateAfter) 
							|| (needToRotateY < 0 && y > needToRotateY * decelerateAfter))
						{
							log("need to decelerate rotation ("+x+", "+y+", "+needToRotateX+", "+needToRotateY+")");
							rcBlock.MoveAndRotateStopped();
//							var revRot = new Vector2((float)-needToRotateX, (float)-needToRotateY);
//							rcBlock.MoveAndRotate(Vector3D.Zero, revRot, 0); // stop rotating
							myNavState = navState.STOPPING;
						}
						break;
					default:
//						log("ERROR: invalid state " + myNavState);
						break;
				}
			}
			else
			{
				if (dir.Length() < 10) // at destination
				{
					switch (myNavState)
					{
						case navState.MOVING:
							log("stopping at destination");
							rcBlock.MoveAndRotateStopped();
							myNavState = navState.STOPPING;
							break;
						case navState.STOPPING:
							log("reached destination");
							myNavState = navState.DESTINATION;
							break;
						default:
							break;
					}
				}
//					dir = Vector3D.Zero;
//				else
//					dir = Vector3D.TransformNormal(dir, (rcBlock as IMyEntity).WorldMatrixNormalizedInv);
			}

			previousX = x;
			previousY = y;

/*			if (dir.LengthSquared() > 0 || rot.LengthSquared() > 0)
			{
//				rcBlock.MoveAndRotateStopped();
				rcBlock.MoveAndRotate(dir, rot, 0); // rotate towards target
			}
			else
				rcBlock.MoveAndRotateStopped();

//			Logger.WriteLine("success!, I hope...");*/
		}

		private void OnBlockOwnershipChanged(Sandbox.ModAPI.IMyCubeGrid changedBlock)
		{
			needToUpdateRemoteControls = true;
		}

		private void OnBlockAdded(Sandbox.ModAPI.IMySlimBlock addedBlock)
		{
			needToUpdateRemoteControls = true;
		}

		private void OnBlockRemoved(Sandbox.ModAPI.IMySlimBlock removedBlock)
		{
			needToUpdateRemoteControls = true;
		}

		private void log(string toLog)
		{
			Logger.WriteLine("GH: "+toLog);
		}
	}
}
