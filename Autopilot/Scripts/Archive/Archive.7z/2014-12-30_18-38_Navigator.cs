﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Sandbox.Common;
using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
using Sandbox.Definitions;
using Sandbox.Engine;
using Sandbox.Game;
using Sandbox.ModAPI;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using VRageMath;

namespace Autopilot
{
	public class Navigator
	{
		public Sandbox.ModAPI.IMyCubeGrid myGrid { get; private set; }

		private List<Sandbox.ModAPI.IMySlimBlock> remoteControlBlocks;

		/// <summary>
		/// overrids fetching commands from display name when true
		/// </summary>
		private bool AIOverride;
		/// <summary>
		/// the display name of the current remote control
		/// </summary>
		private string RCDisplayName;

		/// <summary>
		/// current navigation settings
		/// </summary>
		private NavSettings CNS;
		private Collision myCollisionObject;
		private IMyControllableEntity currentRemoteControl_Value;
		private IMyControllableEntity currentRCcontrol
		{
			get { return currentRemoteControl_Value; }
			set
			{
				currentRemoteControl_Value = value;
				if (value == null)
					myCollisionObject = null;
				else
					myCollisionObject = new Collision(currentRemoteControl_Value as Sandbox.ModAPI.IMyCubeBlock);
			}
		}
		private Sandbox.ModAPI.IMyCubeBlock currentRCblock
		{
			get { return currentRCcontrol as Sandbox.ModAPI.IMyCubeBlock; }
			set { currentRCcontrol = value as IMyControllableEntity; }
		}

		internal Navigator(Sandbox.ModAPI.IMyCubeGrid grid)
		{
			myGrid = grid;
		}

		private bool needToInit = true;

		private void init()
		{
			updateBlocks();

			// register for events
			myGrid.OnBlockAdded += OnBlockAdded;
			myGrid.OnBlockOwnershipChanged += OnBlockOwnershipChanged;
			myGrid.OnBlockRemoved += OnBlockRemoved;

			CNS = new NavSettings(this);
			needToInit = false;
		}

		private bool needToUpdateBlocks;
		private static MyObjectBuilderType remoteControlType = (new MyObjectBuilder_RemoteControl() as MyObjectBuilder_Base).TypeId;

		private void updateBlocks()
		{
			needToUpdateBlocks = false;

			//	find remote control blocks
			remoteControlBlocks = new List<Sandbox.ModAPI.IMySlimBlock>();
			myGrid.GetBlocks(remoteControlBlocks, block => block.FatBlock != null && block.FatBlock.BlockDefinition.TypeId == remoteControlType);
		}

		private void OnBlockOwnershipChanged(Sandbox.ModAPI.IMyCubeGrid changedBlock)
		{
			needToUpdateBlocks = true;
		}

		private void OnBlockAdded(Sandbox.ModAPI.IMySlimBlock addedBlock)
		{
			if (addedBlock.FatBlock != null && addedBlock.FatBlock.BlockDefinition.TypeId == remoteControlType)
				needToUpdateBlocks = true;
		}

		private void OnBlockRemoved(Sandbox.ModAPI.IMySlimBlock removedBlock)
		{
			if (removedBlock.FatBlock != null && removedBlock.FatBlock.BlockDefinition.TypeId == remoteControlType)
				needToUpdateBlocks = true;
		}

		private uint updateCount = 0;

		/// <summary>
		/// Causes the ship to fly around, following commands.
		/// Calling more often means more precise movements, calling too often (~ every frame) will break functionality.
		/// </summary>
		// TODO: add a safety to prevent too many calls
		public void update()
		{
			//DateTime startOfUpdate = DateTime.Now;
			updateCount++; // overflow is fine here

			if (!gridCanNavigate())
				return;
			if (needToInit)
				init();
			if (CNS.lockOnTarget != NavSettings.TARGET.OFF)
				tryLockOn();
			if (CNS.waitUntil.CompareTo(DateTime.UtcNow) > 0)
			{
				if (!remoteControlIsReady(currentRCcontrol as Sandbox.ModAPI.IMyCubeBlock)) // if something changes, stop waiting!
					reset();
				return;
			}

			if (CNS.getTypeOfWayDest() != NavSettings.TypeOfWayDest.NULL)
				navigate();
			else // no waypoints
			{
				//log("no waypoints or destination");
				if (CNS.instructions.Count > 0)
				{
					while (true)
					{
						addInstruction(CNS.instructions.Dequeue());
						if (CNS.instructions.Count == 0)
						{
							addInstruction("w1");
							return;
						}
						switch (CNS.getTypeOfWayDest())
						{
							case NavSettings.TypeOfWayDest.BLOCK:
							case NavSettings.TypeOfWayDest.GRID:
								log("got a grid as a destination: " + CNS.getDestGridName());
								return;
							case NavSettings.TypeOfWayDest.COORDINATES:
								log("got a new destination " + CNS.getWayDest());
								return;
							// default keep going
						}
					}
				}
				else
				{
						// find a remote control with CNS.instructions
						//log("searching for a ready remote control");
					foreach (Sandbox.ModAPI.IMySlimBlock remoteControlBlock in remoteControlBlocks)
					{
						Sandbox.ModAPI.IMyCubeBlock fatBlock = remoteControlBlock.FatBlock;
						if (remoteControlIsReady(fatBlock, true))
						{
							if (AIOverride)
							{
								if (currentRCcontrol == null)
									currentRCcontrol = (fatBlock as IMyControllableEntity);
							}
							else
							{
								//log("found a ready remote control");
								//	parse display name
								string displayName = fatBlock.DisplayNameText;
								RCDisplayName = displayName;
								int start = displayName.IndexOf('[') + 1;
								int end = displayName.IndexOf(']');
								if (start > 0 && end > start) // has appropriate brackets
								{
									int length = end - start;
									string noSpaces = displayName.Substring(start, length).Replace(" ", ""); // remove all spaces
									string[] inst = noSpaces.Split(':'); // split into CNS.instructions
									CNS.instructions = new Queue<string>(inst);
									currentRCcontrol = (fatBlock as IMyControllableEntity);
								}
							}
						}
					}
				}
			}

			// will not always reach here
			//TimeSpan toUpdate = DateTime.Now - startOfUpdate;
			//log("\tTTU is "+toUpdate.Milliseconds);
		}

		/// <summary>
		/// stops fetching commands from display name, allows the use of addCommand
		/// </summary>
		/// <param name="remoteControl">which remote control to use; if remoteControl not provided, one will be chosen</param>
		public void modTakeControl(IMyControllableEntity remoteControl = null)
		{
			AIOverride = true;
			reset();
			currentRCcontrol = remoteControl;
		}

		/// <summary>
		/// resume fetching commands from display name, disables addCommand
		/// </summary>
		public void modReleaseControl()
		{
			AIOverride = false;
			reset();
		}

		/// <summary>
		/// Adds a command or a series separated by :
		/// </summary>
		/// <param name="command">command(s) to add</param>
		/// <returns>true iff successful</returns>
		public bool addCommand(string command)
		{
			if (AIOverride == false)
				return false;

			string noSpaces = command.Replace(" ", "");
			string[] inst = noSpaces.Split(':');
			foreach (string instruction in inst)
				CNS.instructions.Enqueue(instruction);

			return true;
		}

		/// <summary>
		/// Adds a string array of commands. Each string may contain multiple commands separated by :
		/// </summary>
		/// <param name="commands">command(s) to add</param>
		/// <returns>true iff successful</returns>
		public bool addCommand(string[] commands)
		{
			if (AIOverride == false)
				return false;

			foreach (string command in commands)
				addCommand(command);

			return true;
		}

		/// <summary>
		/// Adds a command or a series separated by :
		/// </summary>
		/// <param name="command">command(s) to add</param>
		/// <returns>true iff successful</returns>
		public bool addCommand(StringBuilder command)
		{
			if (AIOverride == false)
				return false;

			addCommand(command.ToString());

			return true;
		}

		/// <summary>
		/// adds a single instruction to this handler
		/// </summary>
		/// <param name="instruction">the instruction to add</param>
		private void addInstruction(string instruction)
		{
			//log("entered addInstruction("+instruction+")");

			string lowerCase = instruction.ToLower();
			if (instruction.Length < 2)
				return;
			string data = lowerCase.Substring(1);

			switch (lowerCase[0])
			{
				case 'b': // block, for friendly, search by name. for enemy, search by type
					CNS.tempBlockName = data;
					return;
				case 'c': // coordinates
					{
						string[] coordsString = data.Split(',');
						if (coordsString.Length == 3)
						{
							double[] coordsDouble = new double[3];
							for (int i = 0; i < coordsDouble.Length; i++)
								if (!Double.TryParse(coordsString[i], out coordsDouble[i]))
									return;
							Vector3D destination = new Vector3D(coordsDouble[0], coordsDouble[1], coordsDouble[2]);
							CNS.setDestination(destination);
						}
						return;
					}
				case 'd': // dock, will need a target connector and a local one
					return;
				case 'f': // fly a given distance relative to RC
					{
						string[] coordsString = data.Split(',');
						if (coordsString.Length == 3)
						{
							double[] coordsDouble = new double[3];
							for (int i = 0; i < coordsDouble.Length; i++)
								if (!Double.TryParse(coordsString[i], out coordsDouble[i]))
									return;
							Vector3D destination = new Vector3D(coordsDouble[0], coordsDouble[1], coordsDouble[2]);
							destination = GridWorld.RCtoWorld(currentRCblock, destination);
							CNS.setDestination(destination);
						}
						return;
					}
				case 'g': // grid, closest friendly grid that contains the string
					CNS.destinationBlockName = CNS.tempBlockName;
					CNS.tempBlockName = null;
					Sandbox.ModAPI.IMyCubeBlock closestBlock;
					Sandbox.ModAPI.IMyCubeGrid closestGrid = findCubeGrid(out closestBlock, true, data, CNS.destinationBlockName);
					if (closestGrid != null)
						CNS.setDestination(closestGrid, closestBlock);
					return;
				case 'e': // fly to nearest enemy, set max lock-on, block
				case 'm': // same as e, but will crash into target
					{
						double parsed;
						if (Double.TryParse(data, out parsed))
						{
							if (lowerCase[0] == 'e')
								CNS.lockOnTarget = NavSettings.TARGET.ENEMY;
							else
								CNS.lockOnTarget = NavSettings.TARGET.MISSILE;
							CNS.lockOnRange = (int)parsed;
							CNS.lockOnBlock = CNS.tempBlockName;
							CNS.tempBlockName = null;
						}
						else
						{
							CNS.lockOnTarget = NavSettings.TARGET.OFF;
							CNS.lockOnRange = 0;
							CNS.lockOnBlock = null;
							CNS.tempBlockName = null;
							log("stopped tracking enemies");
						}
						return;
					}
				case 'o': // destination offset, should be cleared after every waypoint, should be relative to destination(not world) if it is a grid, if offset is used on a grid, match orientation
					return;
				case 'p': // how close ship needs to be to destination
					{
						double parsed;
						if (double.TryParse(data, out parsed))
							CNS.destinationRadius = (int)parsed;
						return;
					}
				case 'r': // roll the ship, not sure how to describe roll
					return;
				case 'v': // minimum speed to turn off dampeners
					{
						double parsed;
						if (Double.TryParse(data, out parsed))
							CNS.speedCruise_external = (int)parsed;
						return;
					}
				case 'w': // wait
					double seconds = 0;
					if (Double.TryParse(data, out seconds))
					{
						if (CNS.waitUntil < DateTime.UtcNow)
							CNS.waitUntil = DateTime.UtcNow.AddSeconds(seconds);
						//if (seconds > 1.1)
							//log("setting wait for " + CNS.waitUntil);
					}
					return;
				default:
					return;
			}
		}

		private static DateTime tryLockOnLastGlobal;
		private DateTime tryLockOnLastLocal;
		private static DateTime sanityCheckMin = DateTime.Today.AddDays(-1);

		private void tryLockOn()
		{
			//log("entered tryLockOn");

			if (CNS.lockOnTarget == NavSettings.TARGET.OFF)
				return;

			DateTime now = DateTime.UtcNow;

			if (tryLockOnLastLocal > sanityCheckMin)
			{
				double secondsSinceLocalUpdate = (now - tryLockOnLastLocal).TotalSeconds;
				if (secondsSinceLocalUpdate < 1)
					return;
				double millisecondDelayGlobal = 9000 / secondsSinceLocalUpdate + 100;
				if (now < tryLockOnLastGlobal.AddMilliseconds(millisecondDelayGlobal))
					return;
			}
			else if (tryLockOnLastGlobal > sanityCheckMin && now < tryLockOnLastGlobal.AddMilliseconds(100))
				return;

			//log("trying to lock on");
			tryLockOnLastGlobal = now;
			tryLockOnLastLocal = now;

			Sandbox.ModAPI.IMyCubeBlock closestBlock;
			Sandbox.ModAPI.IMyCubeGrid closestEnemy = findCubeGrid(out closestBlock, false, null, CNS.lockOnBlock, CNS.lockOnRange);
			if (closestEnemy == null)
			{
				//TODO check current target for validity
				//log("no enemy found");
				return;
			}

			// found an enemy, setting as destination
			if (closestBlock != null)
				log("found an enemy: " + closestEnemy.DisplayName + ":" + closestBlock.DisplayNameText);
			else
				log("found an enemy: " + closestEnemy.DisplayName);
			CNS.setDestination(closestEnemy, closestBlock);
			if (CNS.lockOnTarget == NavSettings.TARGET.MISSILE)
				CNS.isAMissile = true;
			CNS.waitUntil = DateTime.UtcNow;
		}

		public static bool looseContains(string bigstring, string substring)
		{
			bigstring = bigstring.ToLower().Replace(" ", "");
			substring = substring.ToLower().Replace(" ", "");

			return bigstring.Contains(substring);
		}

		private static int maxLockOnRangeEnemy = 1100; // only lock-onto enemies closer than this

		private Sandbox.ModAPI.IMyCubeGrid findCubeGrid(out Sandbox.ModAPI.IMyCubeBlock closestBlock, bool friend = true, string nameContains = null, string blockContains = null, double lockOnRangeEnemy = 0)
		{
			//log("entered findCubeGrid: " + friend + ", " + nameContains + ", " + blockContains + ", " + lockOnRangeEnemy);
			if (lockOnRangeEnemy < 1 || maxLockOnRangeEnemy < lockOnRangeEnemy)
				lockOnRangeEnemy = maxLockOnRangeEnemy;

			closestBlock = null;

			Dictionary<double, Sandbox.ModAPI.IMyCubeGrid> nearbyGrids = new Dictionary<double, Sandbox.ModAPI.IMyCubeGrid>();

			HashSet<IMyEntity> entities = new HashSet<IMyEntity>();
			MyAPIGateway.Entities.GetEntities(entities, e => e is Sandbox.ModAPI.IMyCubeGrid);
			foreach (IMyEntity entity in entities)
			{
				Sandbox.ModAPI.IMyCubeGrid grid = entity as Sandbox.ModAPI.IMyCubeGrid;
				if (Core.isHostile(myGrid, grid) == friend)
					continue;
				if (nameContains == null || looseContains(grid.DisplayName, nameContains)) //grid.DisplayName.ToLower().Replace(" ", "").Contains(nameContains))
				{
					double distance = GridWorld.getClosestCorner(getMyPosition(), grid).distance;
					if (friend || distance < lockOnRangeEnemy)
					{
						bool added = false;
						while (!added)
						{
							try
							{
								nearbyGrids.Add(distance, grid);
								added = true;
							}
							catch (ArgumentException) { distance += 0.001; }
						}
					}
				}
			}
			if (nearbyGrids.Count > 0)
				foreach (KeyValuePair<double, Sandbox.ModAPI.IMyCubeGrid> pair in nearbyGrids.OrderBy(i => i.Key))
					if (blockContains == null || findClosestCubeBlockOnGrid(out closestBlock, pair.Value, blockContains, !friend))
						return pair.Value;

			closestBlock = null;
			return null;
		}

		/// <summary>
		/// finds the closest block on a grid that contains the specified string
		/// </summary>
		/// <param name="grid"></param>
		/// <param name="blockContains"></param>
		/// <param name="searchByDefinition"></param>
		/// <returns></returns>
		private bool findClosestCubeBlockOnGrid(out Sandbox.ModAPI.IMyCubeBlock closestBlock, Sandbox.ModAPI.IMyCubeGrid grid, string blockContains, bool searchByDefinition = false) //, bool getAny = false)
		{
			//log("entered findClosestCubeBlockOnGrid: " + grid.DisplayName + ", " + blockContains + ", " + searchByDefinition + ", " + getAny);
			List<Sandbox.ModAPI.IMySlimBlock> allBlocks = new List<Sandbox.ModAPI.IMySlimBlock>();
			closestBlock = null;
			double distanceToClosest = 0;
			grid.GetBlocks(allBlocks);
			foreach (Sandbox.ModAPI.IMySlimBlock blockInGrid in allBlocks)
			{
				if (blockInGrid.FatBlock == null)
					continue;
				Sandbox.ModAPI.IMyCubeBlock fatBlock = blockInGrid.FatBlock;
				string toSearch;
				if (searchByDefinition)
					toSearch = fatBlock.DefinitionDisplayNameText;
				else
					toSearch = fatBlock.DisplayNameText;
				toSearch = toSearch.ToLower();
				if (looseContains(toSearch, blockContains))
				{
					double distance = (fatBlock.GetPosition() - getMyPosition()).Length();
					if (closestBlock == null || distance < distanceToClosest)
					{
						closestBlock = fatBlock;
						distanceToClosest = distance;
					}
				}
			}
			return (closestBlock != null);
		}

		/// <summary>
		/// checks for is a station, is owned by current session's player, grid exists
		/// </summary>
		/// <returns>true iff it is possible for this grid to navigate</returns>
		public bool gridCanNavigate()
		{
			if (myGrid == null)
			{
				log("grid is gone...");
				return false;
			}
			if (myGrid.IsStatic)
				return false;

			if (myGrid.BigOwners.Count > 0)
				return Core.canControl(myGrid.BigOwners[0]);

			return false;
		}

		/// <summary>
		/// checks the functional and working flags, current player owns it, display name has not changed
		/// </summary>
		/// <param name="remoteControl">remote control to check</param>
		/// <returns>true iff the remote control is ready</returns>
		public bool remoteControlIsReady(Sandbox.ModAPI.IMyCubeBlock remoteControl, bool skipNameCheck = false)
		{
			if (remoteControl == null)
			{
				//log("no remote control");
				return false;
			}

			if (!remoteControl.IsFunctional || !remoteControl.IsWorking)
			{
				//log("not functional and working");
				return false;
			}

			if (!Core.canControl(remoteControl.OwnerId))
			{
				//log("cannot control");
				return false;
			}

			if (skipNameCheck || AIOverride)
				return true;
			return (remoteControl.DisplayNameText.Equals(RCDisplayName));
		}

		public bool remoteControlIsReady(IMyControllableEntity remoteControl, bool skipNameCheck = false)
		{
			return remoteControlIsReady(remoteControl as Sandbox.ModAPI.IMyCubeBlock, skipNameCheck);
		}

		/// <summary>
		/// stop the ship, return navigation variables to their defaults, clears current remote control
		/// </summary>
		public void reset()
		{
			log("resetting");
			if (currentRCcontrol != null)
			{
				try
				{
					fullStop();
				}
				catch (NullReferenceException) // when grid is destroyed
				{
					currentRCcontrol.MoveAndRotateStopped();
				}
				//log("clearing current remote control");
				currentRCcontrol = null;
			}
			if (needToUpdateBlocks)
				updateBlocks();
			CNS = new NavSettings(this);
		}

		private double needToRotateX; // from start of rotation
		private double needToRotateY; // from start of rotation
		private double? previousX = null;
		private double? previousY = null;
		//private double moveDistance; // from start of leg to waypoint
		private double distanceToWaypoint; // from current position
		private Vector3D? previousPosition = null;
		private DateTime? previousTime = null;
		double movementSpeed = 0;
		Vector3D currentPos;
		//private double? previousMovementSpeed = null;

		private float rotationPower = 3f;
		private float decelerateRotation = 1f / 2f; // how much of rotation should be deceleration
		//private float decelerateMovement = 1f / 2f; // how much of movement should be deceleration, only used when grid's deceleration is unknown
		private static float decelerateAdjustmentOver = 0.90f; // adjust decelerate by this much when overshoot, must be > 0 and < 1
		private static float decelerateAdjustmentUnder = 0.95f; // adjust decelerate by this much when undershoot, must be > 0 and < 1

		private DateTime maxRotateTime;

		/// <summary>
		/// when true collision avoidance has failed to find a path, stop Navigator
		/// </summary>
		//private bool NO_WAY_FORWARD = false;
		//private DateTime lastCollisionCheck = DateTime.UtcNow;

		// TODO: strafe short distances/manually
		private void navigate()
		{
			Vector3D currentWaypoint = (Vector3D)CNS.getWayDest(); // update() checked for null
			//log("entered navigate(" + currentWaypoint + ")");
			if (!remoteControlIsReady(currentRCcontrol as Sandbox.ModAPI.IMyCubeBlock))
			{
				log("remote control is not ready");
				reset();
				return;
			}

			//log("cRC pos: "+(currentRemoteControl as IMyEntity).GetPosition());
			Vector3D displacement = currentWaypoint - getMyPosition();// (currentRemoteControl as IMyEntity).GetPosition();
			//log("displacement vector: "+displacement);

			Vector3D dirNorm = Vector3D.Normalize(displacement);
			double x = (currentRCcontrol as IMyEntity).WorldMatrix.Down.Dot(dirNorm);
			double y = (currentRCcontrol as IMyEntity).WorldMatrix.Right.Dot(dirNorm);
			double forw = (currentRCcontrol as IMyEntity).WorldMatrix.Forward.Dot(dirNorm);
			// x and y now represent how far the ship needs to turn to be facing in the correct direction (0,0) means facing the right way

			//log("movement: "+x+", "+y+", "+forw);

			if (forw < 0) // destination is behind myGrid
			{
				if (y > 0)
					y = 1;
				else
					y = -1;
			}

			x *= rotationPower;
			y *= rotationPower;

			distanceToWaypoint = displacement.Length();

			// calculate speed & acceleration
			currentPos = getMyPosition();
			DateTime currentTime = DateTime.UtcNow;
			//double movementSpeed = 0;

			if (previousPosition != null && previousTime != null)
			{
				double elapsedTime = ((TimeSpan)(currentTime - previousTime)).TotalSeconds;
				//log("calculating time " + elapsedTime + " = " + currentTime + " - " + previousTime);
				if (elapsedTime >= 0.1)
				{
					double distanceTraveled = (currentPos - (Vector3D)previousPosition).Length();
					if (distanceTraveled > 0.1)
						movementSpeed = distanceTraveled / elapsedTime;
					else
						movementSpeed = 0;
					//log("setting speed "+movementSpeed+" = "+distanceTraveled+" / "+elapsedTime);
					previousPosition = currentPos;
					previousTime = currentTime;
				}
			}
			else
			{
				previousPosition = currentPos;
				previousTime = currentTime;
			}

			if (CNS.moveState == NavSettings.Moving.NOT_MOVING && startOfDecelMeasureVec != null)
			{
				double distanceTraveled = (currentPos - (Vector3D)startOfDecelMeasureVec).Length();
				if (distanceTraveled > 1)
				{
					if (decelMeasureCoefficient < 0.1)
						decelMeasureCoefficient = distanceTraveled / startOfDecelMeasureSpeed;
					else
						decelMeasureCoefficient = 0.9 * decelMeasureCoefficient + 0.1 * distanceTraveled / startOfDecelMeasureSpeed;
					//log("got a measurement for deceleration: " + distanceTraveled + " / " + startOfDecelMeasureSpeed + ", " + CNS.decelMeasureCoefficient);
				}
				startOfDecelMeasureSpeed = 0;
				startOfDecelMeasureVec = null;
			}

			if (distanceToWaypoint < CNS.destinationRadius && !CNS.isAMissile) // at destination
			{
				if (CNS.getTypeOfWayDest()== NavSettings.TypeOfWayDest.WAYPOINT){
					CNS.atWayDest();
					if (CNS.getTypeOfWayDest() == NavSettings.TypeOfWayDest.NULL)
					{
						log("Error no more destinations at Navigator.navigate() // at destination");
						fullStop();
					}
					else
					{
						log("reached waypoint, next type is " + CNS.getTypeOfWayDest() + ", coords: " + CNS.getWayDest());
						fullStop();
					}
				}
				else if (CNS.moveState == NavSettings.Moving.NOT_MOVING)
				{
					log("reached destination");
					fullStop();
					CNS.atWayDest();
					//CNS.curNavState = NavSettings.State.DESTINATION;
				}
				else if (CNS.moveState != NavSettings.Moving.STOPPING_M)
				{
					log("stopping at destination");
					fullStop();
					CNS.moveState = NavSettings.Moving.STOPPING_M;
				}
			}
			else // not at destination
			{
				if (!CNS.isAMissile)// && CNS.collAtDest == NavSettings.COL_DEST.NOT_AT)
				{
					//if (!CNS.isAMissile	&& (CNS.curNavState == NavSettings.State.MOVING || CNS.inflightAdjustment ))
					//&& (DateTime.UtcNow - lastCollisionCheck).TotalMilliseconds > 100)
					//{
					//log("CNS.destinationRadius=" + CNS.destinationRadius + ", movementSpeed=" + movementSpeed + ", stoppingDistance=" + getStoppingDistance(movementSpeed));
					Collision.collisionAvoidResult currentAvoidResult = myCollisionObject.avoidCollisions(ref CNS, (int)(CNS.destinationRadius + 3 * getStoppingDistance(movementSpeed)), updateCount);
					//collisionAvoidResult currentAvoidResult = collisionAvoidance(2*getStoppingDistance(movementSpeed));
					//log("got a currentAvoidResult "+currentAvoidResult);
					//lastCollisionCheck = DateTime.UtcNow;
					switch (currentAvoidResult)
					{
						case Collision.collisionAvoidResult.NOT_FINISHED:
							break;
						//case Collision.collisionAvoidResult.AT_DEST_GRID:
							//CNS.collAtDest = NavSettings.COL_DEST.AT_DEST;
							//log("collAtDest, setting speed limit");
							//break;
						case Collision.collisionAvoidResult.ALTERNATE_PATH:
							//CNS.curNavState = NavSettings.State.DEMOVE;
							fullStop();
							break;
						case Collision.collisionAvoidResult.NO_WAY_FORWARD:
							//log("NO WAY FORWARD");
							CNS.noWayForward = true;
							fullStop();
							break;
						case Collision.collisionAvoidResult.NO_OBSTRUCTION:
							simpleMoveOrRotate(x, y, movementSpeed);
							break;
						default:
							log("Error: unsuitable case from avoidCollisions(): " + currentAvoidResult);
							fullStop();
							break;
					}
				}
				else
					simpleMoveOrRotate(x, y, movementSpeed);
			}

			if (isStopped(x, y, movementSpeed))
			{
				if (CNS.moveState == NavSettings.Moving.STOPPING_M)
					//log("now stopped");
					CNS.moveState = NavSettings.Moving.NOT_MOVING;
				else if (CNS.moveState == NavSettings.Moving.MOVING)
					CNS.moveState = NavSettings.Moving.STOPPING_M;
			}

			previousX = x;
			previousY = y;
			//			previousMovementSpeed = movementSpeed;
		}

		private static Vector3 cruiseForward = new Vector3(0,0,-0.001); // hopefully this minimum is consistent
		private bool isCruising = false;
		private bool changeRotationPower;

		private void simpleMoveOrRotate(double x, double y, double? movementSpeed)
		{
			//log("entered simpleMoveOrRotate("+x+", "+y+", "+movementSpeed+", "+currentPos+")");

			if (CNS.noWayForward)
				return;
			//if (CNS.curNavState == NavSettings.State.STOPPING)
				//return;

			Vector2 rot = new Vector2((float)x, (float)y);
			double stoppingDistance = getStoppingDistance(movementSpeed);

			if (!CNS.isAMissile && CNS.moveState == NavSettings.Moving.MOVING )
			{
				switch (CNS.getTypeOfWayDest())
				{
					case NavSettings.TypeOfWayDest.BLOCK:
					case NavSettings.TypeOfWayDest.GRID:
						// TODO need to calculate distance between myGrid and closest point of destGrid, collision is too expensive for this purpose
					case NavSettings.TypeOfWayDest.COORDINATES:
						if (distanceToWaypoint < 5 * stoppingDistance)
						{
							//log("on aproach, setting speed limit=" + (int)(movementSpeed * 0.9));
							CNS.speedSlow_internal = (int)(movementSpeed * 0.9);
							CNS.speedCruise_internal = 1;
						}
						break;
				}
				if (movementSpeed > CNS.getSpeedCruise())
				{
					if (movementSpeed > CNS.getSpeedSlow())
					{
						if (currentMove != Vector3.Zero)
						{
							move(Vector3.Zero);
							log("moving too fast " + movementSpeed + " > " + CNS.getSpeedSlow());
						}
					}
					else if (!isCruising)
					{
						// cruise
						move(cruiseForward);
						isCruising = true;
					}
				}
			}

			float rotLengthSq = -1;
			if (CNS.moveState == NavSettings.Moving.NOT_MOVING && CNS.rotateState == NavSettings.Rotating.NOT_ROTATING)
			{
				float rotationPrecision;
				/*if (CNS.curNavState == NavSettings.State.MOVING)
					rotationPrecision = 0.5f;
				else*/
				if (CNS.isAMissile)
					// for missile, speed is more important
					rotationPrecision = 4f;
				else
					rotationPrecision = 2f;
				rotLengthSq = Math.Abs(rot.LengthSquared());
				if (rotLengthSq < rotationPrecision)
				{
					move(Vector3.Forward); // move forward
					//currentRCcontrol.MoveAndRotate(Vector3D.Forward, Vector2.Zero, 0); // move
					//moveDistance = distanceToWaypoint;
					log("moving " + distanceToWaypoint);
					CNS.moveState = NavSettings.Moving.MOVING;
					return;
				}
			}

			//log("need to rotate "+rot.Length());
			// need to rotate
			switch (CNS.rotateState)
			{
				case NavSettings.Rotating.NOT_ROTATING:
					switch (CNS.moveState)
					{
						case NavSettings.Moving.MOVING:
							{
								if (rotLengthSq < 0)
									rotLengthSq = Math.Abs(rot.LengthSquared());
								if (rotLengthSq < 0.1)
									return;
								if (rotLengthSq > 25f)
								{
									log("stopping to rotate");
									fullStop();
									return;
								}
								else
								//if (CNS.curNavState != NavSettings.State.STOPPED)
								{// make a small, inflight adjustment
									log("need to adjust: " + x + ", " + y);
									needToRotateX = x;
									needToRotateY = y;
									changeRotationPower = true;
									rotate(rot); // rotate towards target
									//currentRCcontrol.MoveAndRotate(Vector3D.Forward, rot, 0); // rotate towards target
									CNS.rotateState = NavSettings.Rotating.ROTATING;
									maxRotateTime = DateTime.UtcNow.AddSeconds(3);
									return;
								}
							}
						case NavSettings.Moving.NOT_MOVING:
							{
								log("starting rotation: " + x + ", " + y);
								needToRotateX = x;
								needToRotateY = y;
								changeRotationPower = true;
								rotate(rot); // rotate towards target
								//currentRCcontrol.MoveAndRotate(Vector3D.Zero, rot, 0); // rotate towards target
								CNS.rotateState = NavSettings.Rotating.ROTATING;
								maxRotateTime = DateTime.UtcNow.AddSeconds(10);
								return;
							}
					}
					return;
				case NavSettings.Rotating.STOPPING_R:
					{
						if (isNotRotating())
						{
							int overUnder = 0;
							//	check for overshoot/undershoot
							if (Math.Abs(x) > 0.1 && Math.Abs(needToRotateX) > 0.1)
								if ((x > 0 && needToRotateX > 0) || (x < 0 && needToRotateX < 0))
									overUnder--;
								else
									overUnder++;
							if (Math.Abs(y) > 0.1 && Math.Abs(needToRotateY) > 0.1)
								// assume (needToRotateY != 0)
								if ((y > 0 && needToRotateY > 0) || (y < 0 && needToRotateY < 0))
									overUnder--;
								else
									overUnder++;
							needToRotateX = 0;
							needToRotateY = 0;

							if (overUnder != 0)
							{
								if (changeRotationPower)
								{
									if (overUnder > 0)
										rotationPower /= decelerateAdjustmentOver;
									else
										rotationPower *= decelerateAdjustmentUnder;
									log("adjusted rotPower, new value is " + rotationPower);
								}
								else
								{
									if (overUnder > 0)
										decelerateRotation /= decelerateAdjustmentOver;
									else
										decelerateRotation *= decelerateAdjustmentUnder;
									log("adjusted derotate, new value is " + decelerateRotation);
								}
							}
							CNS.rotateState = NavSettings.Rotating.NOT_ROTATING;
						}
						return;
					}
				case NavSettings.Rotating.ROTATING:
					{
						// check for need to derotate
						//						log("checking rotation (" + x + ", " + y + ", " + needToRotateX + ", " + needToRotateY + ")");
						if ((needToRotateX > 0.1 && x < needToRotateX * decelerateRotation)
							|| (needToRotateX < -0.1 && x > needToRotateX * decelerateRotation)
							|| (needToRotateY > 0.1 && y < needToRotateY * decelerateRotation)
							|| (needToRotateY < -0.1 && y > needToRotateY * decelerateRotation)
							|| DateTime.UtcNow >= maxRotateTime)
						{
							log("decelerate rotation (" + x + ", " + y + ", " + needToRotateX + ", " + needToRotateY + ")");
							rotate(Vector2.Zero); // stop rotating
							CNS.rotateState = NavSettings.Rotating.STOPPING_R;
							/*if (CNS.inflightAdjustment)
							{
								//currentRCcontrol.MoveAndRotate(Vector3D.Forward, Vector2.Zero, 0);
								CNS.curNavState = NavSettings.State.MOVING;
								CNS.inflightAdjustment = false;
								//log("stopping inflight adjustment (DEROTATE) "+x+", "+y);
							}
							else
							{
								CNS.curNavState = NavSettings.State.DEROTATE;
								//fullStop();
							}*/
						}
						return;
					}
			}
			//}
			//else // no need to rotate
			//{
				/*if (CNS.curNavState == NavSettings.State.ROTATING)// || CNS.curNavState == NavSettings.State.DEROTATE)
				{
					//log("stopping rotation "+rot.Length()+" of "+rotationPrecision);
					rotate(Vector2.Zero); // stop rotating
					if (CNS.inflightAdjustment)
					{
						//currentRCcontrol.MoveAndRotate(Vector3D.Forward, Vector2.Zero, 0);
						CNS.curNavState = NavSettings.State.MOVING;
						CNS.inflightAdjustment = false;
						//log("stopping inflight adjustment (STOP) " + x + ", " + y);
					}
					else
					{
						CNS.curNavState = NavSettings.State.DEROTATE;
						//fullStop();
					}
				}
				else // need to move*/
					//					log("need to move");
					
			//}
		}

		private  static TimeSpan stoppedAfter = new TimeSpan(0,0,3);
		private DateTime stoppedMovingAt;

		private bool isStopped(double? x, double? y, double? speed)
		{
			bool currentlyMoving = false;

			if (speed == null)
				currentlyMoving = true;
			if (Math.Abs((double)(previousX - x)) > 0.01f)
				currentlyMoving = true;
			if (Math.Abs((double)(previousY - y)) > 0.01f)
				currentlyMoving = true;

			if (speed > 0.1f)
				currentlyMoving = true;

			if (currentlyMoving)
			{
				stoppedMovingAt = DateTime.UtcNow + stoppedAfter;
				return false;
			}
			else
				return DateTime.UtcNow > stoppedMovingAt;
		}

		private DateTime stoppedRotatingAt;
		/// <summary>
		/// this is based on ship forward
		/// </summary>
		private Vector3D? facing = null;

		private bool isNotRotating()
		{
			Vector3D origin = myGrid.GetPosition();
			Vector3D forward = myGrid.GridIntegerToWorld(Vector3I.Forward);
			Vector3D currentFace = forward - origin;
			
			bool currentlyRotating;
			if (facing == null)
				currentlyRotating = true;
			else
			{
				Vector3D prevFace = (Vector3D)facing;
				if (Math.Abs(currentFace.X - prevFace.X) > 0.1 || Math.Abs(currentFace.Y - prevFace.Y) > 0.1 || Math.Abs(currentFace.Z - prevFace.Z) > 0.1)
				{
					currentlyRotating = true;
					log("rotating, x=" + Math.Abs(currentFace.X - prevFace.X) + ", y=" + Math.Abs(currentFace.Y - prevFace.Y) + ", z=" + Math.Abs(currentFace.Z - prevFace.Z) + ", S.A.=" + stoppedRotatingAt);
				}
				else
				{
					currentlyRotating = false;
					//log("not rotating, x=" + Math.Abs(currentFace.X - prevFace.X) + ", y=" + Math.Abs(currentFace.Y - prevFace.Y) + ", z=" + Math.Abs(currentFace.Z - prevFace.Z) + ", S.A.=" + stoppedRotatingAt);
				}
			}
			facing = currentFace;

			if (currentlyRotating)
			{
				//log("rotating");
				stoppedRotatingAt = DateTime.UtcNow + stoppedAfter;
				return false;
			}
			else
				return DateTime.UtcNow > stoppedRotatingAt;
		}

		private double startOfDecelMeasureSpeed = 0;
		private Vector3D? startOfDecelMeasureVec = null;

		// no longer necisary, use cruiseForward
		/*private void setDampeners(bool dampenersOn = true)
		{
			if ((myGrid.GetObjectBuilder() as MyObjectBuilder_CubeGrid).DampenersEnabled != dampenersOn)
			{
				currentRCcontrol.SwitchDamping();
				if (!dampenersOn)
					log("disabling dampeners. speed=" + movementSpeed + ", cruise=" + CNS.getSpeedCruise() + ", slow=" + CNS.getSpeedSlow());
				else
					log("enabling dampeners. speed=" + movementSpeed + ", cruise=" + CNS.getSpeedCruise() + ", slow=" + CNS.getSpeedSlow());
			}
		}*/

		/*private void partialStop()
		{
			//setDampeners();
			log("doing stop");
			currentMove = Vector3.Zero;
			currentRotate = Vector2.Zero;
			currentRoll = 0;
			currentRCcontrol.MoveAndRotateStopped();
		}*/

		/// <summary>
		/// temporaily switches off cruising, may be reactivated
		/// </summary>
		private void disableCruise()
		{
			CNS.speedCruise_internal = int.MaxValue;
			CNS.speedSlow_internal = int.MaxValue;
			isCruising = false;
		}

		/// <summary>
		/// for other kinds of stop use move(Vector3.Zero) or similar
		/// </summary>
		private void fullStop()
		{
			log("full stop");
			currentMove = Vector3.Zero;
			currentRotate = Vector2.Zero;
			currentRoll = 0;
			disableCruise();

			currentRCcontrol.MoveAndRotateStopped();

			//CNS.inflightAdjustment = false;
			if (movementSpeed > 1 && CNS.moveState == NavSettings.Moving.MOVING)
			{
				//CNS.moveState = NavSettings.Moving.STOPING_M;
				startOfDecelMeasureSpeed = (double)movementSpeed;
				startOfDecelMeasureVec = currentPos;
			}
			CNS.moveState = NavSettings.Moving.STOPPING_M;
			CNS.rotateState = NavSettings.Rotating.STOPPING_R;
			needToRotateX = 0;
			needToRotateY = 0;
			//else
				//CNS.curNavState = NavSettings.State.STOPPING;
		}

		private Vector3 currentMove = Vector3.Zero;
		private Vector2 currentRotate = Vector2.Zero;
		private float currentRoll = 0;

		private void move(Vector3 move)
		{
			//log("entered move("+move+")");
			currentMove = move;
			moveAndRotate();
		}

		private void rotate(Vector2 rotate)
		{
			//log("entered rotate("+rotate+")");
			currentRotate = rotate;
			moveAndRotate();
		}

		private void roll(float roll)
		{
			//log("entered roll("+roll+")");
			currentRoll = roll;
			moveAndRotate();
		}

		private void moveAndRotate()
		{
			//isCruising = false;
			if (currentMove == Vector3.Zero && currentRotate == Vector2.Zero && currentRoll == 0)
			{
				log("MAR is actually stop");
				currentRCcontrol.MoveAndRotateStopped();
			}
			else
			{
				log("doing MAR(" + currentMove + ", " + currentRotate + ", " + currentRoll + ")");
				currentRCcontrol.MoveAndRotate(currentMove, currentRotate, currentRoll);
			}
		}

		private static double decelMeasureCoefficient = 1f;

		private double getStoppingDistance(double? speed)
		{
			//if (CNS.decelMeasureCoefficient >= 0.1)
				return decelMeasureCoefficient * (double)speed;
			//else
				//return moveDistance * decelerateMovement;
		}

		private void log(string toLog)
		{
			if (!MyLogger.enabled)
				return;
			StringBuilder sbLog = new StringBuilder(30);
			sbLog.Append(CNS.moveState);
			sbLog.Append(":");
			sbLog.Append(CNS.rotateState);
			sbLog.Append(":");
			sbLog.Append(toLog);
			MyLogger.log(myGrid.DisplayName, "GH", sbLog.ToString());
		}

		public override string ToString()
		{
			return "Nav:"+myGrid.DisplayName;
		}

		public Vector3D getMyPosition()
		{
			if (currentRCcontrol == null)
				return myGrid.GetPosition();
			else
				return (currentRCcontrol as Sandbox.ModAPI.IMyCubeBlock).GetPosition();
		}
	}
}
