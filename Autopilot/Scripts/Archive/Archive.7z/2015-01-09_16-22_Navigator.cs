﻿#define LOG_ENABLED //remove on build

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//using Sandbox.Common;
//using Sandbox.Common.Components;
using Sandbox.Common.ObjectBuilders;
//using Sandbox.Definitions;
//using Sandbox.Engine;
//using Sandbox.Game;
using Sandbox.ModAPI;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using VRageMath;

using Rynchodon.Autopilot.Pathfinder;

namespace Rynchodon.Autopilot
{
	internal class Navigator
	{
		private Logger myLogger = null;
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			myLogger.log(level, method, toLog, CNS.moveState.ToString(), CNS.rotateState.ToString());
		}

		public Sandbox.ModAPI.IMyCubeGrid myGrid { get; private set; }

		private List<Sandbox.ModAPI.IMySlimBlock> remoteControlBlocks;

		/// <summary>
		/// overrids fetching commands from display name when true
		/// </summary>
		public bool AIOverride = false;

		/// <summary>
		/// current navigation settings
		/// </summary>
		internal NavSettings CNS;
		private Collision myCollisionObject;
		private GridDimensions myGridDim;

		private IMyControllableEntity currentRemoteControl_Value;
		public IMyControllableEntity currentRCcontrol
		{
			get { return currentRemoteControl_Value; }
			set
			{
				//log("setting new RC ", "currentRCcontrol.set", Logger.severity.TRACE);
				if (currentRemoteControl_Value == value)
				{
					//log("currentRemoteControl_Value == value", "currentRCcontrol.set", Logger.severity.TRACE);
					return;
				}

				if (currentRemoteControl_Value != null)
				{
					// actions on old RC
					(currentRemoteControl_Value as Sandbox.ModAPI.IMyTerminalBlock).CustomNameChanged -= remoteControl_OnNameChanged;
					reportState(ReportableState.OFF);
				}

				currentRemoteControl_Value = value;
				if (currentRemoteControl_Value == null)
				{
					myGridDim = null;
					myCollisionObject = null;
					CNS = new NavSettings(null);
				}
				else
				{
					myGridDim = new GridDimensions(currentRCblock);
					myCollisionObject = new Collision(myGridDim); //(currentRCblock, out distance_from_RC_to_front);
					CNS = new NavSettings(myGridDim);
				}

				if (currentRemoteControl_Value != null)
				{
					// actions on new RC
					(currentRemoteControl_Value as Sandbox.ModAPI.IMyTerminalBlock).CustomNameChanged += remoteControl_OnNameChanged;
					reportState(ReportableState.OFF);
				}

				// some variables
				rotationPower = 3f;
				decelerateRotation = 1f / 2f;
				inflightRotatingPower = 3f;
				inflightDecelerateRotation = 1f / 2f;
			}
		}
		public Sandbox.ModAPI.IMyCubeBlock currentRCblock
		{
			get { return currentRemoteControl_Value as Sandbox.ModAPI.IMyCubeBlock; }
			set { currentRCcontrol = value as IMyControllableEntity; }
		}

		internal Navigator(Sandbox.ModAPI.IMyCubeGrid grid)
		{
			myGrid = grid;
			myLogger = new Logger(myGrid.DisplayName, "Navigator");
		}

		private bool needToInit = true;

		private void init()
		{
			updateBlocks();

			// register for events
			myGrid.OnBlockAdded += OnBlockAdded;
			myGrid.OnBlockOwnershipChanged += OnBlockOwnershipChanged;
			myGrid.OnBlockRemoved += OnBlockRemoved;

			CNS = new NavSettings(null);
			needToInit = false;
		}

		private bool needToUpdateBlocks;
		private static MyObjectBuilderType remoteControlType = (new MyObjectBuilder_RemoteControl() as MyObjectBuilder_Base).TypeId;

		private void updateBlocks()
		{
			needToUpdateBlocks = false;

			//	find remote control blocks
			remoteControlBlocks = new List<Sandbox.ModAPI.IMySlimBlock>();
			myGrid.GetBlocks(remoteControlBlocks, block => block.FatBlock != null && block.FatBlock.BlockDefinition.TypeId == remoteControlType);
		}

		private void OnBlockOwnershipChanged(Sandbox.ModAPI.IMyCubeGrid changedBlock)
		{
			needToUpdateBlocks = true;
		}

		private void OnBlockAdded(Sandbox.ModAPI.IMySlimBlock addedBlock)
		{
			if (addedBlock.FatBlock != null && addedBlock.FatBlock.BlockDefinition.TypeId == remoteControlType)
				needToUpdateBlocks = true;
		}

		private void OnBlockRemoved(Sandbox.ModAPI.IMySlimBlock removedBlock)
		{
			if (removedBlock.FatBlock != null && removedBlock.FatBlock.BlockDefinition.TypeId == remoteControlType)
				needToUpdateBlocks = true;
		}

		private long updateCount = 0;

		/// <summary>
		/// Causes the ship to fly around, following commands.
		/// Calling more often means more precise movements, calling too often (~ every update) will break functionality.
		/// </summary>
		public void update()
		{
			updateCount++;
			if (!gridCanNavigate())
				return;
			if (needToInit)
				init();
			if (CNS.lockOnTarget != NavSettings.TARGET.OFF)
				tryLockOn();
			if (CNS.waitUntilNoCheck.CompareTo(DateTime.UtcNow) > 0)
				return;
			if (CNS.waitUntil.CompareTo(DateTime.UtcNow) > 0 || CNS.EXIT)
			{
				if (!remoteControlIsReady(currentRCcontrol as Sandbox.ModAPI.IMyCubeBlock)) // if something changes, stop waiting!
				{
					log("wait interrupted", "update()", Logger.severity.DEBUG);
					reset();
				}
				return;
			}

			if (CNS.getTypeOfWayDest() != NavSettings.TypeOfWayDest.NULL)
				navigate();
			else // no waypoints
			{
				//log("no waypoints or destination");
				if (CNS.instructions.Count > 0)
				{
					while (CNS.instructions.Count > 0)
					{
						addInstruction(CNS.instructions.Dequeue());
						switch (CNS.getTypeOfWayDest())
						{
							case NavSettings.TypeOfWayDest.BLOCK:
								log("got a block as a destination: " + CNS.getDestGridName()+":"+CNS.destinationBlockName);
								reportState(ReportableState.PATHFINDING);
								return;
							case NavSettings.TypeOfWayDest.OFFSET:
								log("got an offset as a destination: " + CNS.getDestGridName()+":"+CNS.destinationBlockName+":"+CNS.destination_offset);
								reportState(ReportableState.PATHFINDING);
								return;
							case NavSettings.TypeOfWayDest.GRID:
								log("got a grid as a destination: " + CNS.getDestGridName());
								reportState(ReportableState.PATHFINDING);
								return;
							case NavSettings.TypeOfWayDest.COORDINATES:
								log("got a new destination " + CNS.getWayDest());
								reportState(ReportableState.PATHFINDING);
								return;
							// default keep going
						}
					}
					// at end of instructions
					CNS.endOfCommands();
					CNS.waitUntilNoCheck = DateTime.UtcNow.AddSeconds(1);
					return;
				}
				else
				{
					// find a remote control with CNS.instructions
					reportState(ReportableState.NO_DEST);
					//log("searching for a ready remote control", "update()", Logger.severity.TRACE);
					CNS.waitUntilNoCheck = DateTime.UtcNow.AddSeconds(1);
					foreach (Sandbox.ModAPI.IMySlimBlock remoteControlBlock in remoteControlBlocks)
					{
						Sandbox.ModAPI.IMyCubeBlock fatBlock = remoteControlBlock.FatBlock;
						if (remoteControlIsReady(fatBlock))
						{
							if (AIOverride)
							{
								if (currentRCcontrol == null)
									currentRCcontrol = (fatBlock as IMyControllableEntity);
							}
							else
							{
								//	parse display name
								string instructions = getInstructionsFromRC(fatBlock);
								if (instructions != null)
								{
									log("found a ready remote control " + fatBlock.DisplayNameText, "update()", Logger.severity.TRACE);
									string noSpaces = instructions.Replace(" ", ""); // remove all spaces
									string[] inst = noSpaces.Split(':'); // split into CNS.instructions
									CNS.instructions = new Queue<string>(inst);
									currentRCcontrol = (fatBlock as IMyControllableEntity);
									log("finished queuing instructions(" + CNS.instructions.Count + ")", "update()", Logger.severity.TRACE);
									return;
								}
							}
						}
					}
				}
			}
		}

		/// <summary>
		/// adds a single instruction to this handler
		/// </summary>
		/// <param name="instruction">the instruction to add</param>
		private void addInstruction(string instruction)
		{
			log("entered addInstruction(" + instruction + ")", "addInstruction()", Logger.severity.TRACE);

			if (instruction.Length < 2)
				return;

			string lowerCase = instruction.ToLower();
			string data = lowerCase.Substring(1);

			if (looseContains(instruction, "EXIT"))
			{
				CNS.EXIT = true;
				return;
			}

			switch (lowerCase[0])
			{
				case 'b': // block: for friendly, search by name. for enemy, search by type
					CNS.tempBlockName = data;
					return;
				case 'c': // coordinates
					{
						string[] coordsString = data.Split(',');
						if (coordsString.Length == 3)
						{
							double[] coordsDouble = new double[3];
							for (int i = 0; i < coordsDouble.Length; i++)
								if (!Double.TryParse(coordsString[i], out coordsDouble[i]))
									return;
							Vector3D destination = new Vector3D(coordsDouble[0], coordsDouble[1], coordsDouble[2]);
							CNS.setDestination(destination);
						}
						return;
					}
				case 'd': // dock: will need a target connector and a local one
					return;
				case 'f': // fly a given distance relative to RC
					{
						string[] coordsString = data.Split(',');
						if (coordsString.Length == 3)
						{
							double[] coordsDouble = new double[3];
							for (int i = 0; i < coordsDouble.Length; i++)
								if (!Double.TryParse(coordsString[i], out coordsDouble[i]))
									return;
							Vector3D destination = new Vector3D(coordsDouble[0], coordsDouble[1], coordsDouble[2]);
							destination = GridWorld.RCtoWorld(currentRCblock, destination);
							CNS.setDestination(destination);
						}
						return;
					}
				case 'g': // grid: closest friendly grid that contains the string
					CNS.destinationBlockName = CNS.tempBlockName;
					CNS.tempBlockName = null;
					Sandbox.ModAPI.IMyCubeBlock closestBlock;
					Sandbox.ModAPI.IMyCubeGrid closestGrid = findCubeGrid(out closestBlock, true, data, CNS.destinationBlockName);
					if (closestGrid != null)
						CNS.setDestination(closestBlock, closestGrid);
					return;
				case 'e': // fly to nearest enemy, set max lock-on, block
				case 'm': // same as e, but will crash into target
					{
						double parsed;
						if (Double.TryParse(data, out parsed))
						{
							if (lowerCase[0] == 'e')
								CNS.lockOnTarget = NavSettings.TARGET.ENEMY;
							else
								CNS.lockOnTarget = NavSettings.TARGET.MISSILE;
							CNS.lockOnRange = (int)parsed;
							CNS.lockOnBlock = CNS.tempBlockName;
							CNS.tempBlockName = null;
						}
						else
						{
							CNS.lockOnTarget = NavSettings.TARGET.OFF;
							CNS.lockOnRange = 0;
							CNS.lockOnBlock = null;
							CNS.tempBlockName = null;
							log("stopped tracking enemies");
						}
						return;
					}
				case 'o': // destination offset, should be cleared after every waypoint, if offset is used on a grid, match orientation
					{
						string[] coordsString = data.Split(',');
						if (coordsString.Length == 3)
						{
							double[] coordsDouble = new double[3];
							for (int i = 0; i < coordsDouble.Length; i++)
								if (!Double.TryParse(coordsString[i], out coordsDouble[i]))
									return;
							CNS.destination_offset = new Vector3I((int)coordsDouble[0], (int)coordsDouble[1], (int)coordsDouble[2]);
							log("setting offset to " + CNS.destination_offset+", AFTER swtiching right and up", "addInstruction()", Logger.severity.DEBUG);
						}
						return;
					}
				case 'p': // how close ship needs to be to destination
					{
						double parsed;
						if (double.TryParse(data, out parsed))
							CNS.destinationRadius = (int)parsed;
						return;
					}
				case 'r': // match orientation
					{
						CNS.match_direction = null;
						CNS.match_roll = null;
						string[] orientation = data.Split(',');
						if (orientation.Length == 0 || orientation.Length > 2)
							return;
						Base6Directions.Direction? dir = stringToDirection(orientation[0]);
						//log("got dir "+dir);
						if (dir == null)
							return;
						CNS.match_direction = (Base6Directions.Direction)dir;

						if (orientation.Length == 1)
							return;
						Base6Directions.Direction? roll = stringToDirection(orientation[1]);
						//log("got roll " + roll);
						if (roll == null)
							return;
						CNS.match_roll = (Base6Directions.Direction)roll;

						return;
					}
				case 'v': // speed limits
					{
						string[] speeds = data.Split(',');
						if (speeds.Length == 2)
						{
							double[] parsedArray = new double[2];
							for (int i = 0; i < parsedArray.Length; i++)
							{
								if (!Double.TryParse(speeds[i], out parsedArray[i]))
									return;
							}
							CNS.speedCruise_external = (int)parsedArray[0];
							CNS.speedSlow_external = (int)parsedArray[1];
						}
						else
						{
							double parsed;
							if (Double.TryParse(data, out parsed))
								CNS.speedCruise_external = (int)parsed;
							return;
						}
						return;
					}
				case 'w': // wait
					double seconds = 0;
					if (Double.TryParse(data, out seconds))
					{
						if (CNS.waitUntil < DateTime.UtcNow)
							CNS.waitUntil = DateTime.UtcNow.AddSeconds(seconds);
						//if (seconds > 1.1)
						//log("setting wait for " + CNS.waitUntil);
					}
					return;
			}
			log("failed to parse" + instruction, "addInstruction", Logger.severity.TRACE);
		}

		private Base6Directions.Direction? stringToDirection(string str)
		{
			switch (str[0])
			{
				case 'f':
					return Base6Directions.Direction.Forward;
				case 'b':
					return Base6Directions.Direction.Backward;
				case 'l':
					return Base6Directions.Direction.Left;
				case 'r':
					return Base6Directions.Direction.Right;
				case 'u':
					return Base6Directions.Direction.Up;
				case 'd':
					return Base6Directions.Direction.Down;
			}
			return null;
		}

		private static DateTime tryLockOnLastGlobal;
		private DateTime tryLockOnLastLocal;
		private static DateTime sanityCheckMinTime = DateTime.Today.AddDays(-1);

		private void tryLockOn()
		{
			//log("entered tryLockOn");

			if (CNS.lockOnTarget == NavSettings.TARGET.OFF)
				return;

			DateTime now = DateTime.UtcNow;

			if (tryLockOnLastLocal > sanityCheckMinTime)
			{
				double secondsSinceLocalUpdate = (now - tryLockOnLastLocal).TotalSeconds;
				if (secondsSinceLocalUpdate < 1)
					return;
				double millisecondDelayGlobal = 9000 / secondsSinceLocalUpdate + 100;
				if (now < tryLockOnLastGlobal.AddMilliseconds(millisecondDelayGlobal))
					return;
			}
			else if (tryLockOnLastGlobal > sanityCheckMinTime && now < tryLockOnLastGlobal.AddMilliseconds(50)) // delay for first run
				return;

			log("trying to lock on type=" + CNS.lockOnTarget, "tryLockOn()", Logger.severity.TRACE);
			tryLockOnLastGlobal = now;
			tryLockOnLastLocal = now;

			Sandbox.ModAPI.IMyCubeBlock closestBlock;
			Sandbox.ModAPI.IMyCubeGrid closestEnemy = findCubeGrid(out closestBlock, false, null, CNS.lockOnBlock, CNS.lockOnRange);
			if (closestEnemy == null)
			{
				//TODO check current target for validity
				//log("no enemy found");
				return;
			}

			// found an enemy, setting as destination
			if (closestBlock != null)
				log("found an enemy: " + closestEnemy.DisplayName + ":" + closestBlock.DisplayNameText);
			else
				log("found an enemy: " + closestEnemy.DisplayName);
			CNS.setDestination(closestBlock, closestEnemy);

			if (CNS.lockOnTarget == NavSettings.TARGET.MISSILE)
			{
				CNS.isAMissile = true;
				reportState(ReportableState.MISSILE);
			}
			else
				reportState(ReportableState.ENGAGING);
			CNS.waitUntil = DateTime.UtcNow; // stop waiting
			CNS.clearSpeedInternal();
		}

		public static bool looseContains(string bigstring, string substring)
		{
			bigstring = bigstring.ToLower().Replace(" ", "");
			substring = substring.ToLower().Replace(" ", "");

			return bigstring.Contains(substring);
		}

		private static int maxLockOnRangeEnemy = 1100; // only lock-onto enemies closer than this

		// TODO: check grid for functional
		private Sandbox.ModAPI.IMyCubeGrid findCubeGrid(out Sandbox.ModAPI.IMyCubeBlock closestBlock, bool friend = true, string nameContains = null, string blockContains = null, double lockOnRangeEnemy = 0)
		{
			//log("entered findCubeGrid: " + friend + ", " + nameContains + ", " + blockContains + ", " + lockOnRangeEnemy);
			if (lockOnRangeEnemy < 1 || maxLockOnRangeEnemy < lockOnRangeEnemy)
				lockOnRangeEnemy = maxLockOnRangeEnemy;

			closestBlock = null;

			Dictionary<double, Sandbox.ModAPI.IMyCubeGrid> nearbyGrids = new Dictionary<double, Sandbox.ModAPI.IMyCubeGrid>();

			HashSet<IMyEntity> entities = new HashSet<IMyEntity>();
			MyAPIGateway.Entities.GetEntities(entities, e => e is Sandbox.ModAPI.IMyCubeGrid);
			foreach (IMyEntity entity in entities)
			{
				Sandbox.ModAPI.IMyCubeGrid grid = entity as Sandbox.ModAPI.IMyCubeGrid;
				if (Core.isHostile(myGrid, grid) == friend)
					continue;
				if (nameContains == null || looseContains(grid.DisplayName, nameContains))
				{
					double distance = myGridDim.getRCdistanceTo(grid); // even though we do not need to subtract distance to front
					if (friend || distance < lockOnRangeEnemy)
					{
						bool added = false;
						while (!added)
						{
							try
							{
								nearbyGrids.Add(distance, grid);
								added = true;
							}
							catch (ArgumentException) { distance += 0.001; }
						}
					}
				}
			}
			if (nearbyGrids.Count > 0)
				foreach (KeyValuePair<double, Sandbox.ModAPI.IMyCubeGrid> pair in nearbyGrids.OrderBy(i => i.Key))
					if (blockContains == null || findClosestCubeBlockOnGrid(out closestBlock, pair.Value, blockContains, !friend))
						return pair.Value;

			closestBlock = null;
			return null;
		}

		/// <summary>
		/// finds the closest block on a grid that contains the specified string
		/// </summary>
		/// <param name="grid"></param>
		/// <param name="blockContains"></param>
		/// <param name="searchByDefinition"></param>
		/// <returns></returns>
		private bool findClosestCubeBlockOnGrid(out Sandbox.ModAPI.IMyCubeBlock closestBlock, Sandbox.ModAPI.IMyCubeGrid grid, string blockContains, bool searchByDefinition = false) //, bool getAny = false)
		{
			//log("entered findClosestCubeBlockOnGrid: " + grid.DisplayName + ", " + blockContains + ", " + searchByDefinition + ", " + getAny);
			List<Sandbox.ModAPI.IMySlimBlock> allBlocks = new List<Sandbox.ModAPI.IMySlimBlock>();
			closestBlock = null;
			double distanceToClosest = 0;
			grid.GetBlocks(allBlocks);
			foreach (Sandbox.ModAPI.IMySlimBlock blockInGrid in allBlocks)
			{
				if (blockInGrid.FatBlock == null)
					continue;
				Sandbox.ModAPI.IMyCubeBlock fatBlock = blockInGrid.FatBlock;
				string toSearch;
				if (searchByDefinition)
					toSearch = fatBlock.DefinitionDisplayNameText;
				else
					toSearch = fatBlock.DisplayNameText;
				toSearch = toSearch.ToLower();
				if (looseContains(toSearch, blockContains))
				{
					double distance = myGridDim.getRCdistanceTo(fatBlock);
					if (closestBlock == null || distance < distanceToClosest)
					{
						closestBlock = fatBlock;
						distanceToClosest = distance;
					}
				}
			}
			return (closestBlock != null);
		}

		/// <summary>
		/// checks for is a station, is owned by current session's player, grid exists
		/// </summary>
		/// <returns>true iff it is possible for this grid to navigate</returns>
		public bool gridCanNavigate()
		{
			if (myGrid == null)
			{
				log("grid is gone...", "gridCanNavigate()", Logger.severity.INFO);
				return false;
			}
			if (myGrid.IsStatic)
				return false;

			if (MyAPIGateway.Players.GetPlayerControllingEntity(myGrid as IMyEntity) != null)
			{
				log("player is controlling grid: " + MyAPIGateway.Players.GetPlayerControllingEntity(myGrid as IMyEntity), "remoteControlIsReady()", Logger.severity.TRACE);
				return false;
			}

			//if (myGrid.BigOwners.Count > 0)
				//return Core.canControl(myGrid);

			return true;
		}

		private bool remoteControlIsNotReady = false;

		/// <summary>
		/// checks the functional and working flags, current player owns it, display name has not changed
		/// </summary>
		/// <param name="remoteControl">remote control to check</param>
		/// <returns>true iff the remote control is ready</returns>
		public bool remoteControlIsReady(Sandbox.ModAPI.IMyCubeBlock remoteControl)
		{
			if (remoteControlIsNotReady)
			{
				remoteControlIsNotReady = false;
				return false;
			}
			if (remoteControl == null)
			{
				//log("no remote control", "remoteControlIsReady()", Logger.severity.TRACE);
				return false;
			}
			if (!remoteControl.IsFunctional)
			{
				log("not functional", "remoteControlIsReady()", Logger.severity.TRACE);
				return false;
			}
			if (!remoteControl.IsWorking)
			{
				log("not working", "remoteControlIsReady()", Logger.severity.TRACE);
				return false;
			}
			if (remoteControl.CubeGrid.BigOwners.Count == 0) // no owner
			{
				log("no owner", "remoteControlIsReady()", Logger.severity.TRACE);
				return false;
			}
			//if (!Core.canControl(remoteControl))
			if (remoteControl.OwnerId != remoteControl.CubeGrid.BigOwners[0]) // remote control is not owned by grid's owner
			{
				log("remote has different owner", "remoteControlIsReady()", Logger.severity.TRACE);
				return false;
			}
			if (!(remoteControl as IMyShipController).ControlThrusters)
			{
				//log("no thruster control", "remoteControlIsReady()", Logger.severity.TRACE);
				return false;
			}

			return true;
		}

		public bool remoteControlIsReady(IMyControllableEntity remoteControl)
		{
			return remoteControlIsReady(remoteControl as Sandbox.ModAPI.IMyCubeBlock);
		}

		/// <summary>
		/// stop the ship, return navigation variables to their defaults, clears current remote control
		/// </summary>
		public void reset()
		{
			//log("resetting");
			NavSettings startNav = CNS;
			if (currentRCcontrol != null)
			{
				try
				{
					fullStop();
				}
				catch (NullReferenceException) // when grid is destroyed
				{
					//currentRCcontrol.MoveAndRotateStopped();
					//currentRCcontrol = null;
				}
				//log("clearing current remote control");
				currentRCcontrol = null;
			}
			if (needToUpdateBlocks)
				updateBlocks();
			if (object.ReferenceEquals(startNav, CNS))
			{
				log("clearing CNS", "reset()", Logger.severity.DEBUG);
				CNS = new NavSettings(myGridDim);
			}
			else
				log("did not clear CNS", "reset()", Logger.severity.TRACE);
			//CNS = new NavSettings(this);
		}

		private double pitchNeedToRotate; // from start of rotation
		private double yawNeedToRotate; // from start of rotation
		//private double? previousX = null;
		//private double? previousY = null;
		//private double moveDistance; // from start of leg to waypoint
		private double distanceToWaypoint; // from front of grid
		//private double previousDistanceToWaypoint;
		private Vector3D? previousPosition = null;
		private DateTime? previousTime = null;
		public double movementSpeed { get; private set; }
		Vector3D currentPos;
		//private double? previousMovementSpeed = null;
		//private float decelerateMovement = 1f / 2f; // how much of movement should be deceleration, only used when grid's deceleration is unknown

		//private bool destinationBehind;

		private DateTime maxRotateTime;

		/// <summary>
		/// when true collision avoidance has failed to find a path, stop Navigator
		/// </summary>
		//private bool NO_WAY_FORWARD = false;
		//private DateTime lastCollisionCheck = DateTime.UtcNow;

		// TODO: strafe short distances/manually

		private void navigate()
		{
			//log("entered navigate(" + currentWaypoint + ")", "navigate()", Logger.severity.TRACE);
			if (currentRCblock == null)
				return;
			if (!remoteControlIsReady(currentRCblock))
			{
				log("remote control is not ready");
				reset();
				return;
			}

			if (targetDirection != null)
			{
				matchOrientation(); // continue match
				return;
			}

			Vector3D currentWaypoint = (Vector3D)CNS.getWayDest(); // update() checked for null
			Vector3D displacement = currentWaypoint - myGridDim.getRCworld(); 
			//log("displacement vector: "+displacement);

			Vector3D dirNorm = Vector3D.Normalize(displacement);
			double pitch, yaw;
			getRotationC(dirNorm, out pitch, out yaw);

			distanceToWaypoint = CNS.getDistanceToWayDest(); // different result than dirNorm.Length()
			//log("distanceToWaypoint=" + distanceToWaypoint, "navigate()", Logger.severity.TRACE);

			// calculate speed & acceleration
			currentPos = myGridDim.getRCworld();
			DateTime currentTime = DateTime.UtcNow;
			//double movementSpeed = 0;

			if (previousPosition != null && previousTime != null)
			{
				double elapsedTime = ((TimeSpan)(currentTime - previousTime)).TotalSeconds;
				//log("calculating time " + elapsedTime + " = " + currentTime + " - " + previousTime);
				if (elapsedTime >= 0.1)
				{
					double distanceTraveled = (currentPos - (Vector3D)previousPosition).Length();
					if (distanceTraveled > 0.1)
					{
						// speed
						movementSpeed = distanceTraveled / elapsedTime;
						//log("setting speed " + movementSpeed + " = " + distanceTraveled + " / " + elapsedTime, "navigate()", Logger.severity.TRACE);

						previousPosition = currentPos;
						previousTime = currentTime;
					}
					else
					{
						// did not move (much)
						movementSpeed = 0;
					}
				}
			}
			else
			{
				previousPosition = currentPos;
				previousTime = currentTime;
			}

			if (CNS.moveState == NavSettings.Moving.NOT_MOVE && startOfDecelMeasureVec != null)
			{
				double distanceTraveled = (currentPos - (Vector3D)startOfDecelMeasureVec).Length();
				if (distanceTraveled > 1)
				{
					if (decelMeasureCoefficient < 0.1)
						decelMeasureCoefficient = distanceTraveled / startOfDecelMeasureSpeed;
					else
						decelMeasureCoefficient = 0.9 * decelMeasureCoefficient + 0.1 * distanceTraveled / startOfDecelMeasureSpeed;
					//log("got a measurement for deceleration: " + distanceTraveled + " / " + startOfDecelMeasureSpeed + ", " + CNS.decelMeasureCoefficient);
				}
				startOfDecelMeasureSpeed = 0;
				startOfDecelMeasureVec = null;
			}

			if (distanceToWaypoint < CNS.destinationRadius && !CNS.isAMissile) // at destination
			{
				if (CNS.getTypeOfWayDest() == NavSettings.TypeOfWayDest.WAYPOINT)
				{
					CNS.atWayDest();
					if (CNS.getTypeOfWayDest() == NavSettings.TypeOfWayDest.NULL)
					{
						myLogger.log(Logger.severity.ERROR, "navigate()", "Error no more destinations at Navigator.navigate() // at destination");
						fullStop();
					}
					else
					{
						log("reached waypoint, next type is " + CNS.getTypeOfWayDest() + ", coords: " + CNS.getWayDest(), "navigate()", Logger.severity.INFO);
						CNS.clearSpeedInternal();
						//fullStop();
					}
				}
				else
					if (CNS.destinationRadius > 0)
					{
						if (CNS.moveState == NavSettings.Moving.NOT_MOVE)
						{
							if (CNS.match_direction == null)
							{
								log("reached destination", "navigate()", Logger.severity.INFO);
								//fullStop(); // just incase we are still orienting
								CNS.atWayDest();
								//CNS.curNavState = NavSettings.State.DESTINATION;
							}
							else
							{
								//log("matching orientation", "navigate()", Logger.severity.TRACE);
								matchOrientation(); // start match
							}
						}
						else if (CNS.moveState != NavSettings.Moving.STOP_MOVE)
						{
							log("stopping at destination");
							fullStop();
							CNS.moveState = NavSettings.Moving.STOP_MOVE;
						}
					}
			}
			else // not at destination
			{
				bool doSimpleMoveAndRotate = true;
				if (!CNS.isAMissile)
				{
					Collision.collisionAvoidResult currentAvoidResult = myCollisionObject.avoidCollisions(ref CNS, updateCount);
					switch (currentAvoidResult)
					{
						case Collision.collisionAvoidResult.NOT_FINISHED:
							break;
						case Collision.collisionAvoidResult.NOT_PERFORMED:
							break;
						case Collision.collisionAvoidResult.ALTERNATE_PATH:
							CNS.noWayForward = false;
							log("got a currentAvoidResult " + currentAvoidResult + ", new waypoint is " + CNS.getWayDest(), "navigate()", Logger.severity.TRACE);
							CNS.collisionUpdateSinceWaypointAdded++;
							break;
						case Collision.collisionAvoidResult.NO_WAY_FORWARD:
							log("got a currentAvoidResult " + currentAvoidResult, "navigate()", Logger.severity.INFO);
							CNS.collisionUpdateSinceWaypointAdded++;
							CNS.noWayForward = true;
							reportState(ReportableState.NO_PATH);
							fullStop();
							doSimpleMoveAndRotate = false;
							break;
						case Collision.collisionAvoidResult.NO_OBSTRUCTION:
							CNS.noWayForward = false;
							CNS.collisionUpdateSinceWaypointAdded++;
							break;
						default:
							myLogger.log(Logger.severity.ERROR, "navigate()", "Error: unsuitable case from avoidCollisions(): " + currentAvoidResult);
							fullStop();
							doSimpleMoveAndRotate = false;
							break;
					}
				}
				if (doSimpleMoveAndRotate)
					calcMoveAndRotate(pitch, yaw, movementSpeed);
			}

			if (isStopped(pitch, yaw, movementSpeed))
			{
				if (CNS.moveState == NavSettings.Moving.STOP_MOVE)
					//log("now stopped");
					CNS.moveState = NavSettings.Moving.NOT_MOVE;
				else if (CNS.moveState == NavSettings.Moving.MOVING)
					CNS.moveState = NavSettings.Moving.STOP_MOVE;
			}
		}

		private void calcMoveAndRotate(double pitch, double yaw, double? movementSpeed)
		{
			//log("entered simpleMoveOrRotate(" + x + ", " + y + ", " + movementSpeed + ", " + currentPos + ")", "simpleMoveOrRotate()", Logger.severity.TRACE);

			if (CNS.noWayForward)
				return;

			double stoppingDistance = getStoppingDistance(movementSpeed);

			if (!CNS.isAMissile && (CNS.moveState == NavSettings.Moving.MOVING))
			{
				double distanceToDestination = distanceToWaypoint;
				switch (CNS.getTypeOfWayDest())
				{
					case NavSettings.TypeOfWayDest.BLOCK:
					case NavSettings.TypeOfWayDest.GRID:
						distanceToDestination = CNS.getDistanceToDestGrid();
						goto case NavSettings.TypeOfWayDest.COORDINATES;
					case NavSettings.TypeOfWayDest.OFFSET: // run collision avoidance on aproach rather than slowdown. see CollisionAvoidance..ctor
					case NavSettings.TypeOfWayDest.WAYPOINT:
						if (distanceToDestination < stoppingDistance) // less slowdown on aproaching waypoint, TODO remove slowdown when waypoint skip is available
						{
							//log("aproaching waypoint, setting speed limit=" + (float)(movementSpeed * 0.9), "simpleMoveOrRotate()", Logger.severity.TRACE);
							float speedSlow = (float)(movementSpeed * 0.9);
							CNS.speedSlow_internal = speedSlow;
							CNS.speedCruise_internal = speedSlow/2;
						}
						break;
					case NavSettings.TypeOfWayDest.COORDINATES:
						if (distanceToDestination < 5 * stoppingDistance)
						{
							log("on aproach (" + distanceToDestination + ", " + stoppingDistance + "), setting speed limit=" + (float)(movementSpeed * 0.9), "simpleMoveOrRotate()", Logger.severity.TRACE);
							float speedSlow = (float)(movementSpeed * 0.9);
							CNS.speedSlow_internal = speedSlow;
							CNS.speedCruise_internal = speedSlow / 2;
						}
						break;
				}
			}

			calcAndMove(pitch, yaw, movementSpeed);
			calcAndRotate(pitch, yaw);
		}

		/// <summary>
		/// start moving when less than
		/// </summary>
		private static float rotLenSq_startMove = 1f;
		/// <summary>
		/// start moving when less than, for missile
		/// </summary>
		private static float rotLenSq_startMissile = 4f;
		/// <summary>
		/// inflight rotate when greater than
		/// </summary>
		private static float rotLenSq_inflight = 0.01f;
		/// <summary>
		/// stop and rotate when greater than
		/// </summary>
		private static float rotLenSq_stopAndRot = 16f;

		private static byte collisionUpdatesBeforeMove = 1;

		private void calcAndMove(double pitch, double yaw, double? movementSpeed)
		{
			Vector2 rot = new Vector2((float)pitch, (float)yaw);
			float rotLengthSq = Math.Abs(rot.LengthSquared());
			checkAndCruise(rotLengthSq);
			if (CNS.moveState == NavSettings.Moving.NOT_MOVE && CNS.rotateState == NavSettings.Rotating.NOT_ROTA)
			{
				bool doMove = false;
				if (CNS.isAMissile)
				{
					if (rotLengthSq < rotLenSq_startMissile)
						doMove = true;
				}
				else // not a missile
					if (CNS.collisionUpdateSinceWaypointAdded >= collisionUpdatesBeforeMove)
					{
						if (rotLengthSq < rotLenSq_startMove)
							doMove = true;
					}
				if (doMove)
				{
					reportState(ReportableState.MOVING);
					moveOrder(Vector3.Forward); // move forward
					log("moving " + distanceToWaypoint + " to " + CNS.getWayDest() + ", updates="+collisionUpdatesBeforeMove+", rotLengthSq=" + rotLengthSq + ", x=" + pitch + ", y=" + yaw);
					stoppedMovingAt = DateTime.UtcNow + stoppedAfter;
					CNS.moveState = NavSettings.Moving.MOVING;
					return;
				}
			}
		}

		private void getRotationC(Vector3D dirNorm, out double pitch, out double yaw)
		{
			pitch = currentRCblock.WorldMatrix.Down.Dot(dirNorm);
			yaw = currentRCblock.WorldMatrix.Right.Dot(dirNorm);

			double forward = currentRCblock.WorldMatrix.Forward.Dot(dirNorm);
			//log("amount forward(" + forward + ") = RCfore(" + currentRCblock.WorldMatrix.Forward + ") . dirNorm(" + dirNorm + ")", "getRotationC()", Logger.severity.TRACE);

			if (forward < 0) // destination is behind myGrid
			{
				double yO = yaw;
				if (yaw > 0)
					yaw = 1;//2 - rotY;
				else
					yaw = -1;// -2 - rotY;
				//log("changing y from " + yO + " to " + rotY, "getRotationC()", Logger.severity.TRACE);
			}

			if (CNS.moveState == NavSettings.Moving.MOVING)
			{
				pitch *= inflightRotatingPower;
				yaw *= inflightRotatingPower;
			}
			else
			{
				pitch *= rotationPower;
				yaw *= rotationPower;
			}
		}

		private double pitchRotatePast;
		private double yawRotatePast;

		/// <summary>
		/// 
		/// </summary>
		/// <param name="x"></param>
		/// <param name="y"></param>
		/// <param name="precision_stopAndRot">for increasing precision of rotLenSq_stopAndRot</param>
		private void calcAndRotate(double pitch, double yaw, float? precision_stopAndRot=null){
			Vector2 rot = new Vector2((float)pitch, (float)yaw);
			float rotLengthSq = Math.Abs(rot.LengthSquared());
			if (precision_stopAndRot == null)
				precision_stopAndRot = rotLenSq_stopAndRot;

			//log("need to rotate "+rot.Length());
			// need to rotate
			switch (CNS.rotateState)
			{
				case NavSettings.Rotating.NOT_ROTA:
					{
						switch (CNS.moveState)
						{
							case NavSettings.Moving.MOVING:
								{
									if (rotLengthSq < rotLenSq_inflight)
										return;
									if (rotLengthSq > precision_stopAndRot)
									{
										log("stopping to rotate");
										fullStop();
										return;
									}
									else
									{// make a small, inflight adjustment
										pitchRotatePast = pitchNeedToRotate / 4;
										yawRotatePast = yawNeedToRotate / 4;
										pitchNeedToRotate = pitch + pitchRotatePast;
										yawNeedToRotate = yaw + yawRotatePast;
										if (Math.Abs(pitchNeedToRotate) < rotLenSq_inflight)
											pitchNeedToRotate = 0;
										if (Math.Abs(yawNeedToRotate) < rotLenSq_inflight)
											yawNeedToRotate = 0;
										if (pitchNeedToRotate == 0 && yawNeedToRotate == 0)
											return;
										log("need to adjust: " + pitch + ", " + yaw);
										changeRotationPower = !changeRotationPower;
										rotateOrder(rot); // rotate towards target
										CNS.rotateState = NavSettings.Rotating.ROTATING;
										maxRotateTime = DateTime.UtcNow.AddSeconds(3);
										return;
									}
								}
							case NavSettings.Moving.NOT_MOVE:
								{
									if (!CNS.isAMissile && CNS.collisionUpdateSinceWaypointAdded < collisionUpdatesBeforeMove)
										return;
									pitchRotatePast = 0;
									yawRotatePast = 0;
									pitchNeedToRotate = pitch;
									yawNeedToRotate = yaw;
									if (Math.Abs(pitchNeedToRotate) < rotLenSq_inflight)
										pitchNeedToRotate = 0;
									if (Math.Abs(yawNeedToRotate) < rotLenSq_inflight)
										yawNeedToRotate = 0;
									if (pitchNeedToRotate == 0 && yawNeedToRotate == 0)
										return;
									reportState(ReportableState.ROTATING);
									log("starting rotation: " + pitch + ", " + yaw+", updates="+collisionUpdatesBeforeMove);
									changeRotationPower = !changeRotationPower;
									rotateOrder(rot); // rotate towards target
									CNS.rotateState = NavSettings.Rotating.ROTATING;
									maxRotateTime = DateTime.UtcNow.AddSeconds(10);
									return;
								}
						}
						return;
					}
				case NavSettings.Rotating.STOP_ROTA:
					{
						if (isNotRotating())
						{
							adjustRotationPower(pitch, yaw);
							pitchNeedToRotate = 0;
							yawNeedToRotate = 0;
							CNS.rotateState = NavSettings.Rotating.NOT_ROTA;
						}
						return;
					}
				case NavSettings.Rotating.ROTATING:
					{
						// check for need to derotate
						pitch += pitchRotatePast;
						yaw += yawRotatePast;
						float whichDecelRot;
						if (CNS.moveState == NavSettings.Moving.MOVING)
							whichDecelRot = inflightDecelerateRotation;
						else
							whichDecelRot = decelerateRotation;
						//log("checking rotation (x=" + x + ", y=" + y + ", needToRotateX=" + needToRotateX + ", needToRotateY=" + needToRotateY + ", XrotatePast=" + XrotatePast + ", YrotatePast=" + YrotatePast + ")", "simpleMoveOrRotate()", Logger.severity.TRACE);
						//int xSigns = Math.Sign(x) * Math.Sign(needToRotateX);
						//int ySigns = Math.Sign(y) * Math.Sign(needToRotateY);
						//if ((xSigns == 0 && ySigns == 0) || DateTime.UtcNow.CompareTo(maxRotateTime) > 0
						//	|| xSigns < 0 || Math.Abs(x) < Math.Abs(needToRotateX) * whichDecelRot || Math.Abs(x) > Math.Abs(needToRotateX)
						//	|| ySigns < 0 || Math.Abs(y) < Math.Abs(needToRotateY) * whichDecelRot || Math.Abs(y) > Math.Abs(needToRotateY))
						if ((pitchNeedToRotate > rotLenSq_inflight && pitch < pitchNeedToRotate * whichDecelRot)
							|| (pitchNeedToRotate < -rotLenSq_inflight && pitch > pitchNeedToRotate * whichDecelRot)
							|| (yawNeedToRotate > rotLenSq_inflight && yaw < yawNeedToRotate * whichDecelRot)
							|| (yawNeedToRotate < -rotLenSq_inflight && yaw > yawNeedToRotate * whichDecelRot)
							|| DateTime.UtcNow.CompareTo(maxRotateTime) > 0)
						{
							log("decelerate rotation (" + pitch + ", " + yaw + ", " + pitchNeedToRotate + ", " + yawNeedToRotate + ")");
							rotateOrder(Vector2.Zero); // stop rotating
							CNS.rotateState = NavSettings.Rotating.STOP_ROTA;
						}
						return;
					}
			}
		}

		private float needToRoll = 0;
		private float? lastRoll = null;
		private DateTime stoppedRollingAt = DateTime.UtcNow;

		/// <summary>
		/// does not check for moving or rotating
		/// </summary>
		/// <param name="roll"></param>
		private void calcAndRoll(float roll)
		{
			switch (CNS.rollState)
			{
				case NavSettings.Rolling.NOT_ROLL:
					{
						log("rollin' rollin' rollin' " + roll, "calcAndRoll()", Logger.severity.DEBUG);
						needToRoll = roll;
						rollOrder(roll);
						CNS.rollState = NavSettings.Rolling.ROLLING;
						maxRotateTime = DateTime.UtcNow.AddSeconds(3);
					}
					return;
				case NavSettings.Rolling.ROLLING:
					{
						if (Math.Sign(roll) * Math.Sign(needToRoll) <= 0 || Math.Abs(roll) < Math.Abs(needToRoll) * decelerateRotation || DateTime.UtcNow.CompareTo(maxRotateTime) > 0)
						{
							log("decelerate roll, roll="+roll+", needToRoll="+needToRoll, "calcAndRoll()", Logger.severity.DEBUG);
							rollOrder(0);
							CNS.rollState = NavSettings.Rolling.STOP_ROLL;
						}
					}
					return;
				case NavSettings.Rolling.STOP_ROLL:
					{
						if (lastRoll == null || lastRoll != roll) // is rolling
						{
							stoppedRollingAt = DateTime.UtcNow + stoppedAfter;
							lastRoll = roll;
						}
						else // stopped rolling
							if (DateTime.UtcNow.CompareTo(stoppedRollingAt) > 0)
							{
								log("get off the log (done rolling) ", "calcAndRoll()", Logger.severity.DEBUG);
								lastRoll = null;
								CNS.rollState = NavSettings.Rolling.NOT_ROLL;
							}
					}
					return;
			}
		}

		private Vector3D? targetDirection = null;
		private Vector3D? targetRoll = null;
		private bool matchOrientation_finished_rotating = false;

		private void matchOrientation()
		{
			if (targetDirection == null)
			{
				CNS.getOrientationOfDest(out targetDirection, out targetRoll);
				if (targetDirection == null)
				{ matchOrientation_clear(); return; }
				log("targetDirection=" + targetDirection + ", targetRoll=" + targetRoll, "matchOrientation()", Logger.severity.DEBUG);
				matchOrientation_finished_rotating = false;
			}
			double rotX, rotY;
			//log("my Down=" + currentRCblock.WorldMatrix.Down + ", my Right=" + currentRCblock.WorldMatrix.Right, "matchOrientation()", Logger.severity.TRACE);
			getRotationC((Vector3D)targetDirection, out rotX, out rotY);
			float rotLenSq = Math.Abs((new Vector2((float)rotX, (float)rotY)).LengthSquared());
			//if (!matchOrientation_finished_rotating && rotLenSq > rotLenSq_inflight * 10)
			if (!matchOrientation_finished_rotating || CNS.rollState != NavSettings.Rolling.NOT_ROLL || rotLenSq > rotLenSq_startMove)
			{
				log("rotX=" + rotX + ", rotY=" + rotY + ", rotX/power=" + rotX / rotationPower + ", rotY/power=" + rotY / rotationPower, "matchOrientation()", Logger.severity.TRACE);
				calcAndRotate(rotX, rotY);
			}
			else
			{
				if (!matchOrientation_finished_rotating)
				{
					log("direction successfully matched rotX=" + rotX + ", rotY=" + rotY + ", " + rotLenSq + " < " + rotLenSq_inflight, "matchOrientation()", Logger.severity.DEBUG);
					fullStop();
					matchOrientation_finished_rotating = true;
				}

				if (targetRoll == null)
				{ matchOrientation_clear(); return; }

				// roll time
				float roll = (float)currentRCblock.WorldMatrix.Right.Dot((Vector3D)targetRoll) * rotationPower / 10;
				if (Math.Abs(roll) > rotLenSq_inflight)
				{
					log("roll=" + roll, "matchOrientation()", Logger.severity.TRACE);
					calcAndRoll(roll);
				}
				else
				{
					log("roll successfully matched, roll=" + roll, "matchOrientation()", Logger.severity.DEBUG);
					fullStop();
					matchOrientation_clear(); return;
				}
			}
		}

		private void matchOrientation_clear()
		{
			log("clearing", "matchOrientation_clear()", Logger.severity.DEBUG);
			CNS.match_direction = null;
			CNS.match_roll = null;
			targetDirection = null;
			targetRoll = null;
		}

		private float rotationPower = 3f;
		private float decelerateRotation = 1f / 2f; // how much of rotation should be deceleration
		private float inflightRotatingPower = 3;
		private float inflightDecelerateRotation = 1f / 2f;

		private static float decelerateAdjustmentOver = 1.15f; // adjust decelerate by this much when overshoot
		private static float decelerateAdjustmentUnder = 0.90f; // adjust decelerate by this much when undershoot
		private static float rotationPowerAdjustmentOver = 0.85f;
		private static float rotationPowerAdjustmentUnder = 1.10f;

		private void adjustRotationPower(double x, double y)
		{
			int overUnder = 0;
			log("checking for over/under shoot on rotation: x=" + x + ", needX=" + pitchNeedToRotate + ", y=" + y + ", needY=" + yawNeedToRotate);
			//	check for overshoot/undershoot
			if (Math.Abs(x) > 0.1 && Math.Abs(pitchNeedToRotate) > 0.1)
				if (Math.Sign(x) * Math.Sign(pitchNeedToRotate) == 1) // same sign
					//if ((x > 0 && needToRotateX > 0) || (x < 0 && needToRotateX < 0))
					overUnder--;
				else
					overUnder++;
			if (Math.Abs(y) > 0.1 && Math.Abs(yawNeedToRotate) > 0.1)
				if (Math.Sign(y) * Math.Sign(yawNeedToRotate) == 1) // same sign
					//if ((y > 0 && needToRotateY > 0) || (y < 0 && needToRotateY < 0))
					overUnder--;
				else
					overUnder++;

			if (overUnder != 0)
			{
				if (overUnder > 0) // over rotated
					if (changeRotationPower)
						adjustRotationPowerBy(rotationPowerAdjustmentOver);
					else
						adjustRotationPowerBy(decelerateAdjustmentOver);
				else // under rotated
					if (changeRotationPower)
						adjustRotationPowerBy(rotationPowerAdjustmentUnder);
					else
						adjustRotationPowerBy(decelerateAdjustmentUnder);

				log("power adjusted, under/over is " + overUnder + " x=" + x + "/" + pitchNeedToRotate + ", y=" + y + "/" + yawNeedToRotate);
			}
		}

		private bool changeRotationPower;

		private void adjustRotationPowerBy(float adjustBy)
		{
			if (changeRotationPower)
			{
				if (CNS.moveState == NavSettings.Moving.MOVING)
				{
					inflightRotatingPower *= adjustBy;
					log("adjusted inflightRotatingPower, new value is " + inflightRotatingPower, "adjustRotationPowerBy", Logger.severity.DEBUG);
				}
				else
				{
					rotationPower *= adjustBy;
					log("adjusted rotationPower, new value is " + rotationPower, "adjustRotationPowerBy", Logger.severity.DEBUG);
				}
			}
			else
			{
				if (CNS.moveState == NavSettings.Moving.MOVING)
				{
					inflightDecelerateRotation *= adjustBy;
					log("adjusted inflightDecelerateRotation, new value is " + inflightDecelerateRotation, "adjustRotationPowerBy", Logger.severity.DEBUG);
				}
				else
				{
					decelerateRotation *= adjustBy;
					log("adjusted decelerateRotation, new value is " + decelerateRotation, "adjustRotationPowerBy", Logger.severity.DEBUG);
				}
			}
		}

		private void capFloat(ref float value, float min, float max)
		{
			if (value < min)
			{
				//myLogger.log(Logger.severity.WARNING, "capFloat", "value too low " + value + " < " + min, CNS.moveState.ToString(), CNS.rotateState.ToString());
				value = min;
			}
			else if (value > max)
			{
				//myLogger.log(Logger.severity.WARNING, "capFloat", "value too high " + value + " > " + max, CNS.moveState.ToString(), CNS.rotateState.ToString());
				value = max;
			}
		}

		private static TimeSpan stoppedAfter = new TimeSpan(0, 0, 0, 1);
		private DateTime stoppedMovingAt;

		private bool isStopped(double? x, double? y, double? speed)
		{
			if (speed == null || speed > 0.1f)
			{
				stoppedMovingAt = DateTime.UtcNow + stoppedAfter;
				return false;
			}
			else
				return DateTime.UtcNow > stoppedMovingAt;
		}

		private DateTime stoppedRotatingAt;
		/// <summary>
		/// this is based on ship forward
		/// </summary>
		private Vector3D? facing = null;

		private static float notRotPrecision = 0.01f;

		private bool isNotRotating()
		{
			Vector3D origin = myGrid.GetPosition();
			Vector3D forward = myGrid.GridIntegerToWorld(Vector3I.Forward);
			Vector3D currentFace = forward - origin;

			bool currentlyRotating;
			if (facing == null)
				currentlyRotating = true;
			else
			{
				Vector3D prevFace = (Vector3D)facing;
				if (Math.Abs(currentFace.X - prevFace.X) > notRotPrecision || Math.Abs(currentFace.Y - prevFace.Y) > notRotPrecision || Math.Abs(currentFace.Z - prevFace.Z) > notRotPrecision)
				{
					currentlyRotating = true;
					//log("rotating at this instant, dx=" + Math.Abs(currentFace.X - prevFace.X) + ", dy=" + Math.Abs(currentFace.Y - prevFace.Y) + ", dz=" + Math.Abs(currentFace.Z - prevFace.Z) + ", S.A.=" + stoppedRotatingAt, "isNotRotating()", Logger.severity.TRACE);
				}
				else
				{
					currentlyRotating = false;
					//log("not rotating at this instant, dx=" + Math.Abs(currentFace.X - prevFace.X) + ", dy=" + Math.Abs(currentFace.Y - prevFace.Y) + ", dz=" + Math.Abs(currentFace.Z - prevFace.Z) + ", S.A.=" + stoppedRotatingAt, "isNotRotating()", Logger.severity.TRACE);
				}
			}
			facing = currentFace;

			if (currentlyRotating)
			{
				//log("rotating");
				stoppedRotatingAt = DateTime.UtcNow + stoppedAfter;
				return false;
			}
			else
				return DateTime.UtcNow > stoppedRotatingAt;
		}

		private double startOfDecelMeasureSpeed = 0;
		private Vector3D? startOfDecelMeasureVec = null;

		/// <summary>
		/// for other kinds of stop use moveOrder(Vector3.Zero) or similar
		/// </summary>
		private void fullStop()
		{
			reportState(ReportableState.STOPPING);
			log("full stop");
			currentMove = Vector3.Zero;
			currentRotate = Vector2.Zero;
			currentRoll = 0;
			CNS.clearSpeedInternal();

			setDampeners();
			currentRCcontrol.MoveAndRotateStopped();

			if (movementSpeed > 1 && CNS.moveState == NavSettings.Moving.MOVING)
			{
				//CNS.moveState = NavSettings.Moving.STOPING_M;
				startOfDecelMeasureSpeed = (double)movementSpeed;
				startOfDecelMeasureVec = currentPos;
			}
			CNS.moveState = NavSettings.Moving.STOP_MOVE;
			CNS.rotateState = NavSettings.Rotating.STOP_ROTA;
			pitchNeedToRotate = 0;
			yawNeedToRotate = 0;
		}

		private Vector3 currentMove = Vector3.Zero;
		private Vector2 currentRotate = Vector2.Zero;
		private float currentRoll = 0;

		private void moveOrder(Vector3 move)
		{
			//log("entered moveOrder("+move+")");
			if (currentMove == move)
				return;
			currentMove = move;
			moveAndRotate();
		}

		private void rotateOrder(Vector2 rotate)
		{
			//log("entered rotateOrder("+rotate+")");
			if (currentRotate == rotate)
				return;
			currentRotate = rotate;
			moveAndRotate();
		}

		private void rollOrder(float roll)
		{
			//log("entered rollOrder("+roll+")");
			if (currentRoll == roll)
				return;
			currentRoll = roll;
			moveAndRotate();
		}

		private void moveAndRotate()
		{
			//isCruising = false;
			if (currentMove == Vector3.Zero && currentRotate == Vector2.Zero && currentRoll == 0)
			{
				log("MAR is actually stop");
				currentRCcontrol.MoveAndRotateStopped();
			}
			else
			{
				log("doing MAR(" + currentMove + ", " + currentRotate + ", " + currentRoll + ")");
				currentRCcontrol.MoveAndRotate(currentMove, currentRotate, currentRoll);
			}
		}

		private void setDampeners(bool dampenersOn = true)
		{
			if ((myGrid.GetObjectBuilder() as MyObjectBuilder_CubeGrid).DampenersEnabled != dampenersOn)
			{
				currentRCcontrol.SwitchDamping();
				if (!dampenersOn)
					log("speed control: disabling dampeners. speed=" + movementSpeed + ", cruise=" + CNS.getSpeedCruise() + ", slow=" + CNS.getSpeedSlow());
				else
					log("speed control: enabling dampeners. speed=" + movementSpeed + ", cruise=" + CNS.getSpeedCruise() + ", slow=" + CNS.getSpeedSlow());
			}
		}

		private static Vector3 cruiseForward = new Vector3(0, 0, -0.001); // hopefully this minimum is consistent
		/// <summary>
		/// call every run, needed to enable dampeners
		/// two options for cruise: use cruiseForward, or disable dampeners
		/// </summary>
		private void checkAndCruise(float rotLengthSq)
		{
			//log("entered checkAndCruise, speed="+movementSpeed+", slow="+CNS.getSpeedSlow()+", cruise="+CNS.getSpeedCruise());

			if (CNS.moveState != NavSettings.Moving.MOVING)
			{
				setDampeners();
				return;
			}

			if (movementSpeed > CNS.getSpeedSlow())
			{
				setDampeners();
				moveOrder(Vector3.Zero);
				return;
			}
			if (movementSpeed < CNS.getSpeedCruise())
			{
				setDampeners();
				moveOrder(Vector3.Forward);
				return;
			}
			if (CNS.rotateState == NavSettings.Rotating.NOT_ROTA) // as long as state change comes after checkAndCruise, this will work
			{
				// disable dampeners
				setDampeners(false);
				moveOrder(Vector3D.Zero);
				return;
			}
			else
			{
				// use cruise vector
				moveOrder(cruiseForward);
				setDampeners();
				return;
			}
		}

		private static double decelMeasureCoefficient = 1f;

		private double getStoppingDistance(double? speed)
		{
			//if (CNS.decelMeasureCoefficient >= 0.1)
			return decelMeasureCoefficient * (double)speed;
			//else
			//return moveDistance * decelerateMovement;
		}

		public override string ToString()
		{
			return "Nav:" + myGrid.DisplayName;
		}

		private enum ReportableState : byte { OFF, PATHFINDING, ROTATING, MOVING, STOPPING, NO_PATH, NO_DEST, MISSILE, ENGAGING };
		private ReportableState currentReportable = ReportableState.OFF;

		/// <summary>
		/// may ignore the given state, if Nav is actually in another state
		/// </summary>
		/// <param name="newState"></param>
		private void reportState(ReportableState newState)
		{
			//log("entered reportState()", "reportState()", Logger.severity.TRACE);
			if (currentRemoteControl_Value == null)
			{
				//log("cannot report without RC", "reportState()", Logger.severity.TRACE);
				return;
			}

			string displayName = (currentRemoteControl_Value as Sandbox.ModAPI.IMyCubeBlock).DisplayNameText;
			if (displayName == null)
			{
				myLogger.log(Logger.severity.WARNING, "reportState()", "cannot report without display name");
				return;
			}

			if (CNS.noWayForward)
			{
				//log("changing report to NO_PATH(noWayForward)", "reportState()", Logger.severity.TRACE);
				newState = ReportableState.NO_PATH;
			}
			if (CNS.EXIT)
			{
				newState = ReportableState.OFF;
			}

			// did state actually change?
			if (newState == currentReportable)
				return;
			currentReportable = newState;

			// cut old state, if any
			int endOfState = displayName.IndexOf('>');
			if (endOfState != -1)
				displayName = displayName.Substring(endOfState + 1);

			// add new state
			StringBuilder newName = new StringBuilder();
			newName.Append('<');
			newName.Append(newState);
			newName.Append('>');
			newName.Append(displayName);
			//RCDisplayName = newName.ToString();

			//ignore_RemoteControl_nameChange = true;
			(currentRemoteControl_Value as IMyRemoteControl).SetCustomName(newName);
			//ignore_RemoteControl_nameChange = false;
			log("added ReportableState to RC: " + newState, "reportState()", Logger.severity.TRACE);
		}

		//private bool ignore_RemoteControl_nameChange = false;
		private string instructions;
		private void remoteControl_OnNameChanged(Sandbox.ModAPI.IMyTerminalBlock whichBlock)
		{
			string instructionsInBlock = getInstructionsFromRC(whichBlock as Sandbox.ModAPI.IMyCubeBlock);
			if (instructions == null || !instructions.Equals(instructionsInBlock))
			{
				log("RC name changed: " + whichBlock.CustomName+"; inst were: "+instructions+"; are now: "+instructionsInBlock, "remoteControl_OnNameChanged()", Logger.severity.DEBUG);
				instructions = instructionsInBlock;
				remoteControlIsNotReady = true;
				reset();
				CNS.waitUntilNoCheck = DateTime.UtcNow.AddSeconds(1);
			}
		}

		private string getInstructionsFromRC(Sandbox.ModAPI.IMyCubeBlock rc)
		{
			string displayName = rc.DisplayNameText;
			int start = displayName.IndexOf('[') + 1;
			int end = displayName.IndexOf(']');
			if (start > 0 && end > start) // has appropriate brackets
			{
				int length = end - start;
				return displayName.Substring(start, length);
			}
			return null;
		}
	}
}
