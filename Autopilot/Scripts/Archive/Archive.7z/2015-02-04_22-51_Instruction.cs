﻿#define LOG_ENABLED //remove on build

using System;
//using System.Collections.Generic;
//using System.Linq;
using System.Text.RegularExpressions;

using Sandbox.ModAPI;
using VRageMath;

namespace Rynchodon.Autopilot.Instruction
{
	public class Interpreter
	{
		private Navigator owner;

		private Logger myLogger;
		[System.Diagnostics.Conditional("LOG_ENABLED")]
		private void log(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{ alwaysLog(toLog, method, level); }
		private void alwaysLog(string toLog, string method = null, Logger.severity level = Logger.severity.DEBUG)
		{
			if (myLogger == null) myLogger = new Logger(owner.myGrid.DisplayName, "Instruction");
			myLogger.log(level, method, toLog);
		}

		public Interpreter(Navigator owner)
		{ this.owner = owner; }

		// TODO addInstruction should be moved here, as instruction parsing is re-written
		public bool getAction(out Action asAction, string instruction)
		{
			log("entered getAction(asAction, " + instruction + ")", "getAction()", Logger.severity.TRACE);
			asAction = null;
			if (instruction.Length < 2)
			{
				log("instruction too short: "+instruction.Length, "getAction()", Logger.severity.TRACE);
				return false;
			}

			string lowerCase = instruction.ToLower();
			string data = lowerCase.Substring(1);
			log("instruction = " + instruction + ", lowerCase = " + lowerCase + ", data = " + data + ", lowerCase[0] = " + lowerCase[0], "getAction()", Logger.severity.TRACE);
			switch (lowerCase[0])
			{
				case 'f':
					return getAction_flyTo(out asAction, owner.currentRCblock, data);
			}
			log("could not match: " + lowerCase[0], "getAction()", Logger.severity.TRACE);
			return false;
		}

		public bool getAction_flyTo(out Action execute, IMyCubeBlock block, string instruction)
		{
			execute = null;
			RelativeVector3F result;
			log("checking flyOldStyle", "getAction_flyTo()", Logger.severity.TRACE);
			if (!flyOldStyle(out result, block, instruction))
			{
				log("checking flyNewStyle", "getAction_flyTo()", Logger.severity.TRACE);
				if (!flyNewStyle(out result, block, instruction))
				{
					log("failed both styles", "getAction_flyTo()", Logger.severity.TRACE);
					return false;
				}
			}

			log("passed, destination will be "+result.getWorldAbsolute(), "getAction_flyTo()", Logger.severity.TRACE);
			execute = () => owner.CNS.setDestination(result.getWorldAbsolute());
			//log("created action: " + execute, "getAction_flyTo()", Logger.severity.TRACE);
			return true;
		}

		/// <summary>
		/// tries to read fly instruction of form (r), (u), (b)
		/// </summary>
		/// <param name="result"></param>
		/// <param name="instruction"></param>
		/// <returns>true iff successful</returns>
		private static bool flyOldStyle(out RelativeVector3F result, IMyCubeBlock block, string instruction)
		{
			result = null;
			string[] coordsString = instruction.Split(',');
			if (coordsString.Length != 3)
				return false;

			double[] coordsDouble = new double[3];
			for (int i = 0; i < coordsDouble.Length; i++)
				if (!Double.TryParse(coordsString[i], out coordsDouble[i]))
					return false;

			Vector3D fromBlock = new Vector3D(coordsDouble[0], coordsDouble[1], coordsDouble[2]);
			result = RelativeVector3F.createFromBlock(fromBlock, block);
			return true;
		}

		/// <summary>
		/// splits by ',', then adds each according to its imbedded direction
		/// </summary>
		/// <param name="result"></param>
		/// <param name="block"></param>
		/// <param name="instruction"></param>
		/// <returns>true iff successful</returns>
		private bool flyNewStyle(out RelativeVector3F result, IMyCubeBlock block, string instruction)
		{
			log("entered flyNewStyle(result, " + block.DisplayNameText + ", " + instruction + ")", "flyNewStyle()", Logger.severity.TRACE);
			result = null;
			string[] parts = instruction.Split(',');
			if (parts.Length == 0)
			{
				log("parts.Length == 0", "flyNewStyle()", Logger.severity.TRACE);
				return false;
			}

			Vector3D compound = Vector3D.Zero;
			foreach (string part in parts)
			{
				Vector3D partVector;
				if (!stringToVector3D(out partVector, part))
				{
					log("stringToVector3D failed", "flyNewStyle()", Logger.severity.TRACE);
					return false;
				}
				compound += partVector;
			}

			result = RelativeVector3F.createFromBlock(compound, block);
			return true;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="result"></param>
		/// <param name="vectorString">takes the form "(number)(direction)"</param>
		/// <returns></returns>
		private bool stringToVector3D(out Vector3D result, string vectorString)
		{
			log("entered stringToVector3D(result, " + vectorString + ")", "stringToVector3D()", Logger.severity.TRACE);
			result = new Vector3D();
			string[] numberString = Regex.Split(vectorString, @"\D+", RegexOptions.IgnorePatternWhitespace);
			if (numberString.Length != 1 || numberString[0] == null)
			{
				log("bad length(" + numberString.Length + ") or invalid(" + numberString[0] + ")", "stringToVector3D()", Logger.severity.TRACE);
				return false;
			}
			double number;
			if (!double.TryParse(numberString[0], out number))
			{
				log("failed to parse (" + numberString[0] + " => " + number + ")", "stringToVector3D()", Logger.severity.TRACE);
				return false;
			}
			string[] directionString = Regex.Split(vectorString, @"\d+", RegexOptions.IgnorePatternWhitespace);
			if (directionString.Length != 1 || directionString[0] == null)
			{
				log("bad length(" + directionString.Length + ") or invalid(" + directionString[0] + ")", "stringToVector3D()", Logger.severity.TRACE);
				return false;
			}
			Base6Directions.Direction? direction = stringToDirection(directionString[0]);
			if (direction == null)
			{
				log("failed to parse (" + directionString[0] + " => " + direction + ")", "stringToVector3D()", Logger.severity.TRACE);
				return false;
			}

			result = (Vector3D)Base6Directions.GetVector((Base6Directions.Direction)direction) * number;
			return true;
		}

		private static Base6Directions.Direction? stringToDirection(string str)
		{
			switch (str[0])
			{
				case 'f':
					return Base6Directions.Direction.Forward;
				case 'b':
					return Base6Directions.Direction.Backward;
				case 'l':
					return Base6Directions.Direction.Left;
				case 'r':
					return Base6Directions.Direction.Right;
				case 'u':
					return Base6Directions.Direction.Up;
				case 'd':
					return Base6Directions.Direction.Down;
			}
			return null;
		}
	}
}
